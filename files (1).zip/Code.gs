/** ============================================================
 *  HỆ THỐNG QUẢN LÝ ĐƠN HÀNG 9 SẠCH - Code.gs v6.1
 *  [FIX 261028] Xóa sản phẩm vẫn hiện lại: deleteProductFromSheet xóa TẤT CẢ
 *  dòng trùng mã (trước đây chỉ xóa dòng đầu); _ensureMasterProducts có khóa
 *  chống ghi trùng; thêm hàm dọn dòng trùng cleanDuplicateProducts().
 *  ================================================================
 *  THAY ĐỔI SO VỚI v6.0:
 *  [SỬA] getHistoryPage: nhận empFilter dạng MẢNG (chọn nhiều nhân
 *  viên cùng lúc ở trang Lịch Sử) - vẫn tương thích ngược nếu truyền
 *  1 string như cũ.
 *  [MỚI] deleteCongNoRow: xóa vĩnh viễn 1 dòng công nợ theo sheetRow
 *  (chỉ gọi từ giao diện Admin).
 *  [GIỮ NGUYÊN] Toàn bộ logic v6.0: danh mục sản phẩm, công nợ thanh
 *  toán từng phần, báo cáo tổng hợp nhiều sheet, ghi đơn an toàn với
 *  công thức mảng (chỉ ghi A:K, O, S - không đụng L/M/N/P/Q/R/T).
 * ============================================================ */

// ─── ENTRY POINT ────────────────────────────────────────────
function doGet() {
  return HtmlService.createTemplateFromFile('index')
    .evaluate()
    .setTitle('9 Sạch - Hệ Thống Giá Sỉ')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ─── HELPER: lấy/tạo sheet theo tên ─────────────────────────
function _sheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    if (headers) sh.appendRow(headers);
  }
  return sh;
}

function _clean(v) {
  return v instanceof Date ? v.toISOString() : v;
}

// ════════════════════════════════════════════════════════════
//  GỘP DỮ LIỆU KHỞI TẠO
// ════════════════════════════════════════════════════════════
function getInitData(passwordInput) {
  const login = checkLogin(passwordInput);
  if (!login || !login.success) return { login: login };
  return {
    login: login,
    employees: getEmployeeList(),
    products: getProductsCached(),
    categories: getProductCategories()
  };
}

// ════════════════════════════════════════════════════════════
//  NHÂN VIÊN
// ════════════════════════════════════════════════════════════
function _empSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('NhanVien');
  if (!sh) {
    sh = ss.insertSheet('NhanVien');
    sh.appendRow(['Tên Hiển Thị', 'Tên Đăng Nhập', 'Email', 'Quyền']);
    sh.appendRow(['Quản Lý', '9sach2026', '', 'Admin']);
  } else {
    const hdr = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
    if (hdr.length < 3 || hdr[2] !== 'Email') sh.getRange(1, 3).setValue('Email');
    if (hdr.length < 4 || hdr[3] !== 'Quyền') {
      sh.getRange(1, 4).setValue('Quyền');
      const data = sh.getDataRange().getValues();
      for (let i = 1; i < data.length; i++) {
        if (!data[i][3]) sh.getRange(i + 1, 4).setValue(i === 1 ? 'Admin' : 'NhanVien');
      }
    }
  }
  return sh;
}

function checkLogin(passwordInput) {
  try {
    const sh = _empSheet();
    const data = sh.getDataRange().getValues();
    const clean = passwordInput.toString().trim();
    for (let i = 1; i < data.length; i++) {
      if (data[i][1].toString().trim() === clean) {
        return {
          success: true,
          displayName: data[i][0].toString().trim(),
          username: data[i][1].toString().trim(),
          email: (data[i][2] || '').toString().trim(),
          role: (data[i][3] || 'NhanVien').toString().trim()
        };
      }
    }
    return { success: false };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

function saveNewEmployee(displayName, username, email, role) {
  try {
    const sh = _empSheet();
    const lastRow = sh.getLastRow();
    const usernames = lastRow > 1 ? sh.getRange(2, 2, lastRow - 1, 1).getValues() : [];
    const cleanU = username.toString().trim();
    const cleanD = displayName.toString().trim();
    if (!cleanU || !cleanD) return 'Vui lòng nhập đầy đủ thông tin!';
    for (let i = 0; i < usernames.length; i++) {
      if (usernames[i][0].toString().trim() === cleanU) return 'Lỗi: Tên đăng nhập này đã tồn tại!';
    }
    sh.appendRow([cleanD, cleanU, email || '', role || 'NhanVien']);
    return 'Thêm nhân viên mới thành công!';
  } catch (e) {
    return 'Lỗi thêm nhân viên: ' + e.toString();
  }
}
function updateEmployeeRecord(oldUsername, data) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _empSheet();
    const lastRow = sh.getLastRow();
    if (lastRow < 2) return { success: false, error: 'Không có nhân viên nào.' };
    const rows = sh.getRange(2, 1, lastRow - 1, 4).getValues();
    const cleanOld = (oldUsername || '').toString().trim();
    const newUsername = (data.username || '').toString().trim();
    const newDisplayName = (data.displayName || '').toString().trim();
    if (!newUsername || !newDisplayName) return { success: false, error: 'Thiếu tên hiển thị hoặc tên đăng nhập.' };

    let targetIdx = -1;
    for (let i = 0; i < rows.length; i++) {
      if (rows[i][1].toString().trim() === cleanOld) { targetIdx = i; break; }
    }
    if (targetIdx === -1) return { success: false, error: 'Không tìm thấy nhân viên này.' };

    for (let i = 0; i < rows.length; i++) {
      if (i !== targetIdx && rows[i][1].toString().trim() === newUsername) {
        return { success: false, error: 'Tên đăng nhập này đã được dùng bởi nhân viên khác.' };
      }
    }

    const oldRole = (rows[targetIdx][3] || 'NhanVien').toString();
    if (oldRole === 'Admin' && data.role !== 'Admin') {
      const adminCount = rows.filter(r => (r[3] || '') === 'Admin').length;
      if (adminCount <= 1) return { success: false, error: 'Không thể hạ quyền Admin duy nhất còn lại.' };
    }

    sh.getRange(targetIdx + 2, 1, 1, 4).setValues([[newDisplayName, newUsername, data.email || '', data.role || 'NhanVien']]);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

function deleteEmployeeRecord(username) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _empSheet();
    const lastRow = sh.getLastRow();
    if (lastRow < 2) return { success: false, error: 'Không có nhân viên nào.' };
    const rows = sh.getRange(2, 1, lastRow - 1, 4).getValues();
    const clean = (username || '').toString().trim();
    let targetIdx = -1;
    for (let i = 0; i < rows.length; i++) {
      if (rows[i][1].toString().trim() === clean) { targetIdx = i; break; }
    }
    if (targetIdx === -1) return { success: false, error: 'Không tìm thấy nhân viên này.' };
    const role = (rows[targetIdx][3] || 'NhanVien').toString();
    if (role === 'Admin') {
      const adminCount = rows.filter(r => (r[3] || '') === 'Admin').length;
      if (adminCount <= 1) return { success: false, error: 'Không thể xóa Admin duy nhất còn lại.' };
    }
    sh.deleteRow(targetIdx + 2);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

function getEmployeeList() {
  try {
    const sh = _empSheet();
    const data = sh.getDataRange().getValues();
    return data.slice(1).map(r => ({
      displayName: r[0] || '', username: r[1] || '', email: r[2] || '', role: r[3] || 'NhanVien',
      zaloChatId: (r[4] || '').toString().trim()
    }));
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  SẢN PHẨM (cache 5 phút)
//  [v5.0] cột N = "Tên Chi Tiết"
//  [v6.0] cột O = "Danh Mục" (Bánh Ổ / Bánh Dẻo / Bánh Set / Khác...)
//  Thêm vào CUỐI (không chèn giữa) để không xáo trộn các cột giá cũ.
// ════════════════════════════════════════════════════════════
const SP_HEADERS = ['Mã SP', 'Tên SP', 'Hình Ảnh', 'Giá Lẻ', 'Sỉ Menu', 'Giá Shopee',
  'Sỉ Cửa Hàng', 'Sỉ Khánh Quyên', 'Sỉ 200 - 400', 'Sỉ 400 - 600', 'Sỉ > 600', 'Sỉ Hội Chợ', 'Sỉ Hội Chợ TM',
  'Tên Chi Tiết / Mô Tả', 'Danh Mục'];
const PRODUCT_CACHE_KEY = 'sp_cache_v6';
const DEFAULT_CATEGORIES = ['Bánh Ổ', 'Bánh Dẻo', 'Bánh Set', 'Khác'];

const MASTER_PRODUCTS = [
  {id:'KTC',  name:'KTC',      img:'https://img.upanhnhanh.com/e8489f140ba72e1d931b9c4624241094', normal:95000,  si_menu:80000,  shopee:115000, si_cua_hang:80000,  si_khanh_quyen:80000,  si_200_400:80000,  si_400_600:80000,  si_600:80000,  si_hoi_cho:80000,  si_hoi_cho_TM:80000, detailName:'', category:'Khác'},
  {id:'S2',   name:'SET 2',    img:'https://img.upanhnhanh.com/2ee76611aaef01682df06a8d24a75ced',  normal:33000,  si_menu:24000,  shopee:40000,  si_cua_hang:22000,  si_khanh_quyen:22000,  si_200_400:23600,  si_400_600:22700,  si_600:22600,  si_hoi_cho:22000,  si_hoi_cho_TM:22000, detailName:'', category:'Bánh Set'},
  {id:'S4',   name:'SET 4',    img:'https://img.upanhnhanh.com/0cbf1c82ea50ad4c7a0cee5adf9996d4',  normal:66000,  si_menu:48000,  shopee:79000,  si_cua_hang:44000,  si_khanh_quyen:44000,  si_200_400:47100,  si_400_600:45300,  si_600:45200,  si_hoi_cho:44000,  si_hoi_cho_TM:44000, detailName:'', category:'Bánh Set'},
  {id:'S6',   name:'SET 6',    img:'https://img.upanhnhanh.com/0cbf1c82ea50ad4c7a0cee5adf9996d4',  normal:95000,  si_menu:72000,  shopee:115000, si_cua_hang:66000,  si_khanh_quyen:66000,  si_200_400:70800,  si_400_600:68100,  si_600:67800,  si_hoi_cho:0,      si_hoi_cho_TM:0, detailName:'', category:'Bánh Set'},
  {id:'M12',  name:'MIX 12',   img:'https://img.upanhnhanh.com/b907577e22ad9ed4985a85548bf4ce58',  normal:155000, si_menu:118000, shopee:185000, si_cua_hang:98000,  si_khanh_quyen:96000,  si_200_400:116000, si_400_600:114000, si_600:112000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'M16',  name:'MIX 16',   img:'https://img.upanhnhanh.com/b907577e22ad9ed4985a85548bf4ce58',  normal:195000, si_menu:153000, shopee:220000, si_cua_hang:133000, si_khanh_quyen:131000, si_200_400:151000, si_400_600:149000, si_600:147000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'},
  {id:'T12',  name:'TÍM 12',   img:'https://img.upanhnhanh.com/4d94d2a6c1adad6c393c6d078703a877',  normal:150000, si_menu:115000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:113000, si_400_600:111000, si_600:109000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'T16',  name:'TÍM 16',   img:'https://img.upanhnhanh.com/4d94d2a6c1adad6c393c6d078703a877',  normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'},
  {id:'P12',  name:'PSX 12',   img:'https://img.upanhnhanh.com/5af1fed9bba08c5ee5de8d292d1dd090',  normal:150000, si_menu:115000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:113000, si_400_600:111000, si_600:109000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'P16',  name:'PSX 16',   img:'https://img.upanhnhanh.com/5af1fed9bba08c5ee5de8d292d1dd090',  normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'},
  {id:'C12',  name:'CHOCO 12', img:'https://img.upanhnhanh.com/4ca6fe6abbd674c210e4e20d5ffae306',  normal:150000, si_menu:115000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:113000, si_400_600:111000, si_600:109000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'C16',  name:'CHOCO 16', img:'https://img.upanhnhanh.com/4ca6fe6abbd674c210e4e20d5ffae306',  normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'V12',  name:'VÀNG 12',  img:'https://img.upanhnhanh.com/bf71a516405897c4ad58c1104eb6d48c',  normal:150000, si_menu:110000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:108000, si_400_600:106000, si_600:104000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'V16',  name:'VÀNG 16',  img:'https://img.upanhnhanh.com/bf71a516405897c4ad58c1104eb6d48c',  normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'},
  {id:'TT12', name:'THAN 12',  img:'https://img.upanhnhanh.com/86c74481f420ec213331ee3a637c99b4', normal:150000, si_menu:115000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:113000, si_400_600:111000, si_600:109000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'TT16', name:'THAN 16',  img:'https://img.upanhnhanh.com/86c74481f420ec213331ee3a637c99b4', normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'},
  {id:'X12',  name:'XANH 12',  img:'https://img.upanhnhanh.com/17aa89e46257f88f2aca0ecdc41cb92b', normal:150000, si_menu:110000, shopee:175000, si_cua_hang:95000,  si_khanh_quyen:93000,  si_200_400:108000, si_400_600:106000, si_600:104000, si_hoi_cho:95000,  si_hoi_cho_TM:95000, detailName:'', category:'Bánh Ổ'},
  {id:'X16',  name:'XANH 16',  img:'https://img.upanhnhanh.com/17aa89e46257f88f2aca0ecdc41cb92b', normal:190000, si_menu:150000, shopee:215000, si_cua_hang:130000, si_khanh_quyen:128000, si_200_400:148000, si_400_600:146000, si_600:144000, si_hoi_cho:140000, si_hoi_cho_TM:140000, detailName:'', category:'Bánh Ổ'}
];

function _ensureMasterProducts(sh) {
  // [FIX] Khóa để 2 request chạy song song không cùng ghi KTC/S2... gây trùng dòng
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return; }
  try {
    const lastRow = sh.getLastRow();
    const existingIds = {};
    if (lastRow > 1) {
      sh.getRange(2, 1, lastRow - 1, 1).getValues().forEach(r => {
        if (r[0] !== '' && r[0] !== null) existingIds[r[0].toString().trim().toUpperCase()] = true;
      });
    }
    const deletedIds = _getDeletedMasterIds_();
    const missing = MASTER_PRODUCTS.filter(p => !existingIds[p.id.toUpperCase()] && deletedIds.indexOf(p.id.toUpperCase()) === -1);
    if (!missing.length) return;
    const rows = missing.map(p => [
      p.id, p.name, p.img, p.normal, p.si_menu, p.shopee, p.si_cua_hang, p.si_khanh_quyen,
      p.si_200_400, p.si_400_600, p.si_600, p.si_hoi_cho, p.si_hoi_cho_TM, p.detailName || '', p.category || ''
    ]);
    sh.getRange(sh.getLastRow() + 1, 1, rows.length, 15).setValues(rows);
  } finally { lock.releaseLock(); }
}

function _getDeletedMasterIds_() {
  try { return JSON.parse(PropertiesService.getScriptProperties().getProperty('deletedMasterIds') || '[]'); } catch (e) { return []; }
}
function _markMasterDeleted_(id) {
  try {
    const key = (id || '').toString().toUpperCase();
    const list = _getDeletedMasterIds_();
    if (key && list.indexOf(key) === -1) { list.push(key); PropertiesService.getScriptProperties().setProperty('deletedMasterIds', JSON.stringify(list)); }
  } catch (e) {}
}
function _unmarkMasterDeleted_(id) {
  try {
    const key = (id || '').toString().toUpperCase();
    const list = _getDeletedMasterIds_();
    const idx = list.indexOf(key);
    if (idx !== -1) { list.splice(idx, 1); PropertiesService.getScriptProperties().setProperty('deletedMasterIds', JSON.stringify(list)); }
  } catch (e) {}
}

function getProductsCached() {
  try {
    const cache = CacheService.getScriptCache();
    const cached = cache.get(PRODUCT_CACHE_KEY);
    if (cached) return JSON.parse(cached);
  } catch (e) {}
  const list = getNewProductsFromSheet();
  try {
    CacheService.getScriptCache().put(PRODUCT_CACHE_KEY, JSON.stringify(list), 300);
  } catch (e) {}
  return list;
}
function _invalidateProductCache() {
  try { CacheService.getScriptCache().remove(PRODUCT_CACHE_KEY); } catch (e) {}
}

function getNewProductsFromSheet() {
  try {
    const sh = _sheet('SanPham', SP_HEADERS);
    _ensureMasterProducts(sh);
    const data = sh.getDataRange().getValues();
    if (data.length <= 1) return [];
    return data.slice(1).filter(r => r[0]).map(r => ({
      id: r[0].toString().toUpperCase(), name: r[1].toString(), img: (r[2] || '').toString(),
      normal: Number(r[3]) || 0, si_menu: Number(r[4]) || 0, shopee: Number(r[5]) || 0,
      si_cua_hang: Number(r[6]) || 0, si_khanh_quyen: Number(r[7]) || 0,
      si_200_400: Number(r[8]) || 0, si_400_600: Number(r[9]) || 0, si_600: Number(r[10]) || 0,
      si_hoi_cho: Number(r[11]) || 0, si_hoi_cho_TM: Number(r[12]) || 0,
      detailName: (r[13] || '').toString(), category: (r[14] || '').toString(), isCustom: true
    }));
  } catch (e) { return []; }
}

// Danh sách danh mục hiện có (mặc định + phát sinh từ dữ liệu)
function getProductCategories() {
  try {
    const list = getProductsCached();
    const set = {};
    DEFAULT_CATEGORIES.forEach(c => set[c] = 1);
    list.forEach(p => { if (p.category) set[p.category] = 1; });
    return Object.keys(set);
  } catch (e) { return DEFAULT_CATEGORIES.slice(); }
}

function saveProductToSheet(p) {
  try {
    const sh = _sheet('SanPham', SP_HEADERS);
    const lastRow = sh.getLastRow();
    const ids = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 1).getValues() : [];
    _unmarkMasterDeleted_(p.id);
    const row = [
      p.id.toUpperCase(), p.name, p.img,
      Number(p.normal), Number(p.si_menu), Number(p.shopee),
      Number(p.si_cua_hang), Number(p.si_khanh_quyen), Number(p.si_200_400),
      Number(p.si_400_600), Number(p.si_600), Number(p.si_hoi_cho), Number(p.si_hoi_cho_TM),
      p.detailName || '', p.category || ''
    ];
    for (let i = 0; i < ids.length; i++) {
      if (ids[i][0].toString().toUpperCase() === p.id.toString().toUpperCase()) {
        sh.getRange(i + 2, 1).setNumberFormat('@'); // [FIX] giữ số 0 đầu nếu Mã SP toàn số
        sh.getRange(i + 2, 1, 1, row.length).setValues([row]);
        _invalidateProductCache();
        return 'Cập nhật sản phẩm thành công!';
      }
    }
    sh.getRange(sh.getLastRow() + 1, 1).setNumberFormat('@');
    sh.appendRow(row);
    _invalidateProductCache();
    return 'Thêm sản phẩm mới thành công!';
  } catch (e) { return 'Lỗi xử lý sản phẩm: ' + e.toString(); }
}

function deleteProductFromSheet(id) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return 'Hệ thống đang bận, thử lại sau.'; }
  try {
    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('SanPham');
    if (!sh) return 'Không tìm thấy dữ liệu Sheet.';
    const key = (id || '').toString().trim().toUpperCase();
    if (!key) return 'Thiếu mã sản phẩm.';
    const lastRow = sh.getLastRow();
    const ids = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 1).getValues() : [];
    // [FIX] Xóa TẤT CẢ dòng trùng mã, duyệt từ dưới lên để không lệch chỉ số dòng
    let deleted = 0;
    for (let i = ids.length - 1; i >= 0; i--) {
      if (ids[i][0].toString().trim().toUpperCase() === key) {
        sh.deleteRow(i + 2);
        deleted++;
      }
    }
    _markMasterDeleted_(key);
    _invalidateProductCache();
    SpreadsheetApp.flush();
    if (!deleted) return 'Không tìm thấy mã "' + key + '" trong sheet SanPham (có thể đã xóa trước đó).';
    return 'Đã xóa sản phẩm thành công!' + (deleted > 1 ? ' (đã dọn ' + deleted + ' dòng trùng mã)' : '');
  } catch (e) { return 'Lỗi xóa sản phẩm: ' + e.toString(); }
  finally { lock.releaseLock(); }
}

// Chạy tay 1 lần trong Apps Script editor để dọn các dòng trùng mã đang có sẵn (giữ dòng đầu tiên)
function cleanDuplicateProducts() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('SanPham');
  if (!sh || sh.getLastRow() < 2) return 'Không có dữ liệu.';
  const ids = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues();
  const firstIdx = {};
  ids.forEach((r, i) => {
    const k = r[0].toString().trim().toUpperCase();
    if (k && firstIdx[k] === undefined) firstIdx[k] = i;
  });
  let removed = 0;
  for (let i = ids.length - 1; i >= 0; i--) {   // duyệt từ dưới lên
    const k = ids[i][0].toString().trim().toUpperCase();
    if (k && firstIdx[k] !== i) { sh.deleteRow(i + 2); removed++; }
  }
  _invalidateProductCache();
  return 'Đã xóa ' + removed + ' dòng trùng mã.';
}

// ════════════════════════════════════════════════════════════
//  UPLOAD ẢNH SẢN PHẨM TRỰC TIẾP LÊN DRIVE
// ════════════════════════════════════════════════════════════
function _getOrCreateImageFolder() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('imgFolderId');
  if (id) {
    try { return DriveApp.getFolderById(id); } catch (e) { /* đã bị xóa, tạo lại */ }
  }
  const folder = DriveApp.createFolder('9Sach_HinhAnhSanPham');
  props.setProperty('imgFolderId', folder.getId());
  return folder;
}

function uploadProductImage(base64Data, mimeType, fileName) {
  try {
    if (!base64Data) return { success: false, error: 'Không có dữ liệu ảnh.' };
    const folder = _getOrCreateImageFolder();
    const bytes = Utilities.base64Decode(base64Data);
    const safeName = (fileName || ('sp_' + new Date().getTime())).toString().replace(/[^\w.\-]/g, '_');
    const blob = Utilities.newBlob(bytes, mimeType || 'image/jpeg', safeName);
    const file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    const url = 'https://lh3.googleusercontent.com/d/' + file.getId();
    return { success: true, url: url, fileId: file.getId() };
  } catch (e) {
    return { success: false, error: e.toString() };
  }
}

// ════════════════════════════════════════════════════════════
//  ĐƠN HÀNG
// ════════════════════════════════════════════════════════════
const DH_HEADERS = [
  'Ngày đặt', 'Tên Khách', 'SĐT', 'Địa chỉ', 'Sản phẩm (mã)', 'Số lượng', 'Giá trị', 'Loại giá',
  'Ghi chú', 'Mã số thuế', 'Tên công ty', 'COPPY', 'Tên SP', '', 'Tên đầy đủ SP', 'nguồn', '&',
  'Giá', 'Nhân viên', 'Giá trị', 'Trạng Thái', 'Ghi Chú Trạng Thái', 'Tên Xuất Hóa Đơn', 'Người Duyệt', 'Thời Gian Duyệt'
];
const COL_STATUS = 21;
const COL_STATUS_NOTE = 22;
const READ_WIDTH = 25; // A..W như cũ + X (Người Duyệt) + Y (Thời Gian Duyệt)

// [TỐC ĐỘ] Đổi số cột -> chữ cột A1 (để gom nhiều lần setNumberFormat thành 1 lệnh duy nhất)
function _a1Col_(n) {
  let s = '';
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

function _donHangSheet() {
  const sh = _sheet('DonHang', DH_HEADERS);
  // [DUYỆT ĐƠN] đảm bảo sheet có đủ cột X (24) và Y (25) + tiêu đề
  // [TỐC ĐỘ] chỉ kiểm tra 1 lần mỗi 6 giờ (cache) thay vì mỗi lần ghi đơn
  let okXY = false;
  try { okXY = CacheService.getScriptCache().get('DH_XY_OK') === '1'; } catch (e0) {}
  if (!okXY) {
    try {
      if (sh.getMaxColumns() < 25) sh.insertColumnsAfter(sh.getMaxColumns(), 25 - sh.getMaxColumns());
      if (sh.getRange(1, 24).getValue() !== 'Người Duyệt') sh.getRange(1, 24, 1, 2).setValues([['Người Duyệt', 'Thời Gian Duyệt']]);
      try { CacheService.getScriptCache().put('DH_XY_OK', '1', 21600); } catch (e1) {}
    } catch (e) {}
  }
  return sh;
}

function _sanitizeNote(note) {
  if (!note) return '';
  const s = note.toString();
  const looksLikeReceiptEcho =
    /^\s*Ngày:\s*\d{1,2}\/\d{1,2}\/\d{4}[\s\S]*Tên:/i.test(s) ||
    s.indexOf('\nSản phẩm:\n') !== -1 || s.indexOf('Sản phẩm:\n') === 0;
  if (looksLikeReceiptEcho) return '';
  return s.length > 500 ? s.slice(0, 500) + ' …(đã rút gọn)' : s;
}

function _appendOrderRows(sh, data) {
  const n = data.cartDetails.length;
  if (!n) return true;

  let timestamp = new Date();
  if (data.orderDate) {
    const d = new Date(data.orderDate);
    if (!isNaN(d.getTime())) timestamp = d;
  }
  const empName = data.employeeName ? data.employeeName.toString().trim() : '';
  const phoneStr = (data.phone || '').toString().trim();
  const noteClean = _sanitizeNote(data.note);
  const startRow = sh.getLastRow() + 1;

  const blockAK = data.cartDetails.map((item, index) => {
    const row = new Array(11).fill('');
    if (index === 0) {
      row[0] = timestamp; row[1] = data.name; row[2] = phoneStr; row[3] = data.address;
      row[7] = data.priceType; row[8] = noteClean; row[9] = data.taxCode; row[10] = data.company;
    }
    row[4] = item.name + ' (' + item.id + ')';
    row[5] = item.qty;
    row[6] = item.price * item.qty;
    return row;
  });

  const blockO = data.cartDetails.map(item => [(item.detailName && item.detailName.trim()) || item.name]);
  const blockS = data.cartDetails.map((item, index) => [index === 0 ? empName : '']);
  const blockInvoice = data.cartDetails.map((item, index) => [index === 0 ? (data.invoiceName || '') : '']);

  // [FIX] ép VĂN BẢN mọi cột chữ: B tên, C SĐT, D địa chỉ, H loại giá, I ghi chú, J MST, K công ty, O tên chi tiết, S nhân viên, W tên hóa đơn.
  // Trước đây chỉ ép C và J nên ghi chú như "1/2", "3-4" bị Sheets đổi thành NGÀY (làm trang Lịch Sử trả rỗng).
  sh.getRangeList([2, 3, 4, 8, 9, 10, 11, 15, 19, 23].map(function (c) { return _a1Col_(c) + startRow + ':' + _a1Col_(c) + (startRow + n - 1); })).setNumberFormat('@');
  sh.getRange(startRow, 1, n, 11).setValues(blockAK);
  sh.getRange(startRow, 15, n, 1).setValues(blockO);
  sh.getRange(startRow, 19, n, 1).setValues(blockS);
  sh.getRange(startRow, 23, n, 1).setValues(blockInvoice);   // ← thêm dòng này

  return true;
}


function _cancelOrderRows(sh, startRow, rowCount, noteText) {
  const n = Math.max(1, parseInt(rowCount) || 1);
  const statusValues = []; const noteValues = [];
  for (let i = 0; i < n; i++) { statusValues.push(['Huy']); noteValues.push([noteText || 'Đã hủy']); }
  sh.getRange(startRow, COL_STATUS, n, 1).setValues(statusValues);
  sh.getRange(startRow, COL_STATUS_NOTE, n, 1).setValues(noteValues);
  const rngFmt = sh.getRange(startRow, 1, n, COL_STATUS_NOTE);
  rngFmt.setBackground('#fde2e2');
  try { rngFmt.setFontLine('line-through'); } catch (e) {}
}
function cancelOrderRows(startRow, rowCount) {
  try { _cancelOrderRows(_donHangSheet(), startRow, rowCount, 'Đã hủy'); return true; } catch (e) { return false; }
}

// [MỚI] Sửa nhanh NGÀY GHI NHẬN DOANH THU của 1 đơn hàng đang hoạt động
// (không hủy, không tạo đơn mới, không đụng sản phẩm/khách hàng) - đồng
// thời di chuyển đúng doanh thu/số lượng sang tháng mới trong TongHopThang.
function updateOrderDate(startRow, rowCount, newDateStr, fp) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _donHangSheet();
    const row = parseInt(startRow);
    const chk = _wgCheckBlock_(sh, startRow, rowCount, fp);
    if (!chk.ok) return { success: false, error: chk.error };
    const status = (sh.getRange(row, COL_STATUS).getValue() || '').toString();
    if (status === 'Huy') return { success: false, error: 'Đơn hàng này đã bị hủy, không thể sửa ngày.' };

    const n = Math.max(1, parseInt(rowCount) || 1);
    const totals = _readOrderBlockTotals(sh, row, n);
    if (!totals) return { success: false, error: 'Không đọc được dữ liệu đơn hàng.' };

    const newDate = new Date(newDateStr);
    if (isNaN(newDate.getTime())) return { success: false, error: 'Ngày không hợp lệ.' };
    if (_wgMonthLocked_(newDate)) return { success: false, error: WG_MSG_MONTH_LOCKED };   // [GĐ4]

    const oldCounted = _isBlockCounted(sh, row);
    sh.getRange(row, 1).setValue(newDate);
    const newCounted = _isBlockCounted(sh, row);

    try {
      if (oldCounted) _tongHopApplyDelta(totals.date, -totals.revenue, -1, -totals.qty, totals.phone);
      if (newCounted) _tongHopApplyDelta(newDate, totals.revenue, 1, totals.qty, totals.phone);
    } catch (e2) { /* không chặn luồng chính nếu lỗi ghi tổng hợp */ }

    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

// ════════════════════════════════════════════════════════════
//  KHÁCH HÀNG
// ════════════════════════════════════════════════════════════
const DKS_HEADERS = [
  'Tên khách hàng', 'SĐT', 'Địa chỉ', 'Cột 4', 'Cột 5', 'Cột 6', 'Cột 7', 'Cột 8',
  'Ngày đặt đầu', 'Ngày đặt cuối', 'Cột 11', 'Cột 12', 'Cột 13', 'Cột 14', 'Cột 15',
  'Loại Khách Sỉ', 'Mã số thuế', 'Tên công ty', 'Phân Loại Thủ Công',
  'Tên Xuất Hóa Đơn', 'CCCD', 'Diễn Giải',
  'Mã Khách Hàng', 'Xưởng', 'Mã Tỉnh', 'Nhóm KH', 'Mã Cũ', 'Email'
];
 
function _dataKhachSiSheet() {
  const sh = _sheet('DataKhachSi', DKS_HEADERS);
  if (sh.getMaxColumns() < DKS_TOTAL_COLS) {
    sh.insertColumnsAfter(sh.getMaxColumns(), DKS_TOTAL_COLS - sh.getMaxColumns());
  }
  // Cột 20 -> 27: Tên Xuất HĐ, CCCD, Diễn Giải, Mã KH, Xưởng, Mã Tỉnh, Nhóm KH, Mã Cũ
  const want = DKS_HEADERS.slice(19);
  const have = sh.getRange(1, 20, 1, want.length).getValues()[0];
  let ok = true;
  for (let i = 0; i < want.length; i++) { if (have[i] !== want[i]) { ok = false; break; } }
  if (!ok) {
    sh.getRange(1, 20, 1, want.length).setValues([want]);
    // Mã KH / Mã cũ luôn là văn bản
    sh.getRange(2, DKS_COL.CODE, Math.max(1, sh.getMaxRows() - 1), 1).setNumberFormat('@');
    sh.getRange(2, DKS_COL.OLD_CODE, Math.max(1, sh.getMaxRows() - 1), 1).setNumberFormat('@');
  }
  return sh;
}
const DKS_COL = { NAME:1, PHONE:2, ADDRESS:3, FIRST_ORDER:9, LAST_ORDER:10, LOAI_KHACH_SI:16, TAX:17, COMPANY:18, INVOICE_NAME:20, CCCD:21, DESCRIPTION:22,
  CODE:23, FACTORY:24, PROV:25, GROUP:26, OLD_CODE:27, EMAIL:28 };
const DKS_COL_MANUAL_SEG = 19; // 'Cu' / 'Moi' / '' (rỗng = tự động theo 30 ngày)
const DKS_TOTAL_COLS = 28;   // [v9] thêm cột 28 = Email (cột cuối, không làm lệch các cột cũ)

// [MỚI] Chuẩn hóa email: không hợp lệ -> '' (email để trống được)
function _cleanEmail_(v) {
  const s = (v == null ? '' : v).toString().trim().toLowerCase();
  return /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(s) ? s : '';
}

// Một số dòng dữ liệu cũ trong DataKhachSi bị dính nhầm link ảnh (do
// copy/paste sai) vào đúng cột Tên khách hàng, khiến ô "Tên khách hàng"
// trên form hiện ra một đường link thay vì tên thật. Hàm này chặn không cho
// giá trị "trông giống URL" (bắt đầu bằng http) tự động điền lên form nữa.
function _looksLikeUrl(v) {
  return /^https?:\/\//i.test((v || '').toString().trim());
}
function _stripDiacriticsServer(str) {
  return (str || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase();
}

// [NÂNG CẤP] Tìm khách hàng theo TỪNG CHỮ (không cần dấu, không cần đúng thứ tự):
// khớp trên Tên + Mã KH + Mã cũ + Diễn giải + SĐT + Địa chỉ + Tên xuất HĐ + Công ty + MST + CCCD.
function searchCustomersByName(query) {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh || sh.getLastRow() < 2) return [];
    const toks = _stripDiacriticsServer(query || '').split(/\s+/).filter(Boolean);
    if (!toks.length) return [];
    const data = sh.getRange(2, 1, sh.getLastRow() - 1, DKS_TOTAL_COLS).getValues();
    const results = [];
    for (let i = 0; i < data.length; i++) {
      const r = data[i];
      const name = (r[DKS_COL.NAME - 1] || '').toString();
      if (!name || _looksLikeUrl(name)) continue;
      const hay = _stripDiacriticsServer([
        name, r[DKS_COL.CODE - 1], r[DKS_COL.OLD_CODE - 1], r[DKS_COL.DESCRIPTION - 1],
        r[DKS_COL.PHONE - 1], r[DKS_COL.ADDRESS - 1], r[DKS_COL.INVOICE_NAME - 1],
        r[DKS_COL.COMPANY - 1], r[DKS_COL.TAX - 1], r[DKS_COL.CCCD - 1], r[DKS_COL.EMAIL - 1]
      ].join(' '));
      let ok = true;
      for (let t = 0; t < toks.length; t++) { if (hay.indexOf(toks[t]) === -1) { ok = false; break; } }
      if (!ok) continue;
      results.push({
        name: name,
        phone: (r[DKS_COL.PHONE - 1] || '').toString(),
        address: (r[DKS_COL.ADDRESS - 1] || '').toString(),
        customerType: (r[DKS_COL.LOAI_KHACH_SI - 1] || '').toString(),
        taxCode: (r[DKS_COL.TAX - 1] || '').toString(),
        company: (r[DKS_COL.COMPANY - 1] || '').toString(),
        invoiceName: (r[DKS_COL.INVOICE_NAME - 1] || '').toString(),
        cccd: (r[DKS_COL.CCCD - 1] || '').toString(),
        email: (r[DKS_COL.EMAIL - 1] || '').toString(),
        code: (r[DKS_COL.CODE - 1] || '').toString(),
        group: (r[DKS_COL.GROUP - 1] || '').toString(),
        factory: (r[DKS_COL.FACTORY - 1] || '').toString(),
        description: (r[DKS_COL.DESCRIPTION - 1] || '').toString()
      });
      if (results.length >= 15) break;
    }
    return results;
  } catch (e) { return []; }
}

// [MỚI v7.3] Gợi ý khách cho GIỎ HÀNG theo MÃ KH hoặc TÊN (không dấu, từng chữ, không cần đúng thứ tự).
// CHỈ trả khách ĐÃ CÓ MÃ - khách chưa có mã bị loại hẳn khỏi gợi ý. Ưu tiên: mã bắt đầu bằng chữ đã gõ > mã chứa > tên bắt đầu > còn lại.
function searchCustomersWithCode(query) {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh || sh.getLastRow() < 2) return [];
    const q = _stripDiacriticsServer(query || '').trim();
    const toks = q.split(/\s+/).filter(Boolean);
    if (!toks.length) return [];
    const qNoSpace = q.replace(/\s+/g, '');
    const data = sh.getRange(2, 1, sh.getLastRow() - 1, DKS_TOTAL_COLS).getValues();
    const found = [];
    for (let i = 0; i < data.length; i++) {
      const r = data[i];
      const code = _normCode_(r[DKS_COL.CODE - 1]);
      if (!code) continue;                                   // loại hẳn khách chưa có mã
      const name = (r[DKS_COL.NAME - 1] || '').toString();
      if (!name || _looksLikeUrl(name)) continue;
      const codeKey = _stripDiacriticsServer(code).replace(/\s+/g, '');
      const nameKey = _stripDiacriticsServer(name);
      const hay = _stripDiacriticsServer([
        name, code, r[DKS_COL.OLD_CODE - 1], r[DKS_COL.DESCRIPTION - 1], r[DKS_COL.PHONE - 1], r[DKS_COL.ADDRESS - 1],
        r[DKS_COL.INVOICE_NAME - 1], r[DKS_COL.COMPANY - 1], r[DKS_COL.TAX - 1], r[DKS_COL.CCCD - 1], r[DKS_COL.EMAIL - 1]
      ].join(' '));
      let ok = true;
      for (let t = 0; t < toks.length; t++) { if (hay.indexOf(toks[t]) === -1) { ok = false; break; } }
      if (!ok) continue;
      const rank = codeKey.indexOf(qNoSpace) === 0 ? 0 : (codeKey.indexOf(qNoSpace) > 0 ? 1 : (nameKey.indexOf(q) === 0 ? 2 : 3));
      found.push({
        rank: rank, code: code,
        item: {
          name: name,
          phone: (r[DKS_COL.PHONE - 1] || '').toString(),
          address: (r[DKS_COL.ADDRESS - 1] || '').toString(),
          customerType: (r[DKS_COL.LOAI_KHACH_SI - 1] || '').toString(),
          taxCode: (r[DKS_COL.TAX - 1] || '').toString(),
          company: (r[DKS_COL.COMPANY - 1] || '').toString(),
          invoiceName: (r[DKS_COL.INVOICE_NAME - 1] || '').toString(),
          cccd: (r[DKS_COL.CCCD - 1] || '').toString(),
          email: (r[DKS_COL.EMAIL - 1] || '').toString(),
          code: code,
          group: (r[DKS_COL.GROUP - 1] || '').toString(),
          factory: (r[DKS_COL.FACTORY - 1] || '').toString(),
          description: (r[DKS_COL.DESCRIPTION - 1] || '').toString()
        }
      });
    }
    found.sort(function (a, b) { return a.rank - b.rank || (a.code < b.code ? -1 : (a.code > b.code ? 1 : 0)); });
    const out = found.slice(0, 15).map(function (x) { return x.item; });
    // [MỚI] thêm khách mới đang chờ duyệt (đánh dấu pending) để vẫn lên đơn tiếp được
    try { _pendSearch_(query).forEach(function (p) { if (!out.some(function (o) { return o.code === p.code; })) out.push(p); }); } catch (e) {}
    return out;
  } catch (e) { return []; }
}

// [SỬA v7.3] Tra theo SĐT: CHỈ trả khách ĐÃ CÓ MÃ. Khách chưa có mã coi như không tồn tại (không trả thông tin).
function findCustomerByPhone(phone) {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh) return null;
    const data = sh.getDataRange().getValues();
    const search = phone.toString().replace(/[^0-9]/g, '');
    if (!search) return null;
    for (let i = 1; i < data.length; i++) {
      if ((data[i][1] || '').toString().replace(/[^0-9]/g, '') !== search) continue;
      const code = (data[i][DKS_COL.CODE - 1] || '').toString().trim();
      if (!code) continue;                                   // bỏ qua khách chưa có mã
      const rawName = data[i][0] || '';
      return {
        name: _looksLikeUrl(rawName) ? '' : rawName,
        address: data[i][2] || '',
        customerType: data[i][DKS_COL.LOAI_KHACH_SI - 1] || '',
        taxCode: (data[i][DKS_COL.TAX - 1] || '').toString().trim(),
        company: (data[i][DKS_COL.COMPANY - 1] || '').toString().trim(),
        invoiceName: (data[i][DKS_COL.INVOICE_NAME - 1] || '').toString().trim(),
        cccd: (data[i][DKS_COL.CCCD - 1] || '').toString().trim(),
        email: (data[i][DKS_COL.EMAIL - 1] || '').toString().trim(),
        code: code,
        group: (data[i][DKS_COL.GROUP - 1] || '').toString().trim(),
        nameLooksCorrupted: _looksLikeUrl(rawName)
      };
    }
    return null;
  } catch (e) { return null; }
}

// TIỆN ÍCH DỌN DẸP - chạy tay 1 lần từ Apps Script Editor để xóa các ô
// "Tên khách hàng" trong DataKhachSi đang bị dính link ảnh thay vì tên thật
// (không tự động chạy, không gọi từ client).
function repairDataKhachSiCorruptedNames() {
  const sh = _dataKhachSiSheet();
  if (!sh || sh.getLastRow() < 2) { Logger.log('Không có dữ liệu.'); return; }
  const lastRow = sh.getLastRow();
  const rng = sh.getRange(2, 1, lastRow - 1, 1);
  const values = rng.getValues();
  let fixed = 0;
  const log = [];
  const out = values.map((r, idx) => {
    const v = (r[0] || '').toString();
    if (_looksLikeUrl(v)) {
      fixed++;
      log.push('Dòng ' + (idx + 2) + ': "' + v.slice(0, 60) + '..." -> đã xóa');
      return [''];
    }
    return [v];
  });
  rng.setValues(out);
  Logger.log('Đã dọn ' + fixed + ' ô Tên khách hàng bị dính link trong DataKhachSi (cột A).');
  log.forEach(l => Logger.log(l));
}

// [NÂNG CẤP] Lưu / cập nhật khách sỉ khi tạo đơn. Trả về MÃ KHÁCH HÀNG (chuỗi, rỗng nếu chưa tạo được).
// Thứ tự nhận diện khách: (1) theo Mã KH, (2) theo SĐT. Khách import từ file mới có thể chưa có SĐT -> nhận theo mã.
// extra = { customerCode, codeGroup, codeFactory, cccd, email }
function _saveNewCustomerInternal(name, phone, address, customerType, city, taxCode, companyName, invoiceName, extra) {
  extra = extra || {};
  const sh = _dataKhachSiSheet();
  if (!sh) return '';
  const pc = (phone || '').toString().replace(/[^0-9]/g, '');
  const inCode = _normCode_(extra.customerCode);
  if (!pc && !inCode) return '';
  const today = new Date();
  const lastRow = sh.getLastRow();
  const WIDTH = DKS_TOTAL_COLS;
  // [TỐC ĐỘ] chỉ đọc 2 cột Mã + SĐT để tìm khách (không đọc cả bảng); khi cần cập nhật mới đọc đúng 1 dòng
  const nRows = lastRow > 1 ? lastRow - 1 : 0;
  const codeCol = nRows ? sh.getRange(2, DKS_COL.CODE, nRows, 1).getValues() : [];
  const phoneCol = nRows ? sh.getRange(2, DKS_COL.PHONE, nRows, 1).getValues() : [];

  let idx = -1;
  if (inCode) {
    for (let i = 0; i < codeCol.length; i++) {
      if (_normCode_(codeCol[i][0]) === inCode) { idx = i; break; }
    }
  }
  if (idx < 0 && pc) {
    for (let i = 0; i < phoneCol.length; i++) {
      const rowPhone = (phoneCol[i][0] || '').toString().replace(/[^0-9]/g, '');
      if (rowPhone === pc) { idx = i; break; }
    }
  }
  if (idx < 0 && !pc) return '';   // có mã nhưng mã không còn trong sheet và không có SĐT -> không tạo dòng rỗng

  const allCodes = codeCol.map(r => r[0]);

  if (idx >= 0) {
    const row = sh.getRange(idx + 2, 1, 1, WIDTH).getValues()[0];
    row[DKS_COL.NAME - 1] = name;
    row[DKS_COL.ADDRESS - 1] = address;
    row[DKS_COL.LAST_ORDER - 1] = today;
    if (!row[DKS_COL.FIRST_ORDER - 1]) row[DKS_COL.FIRST_ORDER - 1] = today;
    if (pc && !(row[DKS_COL.PHONE - 1] || '').toString().replace(/[^0-9]/g, '')) row[DKS_COL.PHONE - 1] = pc;
    if (customerType) row[DKS_COL.LOAI_KHACH_SI - 1] = customerType;
    if (taxCode) row[DKS_COL.TAX - 1] = taxCode;
    if (companyName) row[DKS_COL.COMPANY - 1] = companyName;
    if (invoiceName) row[DKS_COL.INVOICE_NAME - 1] = invoiceName;
    if (extra.cccd) row[DKS_COL.CCCD - 1] = extra.cccd;
    if (_cleanEmail_(extra.email)) row[DKS_COL.EMAIL - 1] = _cleanEmail_(extra.email);   // email: có thì lưu, để trống thì giữ email cũ
    // Khách cũ chưa có mã -> cấp mã mới theo quy định
    if (!_normCode_(row[DKS_COL.CODE - 1]) && extra.codeGroup) {
      const gen = _generateCode_(allCodes, extra.codeGroup, extra.codeFactory, city, address);
      if (gen.code) {
        row[DKS_COL.CODE - 1] = gen.code; row[DKS_COL.FACTORY - 1] = gen.factory;
        row[DKS_COL.PROV - 1] = gen.prov; row[DKS_COL.GROUP - 1] = gen.group;
      }
    }
    const r1 = idx + 2;
    sh.getRangeList([_a1Col_(DKS_COL.PHONE) + r1, _a1Col_(DKS_COL.TAX) + r1, _a1Col_(DKS_COL.CCCD) + r1, _a1Col_(DKS_COL.CODE) + r1]).setNumberFormat('@');
    sh.getRange(r1, 1, 1, WIDTH).setValues([row]);
    return (row[DKS_COL.CODE - 1] || '').toString();
  }

  const newRow = sh.getLastRow() + 1;
  const arr = new Array(WIDTH).fill('');
  arr[DKS_COL.NAME - 1] = name;
  arr[DKS_COL.PHONE - 1] = pc;
  arr[DKS_COL.ADDRESS - 1] = address;
  arr[DKS_COL.FIRST_ORDER - 1] = today;
  arr[DKS_COL.LAST_ORDER - 1] = today;
  if (customerType) arr[DKS_COL.LOAI_KHACH_SI - 1] = customerType;
  if (taxCode) arr[DKS_COL.TAX - 1] = taxCode;
  if (companyName) arr[DKS_COL.COMPANY - 1] = companyName;
  if (invoiceName) arr[DKS_COL.INVOICE_NAME - 1] = invoiceName;
  if (extra.cccd) arr[DKS_COL.CCCD - 1] = extra.cccd;
  if (_cleanEmail_(extra.email)) arr[DKS_COL.EMAIL - 1] = _cleanEmail_(extra.email);
  if (extra.codeGroup) {
    const gen = _generateCode_(allCodes, extra.codeGroup, extra.codeFactory, city, address);
    if (gen.code) {
      arr[DKS_COL.CODE - 1] = gen.code; arr[DKS_COL.FACTORY - 1] = gen.factory;
      arr[DKS_COL.PROV - 1] = gen.prov; arr[DKS_COL.GROUP - 1] = gen.group;
    }
  }
  sh.getRangeList([_a1Col_(DKS_COL.PHONE) + newRow, _a1Col_(DKS_COL.TAX) + newRow, _a1Col_(DKS_COL.CCCD) + newRow, _a1Col_(DKS_COL.CODE) + newRow]).setNumberFormat('@');
  sh.getRange(newRow, 1, 1, WIDTH).setValues([arr]);
  return (arr[DKS_COL.CODE - 1] || '').toString();
}

// ════════════════════════════════════════════════════════════
//  ĐỌC + GOM ĐƠN HÀNG THEO NGÀY
// ════════════════════════════════════════════════════════════
const _READ_CHUNK = 1000;

// countedOnly = true: chỉ lấy các đơn ĐƯỢC TÍNH doanh thu/KPI (đơn trước 01/10/2026, hoặc đơn từ 01/10/2026 đã được duyệt).
// countedOnly rỗng/false: lấy toàn bộ đơn như cũ (lịch sử, tra cứu, sao chép...).
function _readDonHangGrouped(fromDate, toDate, empFilter, countedOnly) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!sh || sh.getLastRow() < 2) return [];
  const lastRow = sh.getLastRow();

  const from = fromDate ? new Date(fromDate) : null;
  const to = toDate ? new Date(toDate) : null;
  if (to) to.setHours(23, 59, 59, 999);
  const empSet = (empFilter && empFilter.length) ? empFilter.map(e => (e || '').toString().toLowerCase()) : null;

  let data;
  if (false) {   // [SỬA] tắt dừng-quét-sớm: nó bỏ sót đơn khi các dòng không xếp đúng thứ tự ngày; đọc toàn bộ cho chắc
    let collected = [];
    let cursor = lastRow;
    let doneScanning = false;
    while (cursor >= 2 && !doneScanning) {
      const chunkStart = Math.max(2, cursor - _READ_CHUNK + 1);
      const chunk = sh.getRange(chunkStart, 1, cursor - chunkStart + 1, READ_WIDTH).getValues();
      collected = chunk.concat(collected);
      for (let i = 0; i < chunk.length; i++) {
        if (chunk[i][0] && chunk[i][0] !== '') {
          const d = chunk[i][0] instanceof Date ? chunk[i][0] : new Date(chunk[i][0]);
          if (d < from) { doneScanning = true; break; }
        }
      }
      cursor = chunkStart - 1;
    }
    data = collected;
  } else {
    data = sh.getRange(2, 1, lastRow - 1, READ_WIDTH).getValues();
  }

  let startRowOfData = lastRow - data.length + 1;
  // [LƯU TRỮ] bổ sung tháng cũ đã lưu trữ (chỉ khi tháng đó KHÔNG còn ở sheet chính => không bao giờ đếm trùng)
  let _archN = 0;
  try {
    if (typeof _ldExtraRows_ === 'function') {
      const ex = _ldExtraRows_(from, to);
      if (ex.rows.length) { data = ex.rows.concat(data); _archN = ex.rows.length; }
    }
  } catch (eA) { Logger.log('Lỗi đọc lưu trữ: ' + eA); throw eA; }   // lỗi thì báo rõ, không âm thầm đọc thiếu

  const orders = [];
  let cur = null, curSkip = false;
  data.forEach((r, idx) => {
    if (r[0] && r[0] !== '') {
      curSkip = (r[COL_STATUS - 1] || '') === 'Huy';
      if (!curSkip) {
        const d = r[0] instanceof Date ? r[0] : new Date(r[0]);
        if ((from && d < from) || (to && d > to)) { curSkip = true; cur = null; return; }
        const emp = (r[18] || '').toString();
        if (empSet && !empSet.includes(emp.toLowerCase())) { curSkip = true; cur = null; return; }
        const approvedByRaw = (r[23] || '').toString().trim();
        const needsAppr = _orderNeedsApproval(d);
        const apprProblem = (needsAppr && approvedByRaw) ? _approvalProblem_(approvedByRaw, r[24]) : '';
        const approvedBy = apprProblem ? '' : approvedByRaw;   // duyệt không hợp lệ = CHƯA duyệt (web sẽ hiện "Chờ duyệt" + nút Duyệt)
        const approvedAt = apprProblem ? '' : (r[24] instanceof Date ? r[24].toISOString() : (r[24] || ''));
        const counted = !needsAppr || !!approvedBy;
        if (countedOnly && !counted) { curSkip = true; cur = null; return; }
        cur = {
          date: d.toISOString(), name: _hsv_(r[1] || ''), phone: _hsv_(r[2] || ''), address: _hsv_(r[3] || ''),
          priceType: _hsv_(r[7] || ''), emp: emp, note: _hsv_(r[8] || ''), taxCode: _hsv_(r[9] || ''), company: _hsv_(r[10] || ''),
          invoiceName: _hsv_(r[22] || ''),
          approvedBy: approvedBy, approvedAt: approvedAt, needsApproval: needsAppr, counted: counted, approvalProblem: apprProblem,   // ← thêm dòng này (cột 23, index 22)
          items: [], total: 0, sheetStartRow: idx < _archN ? -(idx + 1) : startRowOfData + (idx - _archN), archived: idx < _archN
        };
        orders.push(cur);
        // KHÔNG return ở đây nữa - để dòng này rơi xuống xử lý sản phẩm bên dưới
      } else {
        cur = null;
        return;
      }
    }
    if (curSkip || !cur) return;
    const val = Number(r[6]) || 0, qty = Number(r[5]) || 0;
    const rawCell = (r[4] || '').toString();               // dạng "Tên SP (MÃ)" luôn cố định, không đổi
    const idMatch = rawCell.match(/\(([^)]+)\)\s*$/);
    const prodId = idMatch ? idMatch[1] : '';               // [MỚI] lấy đúng Mã SP thật
    const prodName = r[14] ? r[14].toString() : rawCell;
    cur.total += val;
    cur.items.push({ name: prodName, qty: qty, price: val, unitPrice: qty ? Math.round(val / qty) : 0, id: prodId });
  });

  return orders;
}

// ════════════════════════════════════════════════════════════
//  LỊCH SỬ ĐƠN HÀNG
//  [v6.1] empFilter giờ nhận MẢNG tên nhân viên (chọn nhiều cùng lúc ở
//  trang Lịch Sử). Vẫn tương thích ngược nếu client cũ gửi 1 string.
// ════════════════════════════════════════════════════════════
function getHistoryPage(fromDate, toDate, empFilter, searchStr, countedOnly) {
  try {
    let empArr = null;
    if (empFilter) {
      empArr = Array.isArray(empFilter) ? empFilter.filter(Boolean) : [empFilter];
      if (!empArr.length) empArr = null;
    }
    let orders = _readDonHangGrouped(fromDate, toDate, empArr, !!countedOnly);
    if (searchStr) {
      const s = searchStr.toString().toLowerCase();
      orders = orders.filter(o => (o.name || '').toLowerCase().indexOf(s) !== -1 || (o.phone || '').toString().indexOf(s) !== -1);
    }
    const totalRev = orders.reduce((a, o) => a + o.total, 0);
    return { orders: orders, totalRev: totalRev, count: orders.length };
  } catch (e) {
    return { orders: [], totalRev: 0, count: 0, error: e.toString() };
  }
}

function getHistoryEmployees() {
  try {
    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
    if (!sh || sh.getLastRow() < 2) return [];
    let data = sh.getRange(2, 19, sh.getLastRow() - 1, 4).getValues();
    try { if (typeof _ldExtraRows_ === 'function') data = _ldExtraRows_(null, null).rows.map(function (r) { return r.slice(18, 22); }).concat(data); } catch (eA) { Logger.log('Lỗi đọc lưu trữ: ' + eA); }
    const seen = {}; const out = [];
    data.forEach(r => {
      const emp = (r[0] || '').toString(); const st = (r[2] || '').toString();
      if (emp && st !== 'Huy' && !seen[emp]) { seen[emp] = 1; out.push(emp); }
    });
    return out;
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  DOANH THU
// ════════════════════════════════════════════════════════════
function getRevenueData(fromDate, toDate, employees) {
  try {
    const allOrders = _readDonHangGrouped(fromDate, toDate, null, true);
    const empMap = {};
    let systemTotal = 0;
    allOrders.forEach(o => {
      systemTotal += o.total;
      if (!empMap[o.emp]) empMap[o.emp] = { orders: 0, qty: 0, total: 0 };
      empMap[o.emp].orders++;
      empMap[o.emp].total += o.total;
      empMap[o.emp].qty += o.items.reduce((a, it) => a + it.qty, 0);
    });
    const keys = (employees && employees.length) ? employees : Object.keys(empMap);
    let filtTotal = 0, filtOrders = 0, filtQty = 0;
    const table = keys.filter(k => empMap[k]).map(name => {
      const d = empMap[name];
      filtTotal += d.total; filtOrders += d.orders; filtQty += d.qty;
      return { name: name, orders: d.orders, total: d.total, qty: d.qty, pct: systemTotal ? (d.total / systemTotal * 100) : 0 };
    });
    return { table: table, total: filtTotal, orders: filtOrders, qty: filtQty, systemTotal: systemTotal };
  } catch (e) {
    return { table: [], total: 0, orders: 0, qty: 0, systemTotal: 0, error: e.toString() };
  }
}

// ════════════════════════════════════════════════════════════
//  PHÂN TÍCH CHI TIẾT
// ════════════════════════════════════════════════════════════
function getAnalytics(fromDate, toDate) {
  try {
    const orders = _readDonHangGrouped(fromDate, toDate, null, true);
    const byProduct = {};
    const byDay = {};
    const byPriceType = {};
    let totalRev = 0, totalQty = 0;

    orders.forEach(o => {
      totalRev += o.total;
      const day = Utilities.formatDate(new Date(o.date), Session.getScriptTimeZone(), 'dd/MM');
      if (!byDay[day]) byDay[day] = { orders: 0, total: 0 };
      byDay[day].orders++; byDay[day].total += o.total;

      if (!byPriceType[o.priceType]) byPriceType[o.priceType] = { orders: 0, total: 0 };
      byPriceType[o.priceType].orders++; byPriceType[o.priceType].total += o.total;

      o.items.forEach(it => {
        totalQty += it.qty;
        if (!byProduct[it.name]) byProduct[it.name] = { qty: 0, total: 0 };
        byProduct[it.name].qty += it.qty; byProduct[it.name].total += it.price;
      });
    });

    const topProducts = Object.keys(byProduct).map(name => ({ name: name, qty: byProduct[name].qty, total: byProduct[name].total }))
      .sort((a, b) => b.total - a.total).slice(0, 15);
    const dayStats = Object.keys(byDay).map(d => ({ day: d, orders: byDay[d].orders, total: byDay[d].total }));
    const priceTypeStats = Object.keys(byPriceType).map(k => ({ priceType: k, orders: byPriceType[k].orders, total: byPriceType[k].total }))
      .sort((a, b) => b.total - a.total);

    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
    let newCust = 0, returningCust = 0;
    if (sh && sh.getLastRow() > 1) {
      let all = sh.getRange(2, 1, sh.getLastRow() - 1, READ_WIDTH).getValues();
      try { if (typeof _ldExtraRows_ === 'function') all = _ldExtraRows_(null, null).rows.concat(all); } catch (eA) { Logger.log('Lỗi đọc lưu trữ: ' + eA); }
      const firstBuy = {};
      all.forEach(r => {
        if (r[0] && r[0] !== '' && (r[COL_STATUS - 1] || '') !== 'Huy') {
          const ph = (r[2] || '').toString().replace(/[^0-9]/g, '');
          const d = r[0] instanceof Date ? r[0] : new Date(r[0]);
          if (ph && (!firstBuy[ph] || d < firstBuy[ph])) firstBuy[ph] = d;
        }
      });
      const from = fromDate ? new Date(fromDate) : null;
      const seenInRange = {};
      orders.forEach(o => {
        const ph = (o.phone || '').toString().replace(/[^0-9]/g, '');
        if (!ph || seenInRange[ph]) return;
        seenInRange[ph] = 1;
        if (from && firstBuy[ph] && firstBuy[ph] >= from) newCust++; else returningCust++;
      });
    }

    return {
      totalRev: totalRev, totalOrders: orders.length, totalQty: totalQty,
      aov: orders.length ? Math.round(totalRev / orders.length) : 0,
      topProducts: topProducts, dayStats: dayStats, priceTypeStats: priceTypeStats,
      newCust: newCust, returningCust: returningCust
    };
  } catch (e) {
    return { error: e.toString() };
  }
}

// ════════════════════════════════════════════════════════════
//  BÁO CÁO TỔNG HỢP: theo khách sỉ, theo nhân viên, so sánh doanh thu
//  theo tháng (kèm % so với TB các tháng có dữ liệu)
// ════════════════════════════════════════════════════════════
function getSummaryReport(fromDate, toDate) {
  try {
    const orders = _readDonHangGrouped(fromDate, toDate, null, true);

    // Theo khách sỉ (gộp theo SĐT)
    const byCust = {};
    orders.forEach(o => {
      const key = (o.phone || o.name || 'Khách lẻ').toString();
      if (!byCust[key]) byCust[key] = { name: o.name, phone: o.phone, orders: 0, qty: 0, revenue: 0, products: {} };
      const c = byCust[key];
      c.orders++;
      c.revenue += o.total;
      o.items.forEach(it => {
        c.qty += it.qty;
        if (!c.products[it.name]) c.products[it.name] = { qty: 0, revenue: 0 };
        c.products[it.name].qty += it.qty;
        c.products[it.name].revenue += it.price;
      });
    });
    const byCustomer = Object.keys(byCust).map(k => {
      const c = byCust[k];
      return {
        name: c.name, phone: c.phone, orders: c.orders, qty: c.qty, revenue: c.revenue,
        products: Object.keys(c.products).map(pn => ({ name: pn, qty: c.products[pn].qty, revenue: c.products[pn].revenue }))
          .sort((a, b) => b.revenue - a.revenue)
      };
    }).sort((a, b) => b.revenue - a.revenue);

    // Theo nhân viên - [SỬA] bỏ qua đơn không có tên NV (không hiện dòng trống)
    const byEmpMap = {};
    orders.forEach(o => {
      if (!o.emp || !o.emp.trim()) return;
      if (!byEmpMap[o.emp]) byEmpMap[o.emp] = { orders: 0, qty: 0, revenue: 0 };
      byEmpMap[o.emp].orders++;
      byEmpMap[o.emp].revenue += o.total;
      byEmpMap[o.emp].qty += o.items.reduce((a, it) => a + it.qty, 0);
    });
    const byEmployee = Object.keys(byEmpMap).map(k => ({ name: k, orders: byEmpMap[k].orders, qty: byEmpMap[k].qty, revenue: byEmpMap[k].revenue }))
      .sort((a, b) => b.revenue - a.revenue);

    // So sánh theo tháng (dùng đúng khoảng orders đã đọc, nhóm theo yyyy-MM)
    const byMonthMap = {};
    orders.forEach(o => {
      const d = new Date(o.date);
      const key = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2);
      if (!byMonthMap[key]) byMonthMap[key] = { revenue: 0, orders: 0 };
      byMonthMap[key].revenue += o.total;
      byMonthMap[key].orders++;
    });
    const monthKeys = Object.keys(byMonthMap).sort();
    const avgRevenue = monthKeys.length ? monthKeys.reduce((a, k) => a + byMonthMap[k].revenue, 0) / monthKeys.length : 0;
    const monthlyComparison = monthKeys.map(k => {
      const rev = byMonthMap[k].revenue;
      const pctVsAvg = avgRevenue ? ((rev - avgRevenue) / avgRevenue * 100) : 0;
      return { month: k, revenue: rev, orders: byMonthMap[k].orders, pctVsAvg: pctVsAvg };
    });

    return { byCustomer: byCustomer, byEmployee: byEmployee, monthlyComparison: monthlyComparison, avgRevenue: avgRevenue };
  } catch (e) {
    return { error: e.toString(), byCustomer: [], byEmployee: [], monthlyComparison: [], avgRevenue: 0 };
  }
}

// ════════════════════════════════════════════════════════════
//  KHÁCH HÀNG RỜI BỎ
// ════════════════════════════════════════════════════════════
function getChurnCustomers(dayThreshold) {
  try {
    const threshold = parseInt(dayThreshold) || 30;
    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
    if (!sh || sh.getLastRow() < 2) return [];
    let data = sh.getRange(2, 1, sh.getLastRow() - 1, READ_WIDTH).getValues();
    try { if (typeof _ldExtraRows_ === 'function') data = _ldExtraRows_(null, null).rows.concat(data); } catch (eA) { Logger.log('Lỗi đọc lưu trữ: ' + eA); }

    const lastBuy = {};
    let curDate = null, curName = '', curPhone = '', curCancelled = false;
    data.forEach(r => {
      if (r[0] && r[0] !== '') {
        curDate = r[0] instanceof Date ? r[0] : new Date(r[0]);
        curName = (r[1] || '').toString();
        curPhone = (r[2] || '').toString().replace(/[^0-9]/g, '');
        curCancelled = (r[COL_STATUS - 1] || '') === 'Huy';
      }
      if (curCancelled || !curPhone || !curDate) return;
      if (!lastBuy[curPhone] || curDate > lastBuy[curPhone].date) lastBuy[curPhone] = { date: curDate, name: curName };
    });

    const now = new Date();
    return Object.entries(lastBuy).map(([phone, info]) => {
      const days = Math.floor((now - info.date) / (1000 * 60 * 60 * 24));
      return { phone: phone, name: info.name, lastDate: info.date.toISOString(), daysSince: days };
    }).filter(x => x.daysSince >= threshold).sort((a, b) => b.daysSince - a.daysSince);
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  CÔNG NỢ - thanh toán từng phần + theo dõi theo khách sỉ
//  Cột: Đã Thu (12), Còn Lại (13), Lịch Sử Thanh Toán JSON (14),
//  Loại Giá (15) - dùng để phát hiện đơn giá Hội Chợ quá hạn.
// ════════════════════════════════════════════════════════════
const CN_HEADERS = ['Order Row', 'Tên KH', 'SĐT', 'Ngày đặt', 'Tổng tiền', 'Nhân viên',
  'Trạng thái', 'Ngày TT', 'Người duyệt', 'Ghi chú', 'Đã gửi mail', 'Đã Thu', 'Còn Lại', 'Lịch Sử Thanh Toán', 'Loại Giá'];

function _congNoSheet() {
  const sh = _sheet('CongNo', CN_HEADERS);
  // tự vá sheet cũ (v5.0) thiếu 4 cột mới
  const hdr = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 15)).getValues()[0];
  if (!hdr[11] || hdr[11] !== 'Đã Thu') {
    sh.getRange(1, 12, 1, 4).setValues([['Đã Thu', 'Còn Lại', 'Lịch Sử Thanh Toán', 'Loại Giá']]);
    const lastRow = sh.getLastRow();
    if (lastRow > 1) {
      const existing = sh.getRange(2, 1, lastRow - 1, 11).getValues();
      const fillDaThu = [], fillConLai = [], fillLS = [], fillLoai = [];
      existing.forEach(r => {
        const status = (r[6] || '').toString();
        const total = Number(r[4]) || 0;
        const paid = (status === 'Hoan tat' || status === 'Đã duyệt' || status === 'Da duyet') ? total : 0;
        fillDaThu.push([paid]); fillConLai.push([total - paid]); fillLS.push(['[]']); fillLoai.push(['']);
      });
      sh.getRange(2, 12, fillDaThu.length, 1).setValues(fillDaThu);
      sh.getRange(2, 13, fillConLai.length, 1).setValues(fillConLai);
      sh.getRange(2, 14, fillLS.length, 1).setValues(fillLS);
      sh.getRange(2, 15, fillLoai.length, 1).setValues(fillLoai);
    }
  }
  return sh;
}

function _saveCongNoInternal(orderRowRef, tenKH, sdt, ngayDat, tongTien, nhanVien, priceType) {
  const sh = _congNoSheet();
  const lastRow = sh.getLastRow();
  const refs = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 1).getValues() : [];
  for (let i = 0; i < refs.length; i++) {
    if (refs[i][0].toString() === orderRowRef.toString()) return 'Đã tồn tại công nợ này!';
  }
  const newRow = sh.getLastRow() + 1;
  const sdtStr = (sdt || '').toString();
  sh.getRange(newRow, 3).setNumberFormat('@');
  const row = [orderRowRef, tenKH, sdtStr, new Date(ngayDat), tongTien, nhanVien, 'Chờ thanh toán', '', '', '', false,
    0, tongTien, '[]', priceType || ''];
  sh.getRange(newRow, 1, 1, row.length).setValues([row]);
  return 'Đã thêm công nợ!';
}
function saveCongNo(orderRowRef, tenKH, sdt, ngayDat, tongTien, nhanVien, priceType) {
  try { return _saveCongNoInternal(orderRowRef, tenKH, sdt, ngayDat, tongTien, nhanVien, priceType); } catch (e) { return 'Lỗi: ' + e.toString(); }
}
function saveOrderWithDebt(orderData, isDebt) {
  if (!isDebt) return true;
  try {
    const ref = 'DH_' + new Date().getTime();
    return _saveCongNoInternal(ref, orderData.name, orderData.phone, new Date().toISOString(), orderData.totalAmount, orderData.employeeName, orderData.priceType);
  } catch (e) { return false; }
}

function getCongNoList(fromDate, toDate, empFilter, statusFilter) {
  try {
    const sh = _congNoSheet();
    const data = sh.getDataRange().getValues();
    if (data.length <= 1) return [];
    const from = fromDate ? new Date(fromDate) : null;
    const to = toDate ? new Date(toDate) : null;
    if (to) to.setHours(23, 59, 59, 999);
    return data.slice(1).filter(r => {
      const d = r[3] instanceof Date ? r[3] : new Date(r[3]);
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (empFilter && empFilter !== (r[5] || '')) return false;
      if (statusFilter && statusFilter !== (r[6] || '')) return false;
      return true;
    }).map(r => r.map(c => _clean(c)));
  } catch (e) { return []; }
}

// Danh sách khách sỉ đang có công nợ (gộp theo SĐT), kèm cờ cảnh báo quá
// hạn (giá Hội Chợ + (>3 ngày hoặc >3 đơn) + còn nợ).
function getCongNoCustomerList() {
  try {
    const sh = _congNoSheet();
    const data = sh.getDataRange().getValues();
    if (data.length <= 1) return [];
    const now = new Date();
    const byCust = {};
    data.slice(1).forEach((r, i) => {
      const sheetRow = i + 2;
      const name = (r[1] || '').toString();
      const phone = (r[2] || '').toString();
      const key = phone || name || ('row' + sheetRow);
      const ngay = r[3] instanceof Date ? r[3] : new Date(r[3]);
      const total = Number(r[4]) || 0;
      const conLai = r[12] !== '' && r[12] !== null && r[12] !== undefined ? Number(r[12]) : total;
      const loaiGia = (r[14] || '').toString();
      if (!byCust[key]) byCust[key] = { name: name, phone: phone, orders: 0, unpaidOrders: 0, total: 0, conLai: 0, oldestUnpaidDays: 0, warning: false };
      const c = byCust[key];
      c.name = name || c.name; c.phone = phone || c.phone;
      c.orders++;
      c.total += total;
      c.conLai += conLai;
      if (conLai > 0) {
        c.unpaidOrders++;
        const days = Math.floor((now - ngay) / (1000 * 60 * 60 * 24));
        if (days > c.oldestUnpaidDays) c.oldestUnpaidDays = days;
        const isHoiCho = /hoi.?cho/i.test(loaiGia) || loaiGia.indexOf('Hội Chợ') !== -1;
        if (isHoiCho && (days > 3 || c.unpaidOrders > 3)) c.warning = true;
      }
    });
    return Object.keys(byCust).map(k => byCust[k]).sort((a, b) => b.conLai - a.conLai);
  } catch (e) { return []; }
}

// Chi tiết công nợ của 1 khách sỉ - đánh số Đơn 1,2,3... theo ngày, kèm
// lịch sử thanh toán đã parse và cờ cảnh báo từng đơn.
function getCongNoDetailByCustomer(phoneOrName) {
  try {
    const sh = _congNoSheet();
    const data = sh.getDataRange().getValues();
    if (data.length <= 1) return [];
    const now = new Date();
    const key = (phoneOrName || '').toString().trim();
    const rows = [];
    data.slice(1).forEach((r, i) => {
      const sheetRow = i + 2;
      const name = (r[1] || '').toString();
      const phone = (r[2] || '').toString();
      if (phone !== key && name !== key) return;
      const ngay = r[3] instanceof Date ? r[3] : new Date(r[3]);
      const total = Number(r[4]) || 0;
      const daThu = r[11] !== '' && r[11] !== null && r[11] !== undefined ? Number(r[11]) : 0;
      const conLai = r[12] !== '' && r[12] !== null && r[12] !== undefined ? Number(r[12]) : (total - daThu);
      let lichSu = [];
      try { lichSu = JSON.parse(r[13] || '[]'); } catch (e) {}
      const loaiGia = (r[14] || '').toString();
      const daysSince = Math.floor((now - ngay) / (1000 * 60 * 60 * 24));
      rows.push({
        sheetRow: sheetRow, date: ngay.toISOString(), name: name, phone: phone,
        total: total, paid: daThu, remaining: conLai, history: lichSu,
        status: r[6] || '', priceType: loaiGia, daysSince: daysSince, emp: r[5] || ''
      });
    });
    rows.sort((a, b) => new Date(a.date) - new Date(b.date));
    let unpaidCount = 0;
    rows.forEach((row, idx) => {
      row.orderNo = idx + 1;
      if (row.remaining > 0) unpaidCount++;
      const isHoiCho = /hoi.?cho/i.test(row.priceType) || row.priceType.indexOf('Hội Chợ') !== -1;
      row.warning = row.remaining > 0 && isHoiCho && (row.daysSince > 3 || unpaidCount > 3);
    });
    return rows;
  } catch (e) { return []; }
}

// Ghi nhận 1 lần thanh toán (có thể trả từng phần nhiều lần)
function recordDebtPayment(sheetRow, amount, payDate, confirmedBy) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _congNoSheet();
    const r = sh.getRange(sheetRow, 1, 1, 15).getValues()[0];
    const total = Number(r[4]) || 0;
    let daThu = Number(r[11]) || 0;
    let lichSu = [];
    try { lichSu = JSON.parse(r[13] || '[]'); } catch (e) {}
    const amt = Math.max(0, Number(amount) || 0);
    if (amt <= 0) return { success: false, error: 'Số tiền không hợp lệ.' };
    lichSu.push({ date: (payDate ? new Date(payDate) : new Date()).toISOString(), amount: amt, by: confirmedBy || '' });
    daThu += amt;
    if (daThu > total) daThu = total;
    const conLai = Math.max(0, total - daThu);
    const status = conLai <= 0 ? 'Hoan tat' : 'Dang thu mot phan';
    sh.getRange(sheetRow, 12).setValue(daThu);
    sh.getRange(sheetRow, 13).setValue(conLai);
    sh.getRange(sheetRow, 14).setValue(JSON.stringify(lichSu));
    sh.getRange(sheetRow, 7).setValue(status);
    if (conLai <= 0) { sh.getRange(sheetRow, 8).setValue(new Date()); sh.getRange(sheetRow, 9).setValue(confirmedBy || ''); }
    return { success: true, paid: daThu, remaining: conLai, status: status };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

function extendCongNo(sheetRow, newPayDate, approverEmail, empEmail, note) {
  try {
    const sh = _congNoSheet();
    const r = sh.getRange(sheetRow, 1, 1, 11).getValues()[0];
    sh.getRange(sheetRow, 7).setValue('Đã gia hạn');
    sh.getRange(sheetRow, 8).setValue(new Date(newPayDate));
    if (note) sh.getRange(sheetRow, 10).setValue(note);
    const subject = '[9 Sạch] Gia hạn công nợ KH: ' + r[1];
    const body = 'Khách hàng ' + r[1] + ' (' + r[2] + ') đã được gia hạn thanh toán.\n'
      + 'Ngày thanh toán mới: ' + new Date(newPayDate).toLocaleDateString('vi-VN') + '\n'
      + 'Ghi chú: ' + (note || '') + '\n\nHệ Thống 9 Sạch';
    [approverEmail, empEmail].filter(Boolean).forEach(mail => { try { MailApp.sendEmail(mail, subject, body); } catch (ex) {} });
    return true;
  } catch (e) { return false; }
}

function checkAndSendDebtWarnings() {
  const sh = _congNoSheet();
  if (!sh) return;
  const data = sh.getDataRange().getValues();
  const empList = getEmployeeList();
  const adminEmails = empList.filter(e => e.role === 'Admin').map(e => e.email).filter(Boolean);
  const now = new Date();
  data.slice(1).forEach((r, i) => {
    const status = (r[6] || '').toString(); const alerted = r[10];
    if (status === 'Hoàn tất' || status === 'Hoan tat' || status === 'Đã duyệt' || alerted) return;
    const orderDate = r[3] instanceof Date ? r[3] : new Date(r[3]);
    if ((now - orderDate) / (1000 * 60 * 60) < 24) return;
    const tenKH = r[1], sdt = r[2], total = r[4], empName = r[5];
    const emp = empList.find(e => e.displayName === empName);
    const subject = '[CẢNH BÁO] Công nợ chưa xác nhận CK: ' + tenKH;
    const body = 'KH: ' + tenKH + ' (' + sdt + ')\nTổng tiền: ' + Number(total).toLocaleString('vi-VN')
      + 'đ\nNgày đặt: ' + orderDate.toLocaleString('vi-VN') + '\nNhân viên: ' + empName
      + '\n\nVui lòng cập nhật trạng thái thanh toán.\nHệ Thống 9 Sạch';
    [...adminEmails, emp ? emp.email : ''].filter(Boolean).forEach(mail => { try { MailApp.sendEmail(mail, subject, body); } catch (ex) {} });
    sh.getRange(i + 2, 11).setValue(true);
  });
}

function approveCongNo(sheetRow, approverName) {
  try {
    const sh = _congNoSheet();
    sh.getRange(sheetRow, 7).setValue('Đã duyệt'); sh.getRange(sheetRow, 9).setValue(approverName);
    return true;
  } catch (e) { return false; }
}
function confirmPayment(sheetRow, confirmedBy) {
  try {
    const sh = _congNoSheet();
    const r = sh.getRange(sheetRow, 1, 1, 15).getValues()[0];
    const total = Number(r[4]) || 0;
    sh.getRange(sheetRow, 7).setValue('Hoàn tất'); sh.getRange(sheetRow, 9).setValue(confirmedBy); sh.getRange(sheetRow, 8).setValue(new Date());
    sh.getRange(sheetRow, 12).setValue(total); sh.getRange(sheetRow, 13).setValue(0);
    return true;
  } catch (e) { return false; }
}

// [MỚI v6.1] Xóa vĩnh viễn 1 dòng công nợ theo sheetRow. Chỉ nên gọi từ
// giao diện dành cho Admin (kiểm tra quyền được thực hiện ở phía client -
// nút xóa chỉ hiện khi currentEmployee.role === 'Admin'). Thao tác này xóa
// hẳn dòng khỏi sheet CongNo, không phục hồi được.
function deleteCongNoRow(sheetRow) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _congNoSheet();
    const row = parseInt(sheetRow);
    if (!row || row < 2) return { success: false, error: 'Dòng không hợp lệ.' };
    if (row > sh.getLastRow()) return { success: false, error: 'Dòng đã bị xóa trước đó hoặc không tồn tại.' };
    sh.deleteRow(row);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

// ════════════════════════════════════════════════════════════
//  TỪ VIẾT TẮT "TẠO ĐƠN BẰNG VĂN BẢN" - dùng chung mọi máy
//  Sheet 'TuVietTat': A=Từ viết tắt | B=Họ SP | C=Người tạo | D=Cập nhật
// ════════════════════════════════════════════════════════════
const PA_SHEET = 'TuVietTat';
const PA_HEADERS = ['Từ viết tắt', 'Họ SP', 'Người tạo', 'Cập nhật'];
const PA_FAMS = ['set', 'mix', 'tim', 'psx', 'choco', 'vang', 'than', 'xanh'];

function _paSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(PA_SHEET);
  if (!sh) { sh = ss.insertSheet(PA_SHEET); sh.appendRow(PA_HEADERS); sh.setFrozenRows(1); }
  return sh;
}
function _paKey_(k) { return _nfc_(k).trim().toLowerCase().replace(/\s+/g, ' '); }

function getPasteAliases() {
  try {
    const sh = _paSheet_(), n = sh.getLastRow();
    const out = {};
    if (n < 2) return out;
    sh.getRange(2, 1, n - 1, 2).getValues().forEach(r => {
      const k = _paKey_(r[0]), f = (r[1] || '').toString().trim().toLowerCase();
      if (k && PA_FAMS.indexOf(f) >= 0) out[k] = f;
    });
    return out;
  } catch (e) { return null; }
}

function upsertPasteAliases(obj, userName) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { ok: false, error: 'busy' }; }
  try {
    const sh = _paSheet_(), n = sh.getLastRow();
    const rows = n > 1 ? sh.getRange(2, 1, n - 1, 2).getValues() : [];
    const pos = {};
    rows.forEach((r, i) => { pos[_paKey_(r[0])] = i + 2; });
    const now = new Date(), who = (userName || '').toString();
    let cnt = 0;
    Object.keys(obj || {}).forEach(k0 => {
      const k = _paKey_(k0), f = (obj[k0] || '').toString().trim().toLowerCase();
      if (!k || k.length > 60 || PA_FAMS.indexOf(f) < 0) return;
      if (pos[k]) sh.getRange(pos[k], 1, 1, 4).setValues([[k, f, who, now]]);
      else { sh.appendRow([k, f, who, now]); pos[k] = sh.getLastRow(); }
      cnt++;
    });
    return { ok: true, count: cnt };
  } catch (e) { return { ok: false, error: e.toString() }; }
  finally { lock.releaseLock(); }
}

function deletePasteAlias(key) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { ok: false, error: 'busy' }; }
  try {
    const sh = _paSheet_(), n = sh.getLastRow(), k = _paKey_(key);
    if (n < 2 || !k) return { ok: true, count: 0 };
    const vals = sh.getRange(2, 1, n - 1, 1).getValues();
    let cnt = 0;
    for (let i = vals.length - 1; i >= 0; i--) {
      if (_paKey_(vals[i][0]) === k) { sh.deleteRow(i + 2); cnt++; }
    }
    return { ok: true, count: cnt };
  } catch (e) { return { ok: false, error: e.toString() }; }
  finally { lock.releaseLock(); }
}

// ════════════════════════════════════════════════════════════
//  CẤU HÌNH LINK
// ════════════════════════════════════════════════════════════
function saveLinks(linkObj) {
  try {
    const props = PropertiesService.getScriptProperties();
    Object.keys(linkObj).forEach(k => props.setProperty(k, linkObj[k]));
    return true;
  } catch (e) { return false; }
}
function getLinks() {
  try {
    const props = PropertiesService.getScriptProperties();
    return {
      lnkXoaSua: props.getProperty('lnkXoaSua') || '', lnkKiemDon: props.getProperty('lnkKiemDon') || '',
      lnkKeToan: props.getProperty('lnkKeToan') || '', lnkDashboard: props.getProperty('lnkDashboard') || '',
      lblXoaSua: props.getProperty('lblXoaSua') || 'Xóa Sửa', lblKiemDon: props.getProperty('lblKiemDon') || 'Kiểm Đơn',
      lblKeToan: props.getProperty('lblKeToan') || 'Kế Toán', lblDashboard: props.getProperty('lblDashboard') || 'Dashboard'
    };
  } catch (e) { return {}; }
}

// ════════════════════════════════════════════════════════════
//  ĐỊA CHỈ 2 CẤP
// ════════════════════════════════════════════════════════════
function getProvinces() {
  try {
    const cache = CacheService.getScriptCache();
    const cached = cache.get('vn_provinces_v2');
    if (cached) return JSON.parse(cached);
    const resp = UrlFetchApp.fetch('https://provinces.open-api.vn/api/v2/p/', { muteHttpExceptions: true });
    const data = JSON.parse(resp.getContentText());
    try { cache.put('vn_provinces_v2', JSON.stringify(data), 3600); } catch (e) {}
    return data;
  } catch (e) { return []; }
}
function getWardsByProvince(provinceCode) {
  try {
    const cache = CacheService.getScriptCache();
    const key = 'vn_wards_v2_' + provinceCode;
    const cached = cache.get(key);
    if (cached) return JSON.parse(cached);
    const resp = UrlFetchApp.fetch('https://provinces.open-api.vn/api/v2/p/' + provinceCode + '?depth=2', { muteHttpExceptions: true });
    const data = JSON.parse(resp.getContentText());
    const wards = data && data.wards ? data.wards : [];
    try { cache.put(key, JSON.stringify(wards), 3600); } catch (e) {}
    return wards;
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  XUẤT EXCEL - hỗ trợ NHIỀU SHEET trong 1 file
//  sheetsSpec: [{title, headers, rows}, ...]  (dùng cho báo cáo tổng hợp)
//  Vẫn giữ chữ ký cũ exportToExcel(title, headers, rows) cho tương thích.
// ════════════════════════════════════════════════════════════
function exportToExcel(sheetTitle, headers, rows) {
  return exportMultiSheetExcel([{ title: sheetTitle || 'Data', headers: headers, rows: rows }]);
}

function exportMultiSheetExcel(sheetsSpec) {
  let tempSS = null;
  try {
    tempSS = SpreadsheetApp.create('TEMP_EXPORT_9SACH_' + new Date().getTime());
    const firstDefaultSheet = tempSS.getSheets()[0];
    const usedNames = {};
    (sheetsSpec || []).forEach((spec, idx) => {
      const sh = idx === 0 ? firstDefaultSheet : tempSS.insertSheet();
      // [SỬA] tên sheet: bỏ ký tự cấm [ ] : * ? / \ , cắt 90 ký tự, không trùng
      let nm = (spec.title || ('Sheet' + (idx + 1))).toString().replace(/[\[\]:*?\/\\]/g, ' ').trim().substring(0, 90) || ('Sheet' + (idx + 1));
      let base = nm, k = 2;
      while (usedNames[nm.toLowerCase()]) { nm = base.substring(0, 85) + ' ' + (k++); }
      usedNames[nm.toLowerCase()] = true;
      sh.setName(nm);
      const headers = spec.headers || [];
      // [SỬA] đồng bộ độ rộng mọi dòng (setValues báo lỗi nếu dòng dài/ngắn khác nhau), bỏ null/undefined
      // [FIX] không dùng Math.max(...mảng) - lỗi tràn stack khi >~100k dòng
      let width = Math.max(headers.length, 1);
      (spec.rows || []).forEach(r => { const l = (r || []).length; if (l > width) width = l; });
      const rows = (spec.rows || []).map(r => {
        const out = new Array(width).fill('');
        (r || []).forEach((v, i) => { out[i] = (v === null || v === undefined) ? '' : v; });
        return out;
      });
      // [FIX] sheet mới chỉ có 1000 dòng x 26 cột -> mở rộng trước khi ghi, nếu không báo lỗi "out of bounds"
      const needRows = rows.length + 1;
      if (sh.getMaxRows() < needRows) sh.insertRowsAfter(sh.getMaxRows(), needRows - sh.getMaxRows());
      if (sh.getMaxColumns() < width) sh.insertColumnsAfter(sh.getMaxColumns(), width - sh.getMaxColumns());
      if (headers.length) sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold').setBackground('#1b4332').setFontColor('#ffffff');
      for (let st = 0; st < rows.length; st += 5000) {
        const part = rows.slice(st, st + 5000);
        sh.getRange(2 + st, 1, part.length, width).setValues(part);
      }
      if (width && rows.length <= 5000) sh.autoResizeColumns(1, width);
    });
    SpreadsheetApp.flush();
    const url = 'https://docs.google.com/spreadsheets/d/' + tempSS.getId() + '/export?format=xlsx';
    const resp = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
    if (resp.getResponseCode() !== 200) throw new Error('Google trả về HTTP ' + resp.getResponseCode() + ' khi xuất file (kiểm tra quyền Drive/Sheets của script).');
    const base64 = Utilities.base64Encode(resp.getBlob().getBytes());
    DriveApp.getFileById(tempSS.getId()).setTrashed(true);
    return base64;
  } catch (e) {
    if (tempSS) { try { DriveApp.getFileById(tempSS.getId()).setTrashed(true); } catch (ex) {} }
    throw new Error('Lỗi xuất Excel: ' + e.toString());
  }
}

// Xuất báo cáo tổng hợp nhiều sheet: Theo Khách Sỉ, Theo Nhân Viên, So
// Sánh Theo Tháng.
function exportSummaryReportExcel(fromDate, toDate) {
  const rep = getSummaryReport(fromDate, toDate);
  const sheets = [];

  const custHeaders = ['Khách sỉ', 'SĐT', 'Số đơn', 'Tổng SL', 'Doanh thu'];
  const custRows = rep.byCustomer.map(c => [c.name, c.phone, c.orders, c.qty, c.revenue]);
  sheets.push({ title: 'Theo Khach Si', headers: custHeaders, rows: custRows.length ? custRows : [['', '', '', '', '']] });

  const prodHeaders = ['Khách sỉ', 'Sản phẩm', 'SL', 'Doanh thu'];
  const prodRows = [];
  rep.byCustomer.forEach(c => c.products.forEach(p => prodRows.push([c.name, p.name, p.qty, p.revenue])));
  sheets.push({ title: 'SP Theo Khach Si', headers: prodHeaders, rows: prodRows.length ? prodRows : [['', '', '', '']] });

  const empHeaders = ['Nhân viên', 'Số đơn', 'Tổng SL', 'Doanh thu'];
  const empRows = rep.byEmployee.map(e => [e.name, e.orders, e.qty, e.revenue]);
  sheets.push({ title: 'Theo Nhan Vien', headers: empHeaders, rows: empRows.length ? empRows : [['', '', '', '']] });

  const cmpHeaders = ['Tháng', 'Doanh thu', 'Số đơn', '% so với TB các tháng'];
  const cmpRows = rep.monthlyComparison.map(m => [m.month, m.revenue, m.orders, m.pctVsAvg.toFixed(1) + '%']);
  sheets.push({ title: 'So Sanh Theo Thang', headers: cmpHeaders, rows: cmpRows.length ? cmpRows : [['', '', '', '']] });

  return exportMultiSheetExcel(sheets);
}

// ════════════════════════════════════════════════════════════
//  TIỆN ÍCH DỌN DẸP DỮ LIỆU CŨ - CHẠY TAY 1 LẦN
// ════════════════════════════════════════════════════════════
function repairDonHangPhones() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!sh || sh.getLastRow() < 2) { Logger.log('Không có dữ liệu.'); return; }
  const lastRow = sh.getLastRow();
  const rng = sh.getRange(2, 3, lastRow - 1, 1);
  const values = rng.getValues();
  let fixed = 0;
  const out = values.map(r => {
    const v = r[0];
    if (typeof v === 'number') {
      const s = String(Math.round(v));
      if (/^[35789]\d{8}$/.test(s)) { fixed++; return ['0' + s]; }
      return [s];
    }
    return [v];
  });
  rng.setNumberFormat('@');
  rng.setValues(out);
  Logger.log('Đã sửa ' + fixed + ' số điện thoại bị mất số 0 đầu trong DonHang (cột C).');
}

function repairDataKhachSiPhones() {
  const sh = _dataKhachSiSheet();
  if (!sh || sh.getLastRow() < 2) { Logger.log('Không có dữ liệu.'); return; }
  const lastRow = sh.getLastRow();
  const rng = sh.getRange(2, 2, lastRow - 1, 1);
  const values = rng.getValues();
  let fixed = 0;
  const out = values.map(r => {
    const v = r[0];
    if (typeof v === 'number') {
      const s = String(Math.round(v));
      if (/^[35789]\d{8}$/.test(s)) { fixed++; return ['0' + s]; }
      return [s];
    }
    return [v];
  });
  rng.setNumberFormat('@');
  rng.setValues(out);
  Logger.log('Đã sửa ' + fixed + ' số điện thoại bị mất số 0 đầu trong DataKhachSi (cột B).');
}

function repairLegacyColumnM_to_O() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!sh || sh.getLastRow() < 2) { Logger.log('Không có dữ liệu.'); return; }
  const lastRow = sh.getLastRow();
  const mRng = sh.getRange(2, 13, lastRow - 1, 1);
  const oRng = sh.getRange(2, 15, lastRow - 1, 1);
  const mVals = mRng.getValues();
  const oVals = oRng.getValues();
  let moved = 0;
  for (let i = 0; i < mVals.length; i++) {
    const mv = mVals[i][0];
    if (mv !== '' && mv !== null && (oVals[i][0] === '' || oVals[i][0] === null)) {
      oVals[i][0] = mv;
      mVals[i][0] = '';
      moved++;
    }
  }
  oRng.setValues(oVals);
  mRng.setValues(mVals);
  Logger.log('Đã chuyển ' + moved + ' giá trị từ cột M (ghi nhầm) sang cột O, giải phóng công thức mảng ở M.');
}

function repairAllLegacyData() {
  repairDonHangPhones();
  repairDataKhachSiPhones();
  repairLegacyColumnM_to_O();
  Logger.log('HOÀN TẤT dọn dẹp dữ liệu cũ.');
}
/** ============================================================
 *  IMPORT DỮ LIỆU ĐƠN HÀNG CŨ VÀO DonHang - chạy tay 1 lần
 *  Yêu cầu: đã import DonHang_Import_Cleaned.xlsx thành sheet
 *  "DonHang_Import" trong cùng Google Sheet.
 * ============================================================ */
function importOldDonHangData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const srcSheet = ss.getSheetByName('DonHang_Import');
  if (!srcSheet) { Logger.log('Không tìm thấy sheet "DonHang_Import".'); return; }
  const dstSheet = _donHangSheet(); // dùng helper có sẵn trong Code.gs

  const lastRow = srcSheet.getLastRow();
  if (lastRow < 2) { Logger.log('Sheet nguồn trống.'); return; }
  const srcData = srcSheet.getRange(2, 1, lastRow - 1, 22).getValues();

  // Chống trùng: khóa = thời điểm đặt (ms) + SĐT đã lọc số
  const dstLastRow = dstSheet.getLastRow();
  const existingKeys = {};
  if (dstLastRow > 1) {
    const existing = dstSheet.getRange(2, 1, dstLastRow - 1, 7).getValues();
    existing.forEach(r => {
      if (r[0] && r[0] !== '') {
        const t = (r[0] instanceof Date ? r[0] : new Date(r[0])).getTime();
        const key = t + '_' + (r[2] || '').toString().replace(/\D/g, '');
        existingKeys[key] = true;
      }
    });
  }

  const outRows = [];
  let skip = false;
  let skippedOrders = 0;
  srcData.forEach(r => {
    if (r[0] && r[0] !== '') {
      const t = (r[0] instanceof Date ? r[0] : new Date(r[0])).getTime();
      const key = t + '_' + (r[2] || '').toString().replace(/\D/g, '');
      skip = !!existingKeys[key];
      if (skip) skippedOrders++;
    }
    if (!skip) outRows.push(r);
  });

  if (!outRows.length) { Logger.log('Toàn bộ đơn đã tồn tại trong DonHang - không nhập gì thêm.'); return; }

  const startRow = dstSheet.getLastRow() + 1;
  dstSheet.getRange(startRow, 3, outRows.length, 1).setNumberFormat('@'); // giữ SĐT dạng text
  dstSheet.getRange(startRow, 1, outRows.length, 22).setValues(outRows);

  Logger.log('Đã nhập ' + outRows.length + ' dòng. Bỏ qua ' + skippedOrders + ' đơn trùng (đã có sẵn trong DonHang).');
}

/** Đối soát tổng số sau khi nhập - chạy để kiểm tra chính xác con số */
function verifyImportedTotals() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  const lastRow = sh.getLastRow();
  if (lastRow < 2) { Logger.log('DonHang trống.'); return; }
  const data = sh.getRange(2, 1, lastRow - 1, 22).getValues();
  let total = 0, orders = 0, huy = 0;
  data.forEach(r => {
    if (r[0] && r[0] !== '') orders++;
    if ((r[20] || '') === 'Huy') huy++;
    if (r[6]) total += Number(r[6]) || 0;
  });
  Logger.log('Tổng số đơn: ' + orders + ' | Đơn đã hủy: ' + huy + ' | Tổng doanh thu (kể cả đã hủy): ' + total.toLocaleString('vi-VN') + 'đ');
}
/** ============================================================
 *  9 SẠCH - NÂNG CẤP: TỔNG HỢP DOANH THU THEO THÁNG (TongHopThang)
 *  ================================================================
 *  MỤC ĐÍCH: Dashboard/BI không cần quét lại toàn bộ DonHang mỗi lần
 *  mở nữa. Mỗi khi có đơn mới/sửa/hủy, chỉ cộng-trừ 1 dòng trong sheet
 *  TongHopThang (mỗi dòng = 1 tháng). getBusinessDashboard() đọc sheet
 *  nhỏ này cho các số liệu nhiều tháng (12 tháng/quý/lũy kế năm), chỉ
 *  đọc DonHang trong phạm vi THÁNG NÀY + THÁNG TRƯỚC để lấy chi tiết
 *  theo nhân viên/loại giá/sản phẩm.
 *
 *  CÁCH TRIỂN KHAI:
 *  1. Trong Code.gs hiện tại, XÓA 3 hàm: submitOrder, cancelOrderOnly,
 *     getBusinessDashboard (sẽ được thay thế bằng bản trong file này).
 *  2. Dán TOÀN BỘ nội dung file này vào cuối Code.gs.
 *  3. Trong Apps Script Editor, chọn hàm rebuildTongHopThang() ở
 *     dropdown trên cùng → bấm Run (chạy 1 lần để dựng số liệu ban
 *     đầu từ toàn bộ DonHang hiện có, kể cả dữ liệu vừa import).
 *  4. Từ đó về sau mọi thứ tự động cập nhật, không cần chạy lại.
 * ============================================================ */

const TONGHOP_HEADERS = ['Tháng', 'Doanh Thu', 'Số Đơn', 'Số Lượng SP', 'Khách Hàng (SĐT JSON)', 'Cập Nhật Lúc'];

function _tongHopSheet() {
  const sh = _sheet('TongHopThang', TONGHOP_HEADERS);
  // [FIX v6.3] Google Sheets tự nhận diện "2026-08" là ngày tháng và âm
  // thầm chuyển thành Date khi ghi, khiến tra cứu theo khóa chuỗi luôn
  // trật -> Dashboard hiện 0 dù dữ liệu còn nguyên. Ép cột A về văn bản
  // TRƯỚC khi ghi để chặn việc tự động chuyển đổi này.
  try {
    const lastRow = sh.getLastRow();
    const numRows = Math.max(lastRow - 1, 1);
    sh.getRange(2, 1, numRows, 1).setNumberFormat('@');
  } catch (e) {}
  return sh;
}

function _monthKey(d) {
  d = (d instanceof Date) ? d : new Date(d);
  return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2);
}

// Đọc lại tổng doanh thu/SL/SĐT của 1 khối dòng đơn hàng (dùng khi sửa/hủy để trừ ngược)
function _readOrderBlockTotals(sh, startRow, rowCount) {
  try {
    const n = Math.max(1, parseInt(rowCount) || 1);
    const block = sh.getRange(startRow, 1, n, 7).getValues(); // cột A-G
    const dateVal = block[0][0];
    const phone = block[0][2];
    let revenue = 0, qty = 0;
    block.forEach(r => { revenue += Number(r[6]) || 0; qty += Number(r[5]) || 0; });
    return {
      date: dateVal instanceof Date ? dateVal : new Date(dateVal),
      revenue: revenue, qty: qty, phone: phone
    };
  } catch (e) { return null; }
}

// Cộng/trừ 1 delta vào đúng dòng tháng trong TongHopThang (tạo dòng mới nếu chưa có)
function _tongHopApplyDelta(dateObj, revenueDelta, ordersDelta, qtyDelta, phone) {
  try {
    const sh = _tongHopSheet();
    const key = _monthKey(dateObj);
    const lastRow = sh.getLastRow();
    const data = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 6).getValues() : [];
    const cleanPhone = (phone || '').toString().replace(/\D/g, '');

    for (let i = 0; i < data.length; i++) {
      if (data[i][0] === key) {
        const rowIdx = i + 2;
        let custList = [];
        try { custList = JSON.parse(data[i][4] || '[]'); } catch (e) {}
        if (cleanPhone && custList.indexOf(cleanPhone) === -1) custList.push(cleanPhone);
        const newRev = Math.max(0, (Number(data[i][1]) || 0) + revenueDelta);
        const newOrders = Math.max(0, (Number(data[i][2]) || 0) + ordersDelta);
        const newQty = Math.max(0, (Number(data[i][3]) || 0) + qtyDelta);
        sh.getRange(rowIdx, 2, 1, 5).setValues([[newRev, newOrders, newQty, JSON.stringify(custList), new Date()]]);
        return;
      }
    }
    // chưa có dòng của tháng này -> tạo mới
    const custList = cleanPhone ? [cleanPhone] : [];
    const newRowIdx = sh.getLastRow() + 1;
    sh.getRange(newRowIdx, 1).setNumberFormat('@'); // [FIX v6.3] ép văn bản TRƯỚC khi ghi
    sh.getRange(newRowIdx, 1, 1, 6).setValues([[key, Math.max(0, revenueDelta), Math.max(0, ordersDelta), Math.max(0, qtyDelta), JSON.stringify(custList), new Date()]]);
  } catch (e) {
    Logger.log('Lỗi cập nhật TongHopThang: ' + e.toString());
  }
}

// Đọc toàn bộ TongHopThang 1 lần thành object tra cứu nhanh theo key tháng
function _loadTongHopMap() {
  const sh = _tongHopSheet();
  const lastRow = sh.getLastRow();
  const map = {};
  if (lastRow < 2) return map;
  const data = sh.getRange(2, 1, lastRow - 1, 6).getValues();
  data.forEach(r => {
    if (!r[0]) return;
    // [FIX v6.3] Tự phục hồi dòng CŨ đã lỡ bị Sheets chuyển thành Date
    // trước khi có fix ở _tongHopSheet() - quy về đúng khóa "yyyy-MM".
    const keyStr = (r[0] instanceof Date) ? _monthKey(r[0]) : r[0].toString().trim();
    let custCount = 0;
    try { custCount = JSON.parse(r[4] || '[]').length; } catch (e) {}
    const revenue = Number(r[1]) || 0, orders = Number(r[2]) || 0, qty = Number(r[3]) || 0;
    map[keyStr] = { revenue: revenue, orders: orders, qty: qty, aov: orders ? Math.round(revenue / orders) : 0, customers: custCount };
  });
  return map;
}

// Tìm ngày đặt của đơn gần nhất chưa hủy - chỉ đọc tối đa 500 dòng cuối DonHang (nhẹ)
function _getLastOrderDate() {
  try {
    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
    if (!sh || sh.getLastRow() < 2) return (typeof _ldLastOrderDateFallback_ === 'function') ? _ldLastOrderDateFallback_() : null;
    const lastRow = sh.getLastRow();
    const scanRows = Math.min(500, lastRow - 1);
    const startRow = lastRow - scanRows + 1;
    const data = sh.getRange(startRow, 1, scanRows, COL_STATUS).getValues();
    for (let i = data.length - 1; i >= 0; i--) {
      const r = data[i];
      if (r[0] && r[0] !== '' && (r[COL_STATUS - 1] || '') !== 'Huy') {
        return r[0] instanceof Date ? r[0] : new Date(r[0]);
      }
    }
    return (typeof _ldLastOrderDateFallback_ === 'function') ? _ldLastOrderDateFallback_() : null;
  } catch (e) { return null; }
}

// [CHẠY TAY 1 LẦN] Dựng lại toàn bộ TongHopThang từ dữ liệu DonHang hiện có
function rebuildTongHopThang() {
  if (typeof _ldRebuildGuard_ === 'function' && _ldRebuildGuard_()) throw new Error('Đã có tháng được lưu trữ và xóa khỏi DonHang. Dùng sanDoanhThuTatCa() thay cho chức năng này.');
  const src = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!src || src.getLastRow() < 2) { Logger.log('DonHang trống.'); return; }
  const data = src.getRange(2, 1, src.getLastRow() - 1, READ_WIDTH).getValues();
  const monthMap = {};
  let curDate = null, curPhone = '', curSkip = false;

  data.forEach(r => {
    if (r[0] && r[0] !== '') {
      curDate = r[0] instanceof Date ? r[0] : new Date(r[0]);
      curPhone = (r[2] || '').toString().replace(/\D/g, '');
      curSkip = (r[COL_STATUS - 1] || '') === 'Huy';
      if (!curSkip && _orderNeedsApproval(curDate) && !_approvalValid_(r[23], r[24])) curSkip = true; // đơn từ 01/10/2026 chưa duyệt: không tính
      if (!curSkip) {
        const key = _monthKey(curDate);
        if (!monthMap[key]) monthMap[key] = { revenue: 0, orders: 0, qty: 0, cust: {} };
        monthMap[key].orders++;
        if (curPhone) monthMap[key].cust[curPhone] = 1;
      }
    }
    if (curSkip || !curDate) return;
    const key = _monthKey(curDate);
    if (!monthMap[key]) monthMap[key] = { revenue: 0, orders: 0, qty: 0, cust: {} };
    monthMap[key].revenue += Number(r[6]) || 0;
    monthMap[key].qty += Number(r[5]) || 0;
  });

  const sh = _tongHopSheet();
  const lastRow = sh.getLastRow();
  if (lastRow > 1) sh.getRange(2, 1, lastRow - 1, 6).clearContent();

  const rows = Object.keys(monthMap).sort().map(key => {
    const m = monthMap[key];
    return [key, m.revenue, m.orders, m.qty, JSON.stringify(Object.keys(m.cust)), new Date()];
  });
  if (rows.length) {
    sh.getRange(2, 1, rows.length, 1).setNumberFormat('@'); // [FIX v6.3] ép văn bản TRƯỚC khi ghi
    sh.getRange(2, 1, rows.length, 6).setValues(rows);
  }
  Logger.log('Đã dựng lại TongHopThang: ' + rows.length + ' tháng, tổng doanh thu = ' +
    rows.reduce((a, r) => a + r[1], 0).toLocaleString('vi-VN') + 'đ');
}

// ════════════════════════════════════════════════════════════
//  THAY THẾ: submitOrder (thêm cập nhật TongHopThang)
// ════════════════════════════════════════════════════════════
function submitOrder(data, isDebt, editInfo) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
  } catch (e) {
    throw new Error('Hệ thống đang bận, vui lòng thử lại sau vài giây.');
  }
  try {
    // [MỚI] Chặn ĐƠN TRỐNG (không có sản phẩm)
    if (!data || !Array.isArray(data.cartDetails) || !data.cartDetails.some(it => Number(it.qty) > 0)) {
      return { success: false, empty: true, message: 'Đơn hàng trống - chưa có sản phẩm nào, không tạo đơn.' };
    }
    // [MỚI] Chặn ĐƠN TRÙNG: cùng NV + cùng khách + cùng sản phẩm/số lượng/tổng tiền trong vòng 3 phút
    let dupKey = '';
    if (!editInfo || !editInfo.startRow) {
      const sig = [data.employeeName || '', (data.phone || '').toString().replace(/[^0-9]/g, '') || data.name || '', Number(data.totalAmount) || 0,
        data.cartDetails.map(it => it.id + 'x' + it.qty).sort().join(',')].join('|');
      dupKey = 'ORD_' + Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, sig, Utilities.Charset.UTF_8));
      if (!data.forceDuplicate && CacheService.getScriptCache().get(dupKey)) {
        return { success: false, duplicate: true, message: 'Đơn này giống hệt một đơn vừa tạo cách đây chưa tới 3 phút (cùng khách, cùng sản phẩm, cùng tiền).' };
      }
    }
    const sh = _donHangSheet();
    // [GĐ4] đơn có ngày thuộc tháng đã lưu trữ + xóa nguồn: từ chối NGAY, trước khi hủy đơn cũ (khi sửa) hay ghi gì
    if (_wgMonthLocked_(data.orderDate || new Date())) return { success: false, message: WG_MSG_MONTH_LOCKED };
    let oldTotals = null;
    let oldCounted = true;

    if (editInfo && editInfo.startRow) {
      const chkEdit = _wgCheckBlock_(sh, editInfo.startRow, editInfo.rowCount, editInfo.fp);
      if (!chkEdit.ok) return { success: false, message: chkEdit.error };
      oldTotals = _readOrderBlockTotals(sh, editInfo.startRow, editInfo.rowCount);
      oldCounted = _isBlockCounted(sh, editInfo.startRow);
      const empName = (data.employeeName || '').toString().trim();
      const note = 'Đã SỬA lúc ' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'HH:mm dd/MM/yyyy') +
        (empName ? ' bởi ' + empName : '') + ' → thay bằng đơn mới bên dưới.';
      _cancelOrderRows(sh, editInfo.startRow, editInfo.rowCount, note);
    }

    // [MỚI] Khách CHƯA có mã: lưu vào sheet KhachMoiChoDuyet (chưa vào DataKhachSi) (không báo Zalo).
    // Làm TRƯỚC khi ghi đơn để lỗi cấp mã không để lại đơn mồ côi.
    let usedPending = false, pendingCode = '';
    if (data.isNewCustomer && !(editInfo && editInfo.startRow)) {
      const pr = createPendingCustomerInternal_(data);
      if (pr.error) return { success: false, message: pr.error };
      if (pr.pending) { usedPending = true; pendingCode = pr.code; }
      else { data.customerCode = pr.code; }         // khách đã có chính thức (trùng SĐT) -> dùng mã sẵn có
    } else if (data.customerCode && _pendFindByCode_(data.customerCode)) {
      usedPending = true; pendingCode = _normCode_(data.customerCode);   // khách chờ duyệt: chưa ghi vào DataKhachSi
    }

    _appendOrderRows(sh, data);

    const customerCode = usedPending ? pendingCode : _saveNewCustomerInternal(data.name, data.phone, data.address, data.priceType,
      data.city || '', data.taxCode || '', data.company || '', data.invoiceName || '',
      { customerCode: data.customerCode || '', codeGroup: data.codeGroup || '', codeFactory: data.codeFactory || '', cccd: data.cccd || '', email: data.email || '' });

    if (isDebt) {
      const ref = 'DH_' + new Date().getTime();
      _saveCongNoInternal(ref, data.name, data.phone, new Date().toISOString(), data.totalAmount, data.employeeName, data.priceType);
    }

    // [MỚI] cập nhật tổng hợp theo tháng - ghi nhẹ, không quét lại DonHang
    try {
      const newQty = (data.cartDetails || []).reduce((a, it) => a + (Number(it.qty) || 0), 0);
      let newDate = new Date();
      if (data.orderDate) { const d = new Date(data.orderDate); if (!isNaN(d.getTime())) newDate = d; }
      if (oldTotals && oldCounted) {
        _tongHopApplyDelta(oldTotals.date, -oldTotals.revenue, -1, -oldTotals.qty, oldTotals.phone);
      }
      // Đơn mới từ 01/10/2026 chưa được duyệt nên CHƯA cộng vào doanh thu; chỉ cộng khi bấm Duyệt.
      if (!_orderNeedsApproval(newDate)) {
        _tongHopApplyDelta(newDate, Number(data.totalAmount) || 0, 1, newQty, data.phone);
      }
    } catch (e2) { /* không chặn luồng chính nếu lỗi ghi tổng hợp */ }

    if (dupKey) { try { CacheService.getScriptCache().put(dupKey, '1', 180); } catch (e3) {} }
    let invoiceId = '';
    try { invoiceId = _invCreateForOrder_(data, customerCode || '', Number(data.totalAmount) || 0); } catch (e4) { Logger.log('Không tạo được dòng Theo dõi xuất HĐ: ' + e4); }
    return { success: true, customerCode: customerCode || '', invoiceId: invoiceId, pendingApproval: usedPending, message: editInfo && editInfo.startRow ? 'Đã hủy đơn cũ và lưu đơn thay thế thành công!' : (usedPending ? 'Đơn đã lưu. Khách mới đang chờ Admin/QLB2B duyệt.' : 'Đơn hàng đã lưu thành công!') };
  } catch (e) {
    throw new Error('Lỗi khi lưu đơn hàng: ' + e.toString());
  } finally {
    lock.releaseLock();
  }
}

// ════════════════════════════════════════════════════════════
//  THAY THẾ: cancelOrderOnly (thêm trừ vào TongHopThang)
// ════════════════════════════════════════════════════════════
function cancelOrderOnly(startRow, rowCount, employeeName, fp) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { throw new Error('Hệ thống đang bận, thử lại sau.'); }
  try {
    const sh = _donHangSheet();
    const chk = _wgCheckBlock_(sh, startRow, rowCount, fp);
    if (!chk.ok) return 'Lỗi: ' + chk.error;
    const totals = _readOrderBlockTotals(sh, startRow, rowCount);
    const wasCounted = _isBlockCounted(sh, startRow);
    const note = 'Đã HỦY HẲN lúc ' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'HH:mm dd/MM/yyyy') +
      (employeeName ? ' bởi ' + employeeName : '') + ' (không tạo đơn thay thế).';
    _cancelOrderRows(sh, startRow, rowCount, note);
    try {
      if (totals && wasCounted) _tongHopApplyDelta(totals.date, -totals.revenue, -1, -totals.qty, totals.phone);
    } catch (e2) {}
    return 'Đã hủy đơn hàng (không tạo đơn thay thế)!';
  } catch (e) {
    return 'Lỗi: ' + e.toString();
  } finally { lock.releaseLock(); }
}

// ════════════════════════════════════════════════════════════
//  THAY THẾ: getBusinessDashboard (đọc từ TongHopThang thay vì
//  quét toàn bộ 1 năm DonHang - CÙNG CẤU TRÚC TRẢ VỀ NHƯ CŨ, front-end
//  index.html KHÔNG cần sửa gì)
// ════════════════════════════════════════════════════════════
function getBusinessDashboard() {
  try {
    const now = new Date();
    const y = now.getFullYear(), m = now.getMonth();

    function startOfMonth(yr, mo) { return new Date(yr, mo, 1, 0, 0, 0, 0); }
    function endOfMonth(yr, mo) { return new Date(yr, mo + 1, 0, 23, 59, 59, 999); }
    function pct(cur, prev) { if (!prev) return cur ? 100 : 0; return (cur - prev) / prev * 100; }
    function mkey(yr, mo) { return yr + '-' + ('0' + (mo + 1)).slice(-2); }
    function emptyStat() { return { revenue: 0, orders: 0, qty: 0, aov: 0, customers: 0 }; }

    const tongHop = _loadTongHopMap();
    function statFromMap(key) { return tongHop[key] ? Object.assign({}, tongHop[key]) : emptyStat(); }
    function sumStats(keys) {
      let revenue = 0, orders = 0, qty = 0;
      keys.forEach(k => { const s = tongHop[k]; if (s) { revenue += s.revenue; orders += s.orders; qty += s.qty; } });
      return { revenue: revenue, orders: orders, qty: qty, aov: orders ? Math.round(revenue / orders) : 0, customers: 0 };
    }

    const thisMonthKey = mkey(y, m);
    let lmY = y, lmM = m - 1; if (lmM < 0) { lmM = 11; lmY--; }
    const lastMonthKey = mkey(lmY, lmM);

    const q = Math.floor(m / 3);
    const qMonths = [q * 3, q * 3 + 1, q * 3 + 2].map(mo => mkey(y, mo));
    let lq = q - 1, lqY = y; if (lq < 0) { lq = 3; lqY--; }
    const lqMonths = [lq * 3, lq * 3 + 1, lq * 3 + 2].map(mo => mkey(lqY, mo));

    const ytdMonths = []; for (let mo = 0; mo <= m; mo++) ytdMonths.push(mkey(y, mo));
    const ytdLastMonths = []; for (let mo = 0; mo <= m; mo++) ytdLastMonths.push(mkey(y - 1, mo));

    let thisMonth = statFromMap(thisMonthKey);
    let lastMonth = statFromMap(lastMonthKey);
    const thisQuarter = sumStats(qMonths);
    const lastQuarter = sumStats(lqMonths);
    const ytdThis = sumStats(ytdMonths);
    const ytdLast = sumStats(ytdLastMonths);

    const monthlySeries = [];
    for (let i = 11; i >= 0; i--) {
      let yy = y, mm = m - i; while (mm < 0) { mm += 12; yy--; }
      const key = mkey(yy, mm);
      const s = statFromMap(key);
      monthlySeries.push({ label: ('0' + (mm + 1)).slice(-2) + '/' + yy, revenue: s.revenue, orders: s.orders });
    }
    const seriesWithData = monthlySeries.filter(x => x.revenue > 0);
    const seriesAvg = seriesWithData.length ? seriesWithData.reduce((a, x) => a + x.revenue, 0) / seriesWithData.length : 0;
    monthlySeries.forEach(x => { x.pctVsAvg = seriesAvg ? ((x.revenue - seriesAvg) / seriesAvg * 100) : 0; });

    const cumThis = [], cumLast = [];
    let runThis = 0, runLast = 0;
    for (let mo = 0; mo < 12; mo++) {
      const keyThis = mkey(y, mo), keyLast = mkey(y - 1, mo);
      const sT = startOfMonth(y, mo);
      if (sT <= now) { runThis += statFromMap(keyThis).revenue; cumThis.push(runThis); } else { cumThis.push(null); }
      runLast += statFromMap(keyLast).revenue; cumLast.push(runLast);
    }

    // Chi tiết THÁNG NÀY - chỉ đọc DonHang trong phạm vi tháng hiện tại (nhẹ, không phình theo thời gian)
    const thisMonthStart = startOfMonth(y, m), thisMonthEnd = endOfMonth(y, m);
    const thisMonthOrders = _readDonHangGrouped(thisMonthStart.toISOString(), thisMonthEnd.toISOString(), null, true);
    const byEmp = {}, byPriceType = {}, byProduct = {};
    thisMonthOrders.forEach(o => {
      if (!byEmp[o.emp]) byEmp[o.emp] = { orders: 0, revenue: 0 };
      byEmp[o.emp].orders++; byEmp[o.emp].revenue += o.total;
      if (!byPriceType[o.priceType]) byPriceType[o.priceType] = { orders: 0, revenue: 0 };
      byPriceType[o.priceType].orders++; byPriceType[o.priceType].revenue += o.total;
      o.items.forEach(it => {
        if (!byProduct[it.name]) byProduct[it.name] = { qty: 0, revenue: 0 };
        byProduct[it.name].qty += it.qty; byProduct[it.name].revenue += it.price;
      });
    });
    const empArr = Object.keys(byEmp).map(k => ({ name: k, orders: byEmp[k].orders, revenue: byEmp[k].revenue })).sort((a, b) => b.revenue - a.revenue);
    const priceTypeArr = Object.keys(byPriceType).map(k => ({ name: k, orders: byPriceType[k].orders, revenue: byPriceType[k].revenue })).sort((a, b) => b.revenue - a.revenue);
    const productArr = Object.keys(byProduct).map(k => ({ name: k, qty: byProduct[k].qty, revenue: byProduct[k].revenue })).sort((a, b) => b.revenue - a.revenue).slice(0, 10);

    // Doanh thu nhân viên THÁNG TRƯỚC - chỉ đọc đúng 1 tháng (phục vụ cảnh báo so sánh)
    let lmY2 = y, lmM2 = m - 1; if (lmM2 < 0) { lmM2 = 11; lmY2--; }
    const lastMonthStart = startOfMonth(lmY2, lmM2), lastMonthEnd = endOfMonth(lmY2, lmM2);
    const lastMonthOrders = _readDonHangGrouped(lastMonthStart.toISOString(), lastMonthEnd.toISOString(), null, true);

    // [FIX v6.2] Tự phục hồi nếu TongHopThang trống/chưa đồng bộ - tính lại
    // trực tiếp từ DonHang cho tháng này & tháng trước, đảm bảo KPI luôn
    // hiển thị đúng số liệu ngay cả khi chưa chạy rebuildTongHopThang().
    if (thisMonth.revenue === 0 && thisMonthOrders.length > 0) {
      let rev=0, qty=0; const cust={};
      thisMonthOrders.forEach(o=>{ rev+=o.total; o.items.forEach(it=>qty+=it.qty); if(o.phone) cust[o.phone]=1; });
      thisMonth = { revenue: rev, orders: thisMonthOrders.length, qty: qty, aov: Math.round(rev/thisMonthOrders.length), customers: Object.keys(cust).length };
    }
    if (lastMonth.revenue === 0 && lastMonthOrders.length > 0) {
      let rev=0, qty=0; const cust={};
      lastMonthOrders.forEach(o=>{ rev+=o.total; o.items.forEach(it=>qty+=it.qty); if(o.phone) cust[o.phone]=1; });
      lastMonth = { revenue: rev, orders: lastMonthOrders.length, qty: qty, aov: Math.round(rev/lastMonthOrders.length), customers: Object.keys(cust).length };
    }

    const byEmpLast = {};
    lastMonthOrders.forEach(o => { byEmpLast[o.emp] = (byEmpLast[o.emp] || 0) + o.total; });

    const lastOrderDate = _getLastOrderDate();
    const daysSinceLastOrder = lastOrderDate ? Math.floor((now - lastOrderDate) / (1000 * 60 * 60 * 24)) : null;

    const warnings = [];
    const momPct = pct(thisMonth.revenue, lastMonth.revenue);
    if (lastMonth.revenue > 0) {
      if (momPct <= -15) warnings.push({ level: 'danger', text: 'Doanh thu tháng này giảm mạnh ' + Math.abs(momPct).toFixed(1) + '% so với tháng trước - cần rà soát ngay nguồn khách, chính sách giá và hoạt động của đối thủ.' });
      else if (momPct <= -5) warnings.push({ level: 'warning', text: 'Doanh thu tháng này giảm ' + Math.abs(momPct).toFixed(1) + '% so với tháng trước - cần theo dõi sát trong các ngày tới.' });
      else if (momPct >= 20) warnings.push({ level: 'success', text: 'Doanh thu tháng này tăng trưởng tốt, +' + momPct.toFixed(1) + '% so với tháng trước.' });
    }
    const qoqPct = pct(thisQuarter.revenue, lastQuarter.revenue);
    if (lastQuarter.revenue > 0 && qoqPct <= -10) warnings.push({ level: 'warning', text: 'Doanh thu quý này giảm ' + Math.abs(qoqPct).toFixed(1) + '% so với quý trước.' });

    const aovPct = pct(thisMonth.aov, lastMonth.aov);
    if (lastMonth.aov > 0 && aovPct <= -10) warnings.push({ level: 'warning', text: 'Giá trị đơn hàng trung bình (AOV) giảm ' + Math.abs(aovPct).toFixed(1) + '% so với tháng trước - khách đang mua ít hơn mỗi lần đặt.' });

    const orderCountPct = pct(thisMonth.orders, lastMonth.orders);
    if (lastMonth.orders > 0 && orderCountPct <= -15) warnings.push({ level: 'warning', text: 'Số lượng đơn hàng giảm ' + Math.abs(orderCountPct).toFixed(1) + '% so với tháng trước - tốc độ đặt hàng đang chậm lại.' });

    if (daysSinceLastOrder !== null && daysSinceLastOrder >= 3) warnings.push({ level: 'danger', text: 'Đã ' + daysSinceLastOrder + ' ngày hệ thống chưa ghi nhận đơn hàng mới - kiểm tra ngay kênh bán hàng / trang đặt hàng.' });

    Object.keys(byEmpLast).forEach(name => {
      const cur = (byEmp[name] ? byEmp[name].revenue : 0);
      const prev = byEmpLast[name];
      if (prev >= 500000) {
        const p = pct(cur, prev);
        if (p <= -30) warnings.push({ level: 'warning', text: 'Nhân viên ' + name + ' có doanh thu tháng này giảm ' + Math.abs(p).toFixed(1) + '% so với tháng trước.' });
      }
    });

    const yoyPct = pct(ytdThis.revenue, ytdLast.revenue);
    if (ytdLast.revenue > 0 && yoyPct <= -10) warnings.push({ level: 'danger', text: 'Lũy kế năm nay đang thấp hơn ' + Math.abs(yoyPct).toFixed(1) + '% so với cùng kỳ năm trước.' });
    else if (ytdLast.revenue > 0 && yoyPct >= 15) warnings.push({ level: 'success', text: 'Lũy kế năm nay đang cao hơn cùng kỳ năm trước ' + yoyPct.toFixed(1) + '% - đà tăng trưởng tốt.' });

    if (!warnings.length) warnings.push({ level: 'success', text: 'Không phát hiện dấu hiệu bất thường - tình hình kinh doanh đang ổn định.' });

    return {
      thisMonth: thisMonth, lastMonth: lastMonth, momPct: momPct,
      thisQuarter: thisQuarter, lastQuarter: lastQuarter, qoqPct: qoqPct,
      ytdThis: ytdThis, ytdLast: ytdLast, yoyPct: yoyPct,
      monthlySeries: monthlySeries, seriesAvg: seriesAvg, cumThis: cumThis, cumLast: cumLast,
      empArr: empArr, priceTypeArr: priceTypeArr, productArr: productArr,
      daysSinceLastOrder: daysSinceLastOrder, warnings: warnings,
      generatedAt: now.toISOString()
    };
  } catch (e) {
    return { error: e.toString() };
  }
}
/** ============================================================
 *  9 SẠCH - BỔ SUNG ĐỢT 2:
 *  - Chữ ký nhân viên (vẽ tay, lưu lại dùng cho lần sau)
 *  - Khách cũ/mới theo nhân viên (30 ngày)
 *  - Xếp hạng khách hàng theo tháng
 *  - Dựng lại DataKhachSi từ DonHang (để phân loại khách cũ/mới chính xác)
 *  - getBusinessDashboard(): thêm avgPerDay + projected cho từng tháng
 *
 *  CÁCH DÙNG: dán TOÀN BỘ file này vào cuối Code.gs (sau phần đã thêm
 *  TongHopThang_Update.gs ở bước trước). Hàm getBusinessDashboard() ở
 *  đây sẽ THAY THẾ (ghi đè) bản trước đó - xóa bản cũ trước khi dán.
 *
 *  CHẠY 1 LẦN sau khi dán xong:
 *   1) backfillDataKhachSiFromDonHang()  -> để khách cũ/mới phân loại
 *      chính xác kể cả với các đơn vừa import từ file Excel cũ.
 * ============================================================ */

// ════════════════════════════════════════════════════════════
//  CHỮ KÝ NHÂN VIÊN
// ════════════════════════════════════════════════════════════
const SIGNATURE_HEADERS = ['Tên Hiển Thị', 'Chữ Ký (Base64 PNG)', 'Cập Nhật Lúc'];

function _signatureSheet() {
  return _sheet('ChuKyNhanVien', SIGNATURE_HEADERS);
}

function saveEmployeeSignature(employeeName, base64PngData) {
  try {
    if (!employeeName) return { success: false, error: 'Thiếu tên nhân viên.' };
    const sh = _signatureSheet();
    const lastRow = sh.getLastRow();
    const names = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 1).getValues() : [];
    for (let i = 0; i < names.length; i++) {
      if ((names[i][0] || '').toString().trim() === employeeName.toString().trim()) {
        sh.getRange(i + 2, 2, 1, 2).setValues([[base64PngData, new Date()]]);
        return { success: true };
      }
    }
    sh.appendRow([employeeName, base64PngData, new Date()]);
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function getEmployeeSignature(employeeName) {
  try {
    if (!employeeName) return null;
    const sh = _signatureSheet();
    const lastRow = sh.getLastRow();
    if (lastRow < 2) return null;
    const data = sh.getRange(2, 1, lastRow - 1, 2).getValues();
    for (let i = 0; i < data.length; i++) {
      if ((data[i][0] || '').toString().trim() === employeeName.toString().trim()) {
        return data[i][1] || null;
      }
    }
    return null;
  } catch (e) { return null; }
}

// ════════════════════════════════════════════════════════════
//  KHÁCH CŨ / KHÁCH MỚI THEO NHÂN VIÊN (30 NGÀY GẦN NHẤT)
//  Khách cũ  = đã có trong DataKhachSi (Ngày đặt đầu) hơn 30 ngày
//  Khách mới = Ngày đặt đầu trong vòng 30 ngày gần đây
// ════════════════════════════════════════════════════════════
function _loadCustomerFirstOrderMap() {
  const sh = _dataKhachSiSheet();
  const map = {};
  if (!sh || sh.getLastRow() < 2) return map;
  const data = sh.getRange(2, 1, sh.getLastRow() - 1, 18).getValues();
  data.forEach(r => {
    const phone = (r[DKS_COL.PHONE - 1] || '').toString().replace(/\D/g, '');
    const first = r[DKS_COL.FIRST_ORDER - 1];
    if (phone && first) {
      const d = first instanceof Date ? first : new Date(first);
      if (!isNaN(d.getTime())) map[phone] = d;
    }
  });
  return map;
}

// [MỚI v6.2] Đọc cờ phân loại THỦ CÔNG từ cột 19 DataKhachSi
function _loadCustomerManualSegMap() {
  const sh = _dataKhachSiSheet();
  const map = {};
  if (!sh || sh.getLastRow() < 2) return map;
  const lastRow = sh.getLastRow();
  const data = sh.getRange(2, 1, lastRow - 1, DKS_COL_MANUAL_SEG).getValues();
  data.forEach(r => {
    const phone = (r[DKS_COL.PHONE - 1] || '').toString().replace(/\D/g, '');
    const seg = (r[DKS_COL_MANUAL_SEG - 1] || '').toString().trim();
    if (phone && seg) map[phone] = seg;
  });
  return map;
}

// [MỚI v6.2] Đánh dấu thủ công 1 khách hàng là Khách Cũ / Khách Mới
function setCustomerManualSegment(phone, name, segType) {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh) return { success: false, error: 'Không tìm thấy sheet DataKhachSi.' };
    const pc = (phone || '').toString().replace(/[^0-9]/g, '');
    if (!pc) return { success: false, error: 'Thiếu số điện thoại khách hàng.' };
    const seg = (segType === 'Cu' || segType === 'Moi') ? segType : '';
    const lastRow = sh.getLastRow();
    const data = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 2).getValues() : [];
    for (let i = 0; i < data.length; i++) {
      const rowPhone = (data[i][DKS_COL.PHONE - 1] || '').toString().replace(/[^0-9]/g, '');
      if (rowPhone === pc) {
        sh.getRange(i + 2, DKS_COL_MANUAL_SEG).setValue(seg);
        return { success: true };
      }
    }
    const newRow = sh.getLastRow() + 1;
    const arr = new Array(DKS_COL_MANUAL_SEG).fill('');
    arr[DKS_COL.NAME - 1] = name || '';
    arr[DKS_COL.PHONE - 1] = pc;
    arr[DKS_COL_MANUAL_SEG - 1] = seg;
    sh.getRange(newRow, 2).setNumberFormat('@');
    sh.getRange(newRow, 1, 1, DKS_COL_MANUAL_SEG).setValues([arr]);
    return { success: true };
  } catch (e) { return { success: false, error: e.toString() }; }
}

function getCustomerSegmentsByEmployee(fromDate, toDate) {
  try {
    const now = new Date();
    const from = fromDate ? new Date(fromDate) : new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const to = toDate ? new Date(toDate) : now;
    to.setHours(23, 59, 59, 999);
    const orders = _readDonHangGrouped(from.toISOString(), to.toISOString(), null, true);
    const firstOrderMap = _loadCustomerFirstOrderMap();
    const manualMap = _loadCustomerManualSegMap(); // [MỚI] ghi đè phân loại tự động

    const empMap = {};
    orders.forEach(o => {
      const phone = (o.phone || '').toString().replace(/\D/g, '');
      if (!phone) return;
      const emp = o.emp || '(Không rõ)';
      const manual = manualMap[phone] || '';
      let seg;
      if (manual === 'Cu') seg = 'old';
      else if (manual === 'Moi') seg = 'new';
      else {
        const firstOrder = firstOrderMap[phone];
        const isOld = firstOrder ? (firstOrder < from) : false;
        seg = isOld ? 'old' : 'new';
      }
      if (!empMap[emp]) empMap[emp] = { old: {}, new: {} };
      if (!empMap[emp][seg][phone]) empMap[emp][seg][phone] = { name: o.name, phone: o.phone, revenue: 0, orders: 0, manualSeg: manual };
      empMap[emp][seg][phone].revenue += o.total;
      empMap[emp][seg][phone].orders += 1;
    });

    return Object.keys(empMap).map(emp => {
      const oldList = Object.values(empMap[emp].old).sort((a, b) => b.revenue - a.revenue);
      const newList = Object.values(empMap[emp].new).sort((a, b) => b.revenue - a.revenue);
      return {
        employee: emp,
        oldCount: oldList.length, newCount: newList.length,
        oldCustomers: oldList, newCustomers: newList
      };
    }).sort((a, b) => (b.oldCount + b.newCount) - (a.oldCount + a.newCount));
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  XẾP HẠNG KHÁCH HÀNG THEO THÁNG
// ════════════════════════════════════════════════════════════
function getCustomerRankingByMonth(monthKey) {
  try {
    const parts = (monthKey || '').split('-');
    if (parts.length !== 2) return { month: monthKey, byRevenue: [], byOrders: [] };
    const y = parseInt(parts[0]), m = parseInt(parts[1]) - 1;
    const from = new Date(y, m, 1, 0, 0, 0, 0);
    const to = new Date(y, m + 1, 0, 23, 59, 59, 999);
    const orders = _readDonHangGrouped(from.toISOString(), to.toISOString(), null, true);

    const byCust = {};
    orders.forEach(o => {
      const key = (o.phone || o.name || 'Khách lẻ').toString();
      if (!byCust[key]) byCust[key] = { name: o.name, phone: o.phone, orders: 0, revenue: 0 };
      byCust[key].orders++;
      byCust[key].revenue += o.total;
    });

    const byRevenue = Object.values(byCust).sort((a, b) => b.revenue - a.revenue).slice(0, 20);
    const byOrders = Object.values(byCust).slice().sort((a, b) => b.orders - a.orders).slice(0, 20);
    return { month: monthKey, byRevenue: byRevenue, byOrders: byOrders };
  } catch (e) { return { month: monthKey, byRevenue: [], byOrders: [], error: e.toString() }; }
}
// [MỚI v6.2] Chi tiết đơn hàng RÚT GỌN của 1 khách trong 1 tháng - dùng
// khi bấm tên khách ở bảng Top Doanh Thu / Top Số Đơn (trang Khách Hàng).
function getCustomerOrderBrief(phoneOrName, monthKey) {
  try {
    const parts = (monthKey || '').split('-');
    let from = null, to = null;
    if (parts.length === 2) {
      const y = parseInt(parts[0]), m = parseInt(parts[1]) - 1;
      from = new Date(y, m, 1, 0, 0, 0, 0);
      to = new Date(y, m + 1, 0, 23, 59, 59, 999);
    }
    const orders = _readDonHangGrouped(from ? from.toISOString() : null, to ? to.toISOString() : null, null, true);
    const key = (phoneOrName || '').toString().trim();
    const rows = orders.filter(o => (o.phone || '').toString() === key || (o.name || '').toString() === key)
      .map(o => ({ date: o.date, qty: o.items.reduce((a, it) => a + it.qty, 0), total: o.total }));
    rows.sort((a, b) => new Date(a.date) - new Date(b.date));
    return rows;
  } catch (e) { return []; }
}

function getAvailableMonthsForRanking() {
  try {
    const sh = _tongHopSheet();
    const lastRow = sh.getLastRow();
    if (lastRow < 2) return [];
    const data = sh.getRange(2, 1, lastRow - 1, 1).getValues();
    return data.map(r => r[0]).filter(Boolean).sort().reverse();
  } catch (e) { return []; }
}

// ════════════════════════════════════════════════════════════
//  [CHẠY TAY 1 LẦN] Dựng lại DataKhachSi từ dữ liệu DonHang hiện có -
//  để phân loại khách cũ/mới chính xác kể cả với đơn vừa import.
//  Chỉ điền "Ngày đặt đầu" nếu ô đó đang trống hoặc muộn hơn ngày
//  thực tế tìm được - KHÔNG ghi đè dữ liệu tên/địa chỉ đã có.
// ════════════════════════════════════════════════════════════
function backfillDataKhachSiFromDonHang() {
  const src = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!src || src.getLastRow() < 2) { Logger.log('DonHang trống.'); return; }
  let data = src.getRange(2, 1, src.getLastRow() - 1, READ_WIDTH).getValues();
  try { if (typeof _ldExtraRows_ === 'function') data = _ldExtraRows_(null, null).rows.concat(data); } catch (eA) { Logger.log('Lỗi đọc lưu trữ: ' + eA); }
  const firstMap = {};
  data.forEach(r => {
    if (!r[0] || r[0] === '') return;
    if ((r[COL_STATUS - 1] || '') === 'Huy') return;
    const phone = (r[2] || '').toString().replace(/\D/g, '');
    if (!phone) return;
    const d = r[0] instanceof Date ? r[0] : new Date(r[0]);
    if (!firstMap[phone] || d < firstMap[phone].date) {
      firstMap[phone] = { date: d, name: r[1] || '', address: r[3] || '' };
    }
  });

  const sh = _dataKhachSiSheet();
  if (!sh) { Logger.log('Không tìm thấy DataKhachSi.'); return; }
  const lastRow = sh.getLastRow();
  const existing = lastRow > 1 ? sh.getRange(2, 1, lastRow - 1, 18).getValues() : [];
  const existingPhoneIdx = {};
  existing.forEach((r, i) => {
    const p = (r[DKS_COL.PHONE - 1] || '').toString().replace(/\D/g, '');
    if (p) existingPhoneIdx[p] = i + 2;
  });

  let updated = 0, added = 0;
  const newRows = [];
  Object.keys(firstMap).forEach(phone => {
    const info = firstMap[phone];
    if (existingPhoneIdx[phone]) {
      const rowIdx = existingPhoneIdx[phone];
      const cur = sh.getRange(rowIdx, DKS_COL.FIRST_ORDER, 1, 1).getValue();
      if (!cur || cur === '' || (cur instanceof Date && info.date < cur)) {
        sh.getRange(rowIdx, DKS_COL.FIRST_ORDER).setValue(info.date);
        updated++;
      }
    } else {
      const arr = new Array(18).fill('');
      arr[DKS_COL.NAME - 1] = info.name;
      arr[DKS_COL.PHONE - 1] = phone;
      arr[DKS_COL.ADDRESS - 1] = info.address;
      arr[DKS_COL.FIRST_ORDER - 1] = info.date;
      arr[DKS_COL.LAST_ORDER - 1] = info.date;
      newRows.push(arr);
      added++;
    }
  });
  if (newRows.length) {
    const startRow = sh.getLastRow() + 1;
    sh.getRange(startRow, 2, newRows.length, 1).setNumberFormat('@');
    sh.getRange(startRow, 1, newRows.length, 18).setValues(newRows);
  }
  Logger.log('Đã cập nhật ngày đặt đầu cho ' + updated + ' khách hàng, thêm mới ' + added + ' khách hàng vào DataKhachSi.');
}

// ════════════════════════════════════════════════════════════
//  THAY THẾ getBusinessDashboard(): thêm avgPerDay + projected
//  cho mỗi tháng trong monthlySeries (TB doanh thu/ngày + dự kiến).
//  Phần còn lại giữ nguyên logic đọc từ TongHopThang như bản trước.
// ════════════════════════════════════════════════════════════
function getBusinessDashboard() {
  try {
    const now = new Date();
    const y = now.getFullYear(), m = now.getMonth();

    function startOfMonth(yr, mo) { return new Date(yr, mo, 1, 0, 0, 0, 0); }
    function endOfMonth(yr, mo) { return new Date(yr, mo + 1, 0, 23, 59, 59, 999); }
    function pct(cur, prev) { if (!prev) return cur ? 100 : 0; return (cur - prev) / prev * 100; }
    function mkey(yr, mo) { return yr + '-' + ('0' + (mo + 1)).slice(-2); }
    function emptyStat() { return { revenue: 0, orders: 0, qty: 0, aov: 0, customers: 0 }; }
    function daysInMonth(yr, mo) { return new Date(yr, mo + 1, 0).getDate(); }

    const tongHop = _loadTongHopMap();
    function statFromMap(key) { return tongHop[key] ? Object.assign({}, tongHop[key]) : emptyStat(); }
    function sumStats(keys) {
      let revenue = 0, orders = 0, qty = 0;
      keys.forEach(k => { const s = tongHop[k]; if (s) { revenue += s.revenue; orders += s.orders; qty += s.qty; } });
      return { revenue: revenue, orders: orders, qty: qty, aov: orders ? Math.round(revenue / orders) : 0, customers: 0 };
    }

    const thisMonthKey = mkey(y, m);
    let lmY = y, lmM = m - 1; if (lmM < 0) { lmM = 11; lmY--; }
    const lastMonthKey = mkey(lmY, lmM);

    const q = Math.floor(m / 3);
    const qMonths = [q * 3, q * 3 + 1, q * 3 + 2].map(mo => mkey(y, mo));
    let lq = q - 1, lqY = y; if (lq < 0) { lq = 3; lqY--; }
    const lqMonths = [lq * 3, lq * 3 + 1, lq * 3 + 2].map(mo => mkey(lqY, mo));

    const ytdMonths = []; for (let mo = 0; mo <= m; mo++) ytdMonths.push(mkey(y, mo));
    const ytdLastMonths = []; for (let mo = 0; mo <= m; mo++) ytdLastMonths.push(mkey(y - 1, mo));

    const thisMonth = statFromMap(thisMonthKey);
    const lastMonth = statFromMap(lastMonthKey);
    const thisQuarter = sumStats(qMonths);
    const lastQuarter = sumStats(lqMonths);
    const ytdThis = sumStats(ytdMonths);
    const ytdLast = sumStats(ytdLastMonths);

    const monthlySeries = [];
    for (let i = 11; i >= 0; i--) {
      let yy = y, mm = m - i; while (mm < 0) { mm += 12; yy--; }
      const key = mkey(yy, mm);
      const s = statFromMap(key);
      const dim = daysInMonth(yy, mm);
      const isCurrentMonth = (yy === y && mm === m);
      const daysElapsed = isCurrentMonth ? now.getDate() : dim;
      const avgPerDay = daysElapsed ? (s.revenue / daysElapsed) : 0;
      const projected = isCurrentMonth ? avgPerDay * dim : s.revenue;
      monthlySeries.push({
        label: ('0' + (mm + 1)).slice(-2) + '/' + yy, revenue: s.revenue, orders: s.orders,
        avgPerDay: avgPerDay, projected: projected
      });
    }
    const seriesWithData = monthlySeries.filter(x => x.revenue > 0);
    const seriesAvg = seriesWithData.length ? seriesWithData.reduce((a, x) => a + x.revenue, 0) / seriesWithData.length : 0;
    monthlySeries.forEach(x => { x.pctVsAvg = seriesAvg ? ((x.revenue - seriesAvg) / seriesAvg * 100) : 0; });

    const cumThis = [], cumLast = [];
    let runThis = 0, runLast = 0;
    for (let mo = 0; mo < 12; mo++) {
      const keyThis = mkey(y, mo), keyLast = mkey(y - 1, mo);
      const sT = startOfMonth(y, mo);
      if (sT <= now) { runThis += statFromMap(keyThis).revenue; cumThis.push(runThis); } else { cumThis.push(null); }
      runLast += statFromMap(keyLast).revenue; cumLast.push(runLast);
    }

    const thisMonthStart = startOfMonth(y, m), thisMonthEnd = endOfMonth(y, m);
    const thisMonthOrders = _readDonHangGrouped(thisMonthStart.toISOString(), thisMonthEnd.toISOString(), null, true);
    const byEmp = {}, byPriceType = {}, byProduct = {};
    thisMonthOrders.forEach(o => {
      if (!byEmp[o.emp]) byEmp[o.emp] = { orders: 0, revenue: 0 };
      byEmp[o.emp].orders++; byEmp[o.emp].revenue += o.total;
      if (!byPriceType[o.priceType]) byPriceType[o.priceType] = { orders: 0, revenue: 0 };
      byPriceType[o.priceType].orders++; byPriceType[o.priceType].revenue += o.total;
      o.items.forEach(it => {
        if (!byProduct[it.name]) byProduct[it.name] = { qty: 0, revenue: 0 };
        byProduct[it.name].qty += it.qty; byProduct[it.name].revenue += it.price;
      });
    });
    const empArr = Object.keys(byEmp).map(k => ({ name: k, orders: byEmp[k].orders, revenue: byEmp[k].revenue })).sort((a, b) => b.revenue - a.revenue);
    const priceTypeArr = Object.keys(byPriceType).map(k => ({ name: k, orders: byPriceType[k].orders, revenue: byPriceType[k].revenue })).sort((a, b) => b.revenue - a.revenue);
    const productArr = Object.keys(byProduct).map(k => ({ name: k, qty: byProduct[k].qty, revenue: byProduct[k].revenue })).sort((a, b) => b.revenue - a.revenue).slice(0, 10);

    let lmY2 = y, lmM2 = m - 1; if (lmM2 < 0) { lmM2 = 11; lmY2--; }
    const lastMonthStart = startOfMonth(lmY2, lmM2), lastMonthEnd = endOfMonth(lmY2, lmM2);
    const lastMonthOrders = _readDonHangGrouped(lastMonthStart.toISOString(), lastMonthEnd.toISOString(), null, true);
    const byEmpLast = {};
    lastMonthOrders.forEach(o => { byEmpLast[o.emp] = (byEmpLast[o.emp] || 0) + o.total; });

    const lastOrderDate = _getLastOrderDate();
    const daysSinceLastOrder = lastOrderDate ? Math.floor((now - lastOrderDate) / (1000 * 60 * 60 * 24)) : null;

    const warnings = [];
    const momPct = pct(thisMonth.revenue, lastMonth.revenue);
    if (lastMonth.revenue > 0) {
      if (momPct <= -15) warnings.push({ level: 'danger', text: 'Doanh thu tháng này giảm mạnh ' + Math.abs(momPct).toFixed(1) + '% so với tháng trước - cần rà soát ngay nguồn khách, chính sách giá và hoạt động của đối thủ.' });
      else if (momPct <= -5) warnings.push({ level: 'warning', text: 'Doanh thu tháng này giảm ' + Math.abs(momPct).toFixed(1) + '% so với tháng trước - cần theo dõi sát trong các ngày tới.' });
      else if (momPct >= 20) warnings.push({ level: 'success', text: 'Doanh thu tháng này tăng trưởng tốt, +' + momPct.toFixed(1) + '% so với tháng trước.' });
    }
    const qoqPct = pct(thisQuarter.revenue, lastQuarter.revenue);
    if (lastQuarter.revenue > 0 && qoqPct <= -10) warnings.push({ level: 'warning', text: 'Doanh thu quý này giảm ' + Math.abs(qoqPct).toFixed(1) + '% so với quý trước.' });

    const aovPct = pct(thisMonth.aov, lastMonth.aov);
    if (lastMonth.aov > 0 && aovPct <= -10) warnings.push({ level: 'warning', text: 'Giá trị đơn hàng trung bình (AOV) giảm ' + Math.abs(aovPct).toFixed(1) + '% so với tháng trước - khách đang mua ít hơn mỗi lần đặt.' });

    const orderCountPct = pct(thisMonth.orders, lastMonth.orders);
    if (lastMonth.orders > 0 && orderCountPct <= -15) warnings.push({ level: 'warning', text: 'Số lượng đơn hàng giảm ' + Math.abs(orderCountPct).toFixed(1) + '% so với tháng trước - tốc độ đặt hàng đang chậm lại.' });

    if (daysSinceLastOrder !== null && daysSinceLastOrder >= 3) warnings.push({ level: 'danger', text: 'Đã ' + daysSinceLastOrder + ' ngày hệ thống chưa ghi nhận đơn hàng mới - kiểm tra ngay kênh bán hàng / trang đặt hàng.' });

    Object.keys(byEmpLast).forEach(name => {
      const cur = (byEmp[name] ? byEmp[name].revenue : 0);
      const prev = byEmpLast[name];
      if (prev >= 500000) {
        const p = pct(cur, prev);
        if (p <= -30) warnings.push({ level: 'warning', text: 'Nhân viên ' + name + ' có doanh thu tháng này giảm ' + Math.abs(p).toFixed(1) + '% so với tháng trước.' });
      }
    });

    const yoyPct = pct(ytdThis.revenue, ytdLast.revenue);
    if (ytdLast.revenue > 0 && yoyPct <= -10) warnings.push({ level: 'danger', text: 'Lũy kế năm nay đang thấp hơn ' + Math.abs(yoyPct).toFixed(1) + '% so với cùng kỳ năm trước.' });
    else if (ytdLast.revenue > 0 && yoyPct >= 15) warnings.push({ level: 'success', text: 'Lũy kế năm nay đang cao hơn cùng kỳ năm trước ' + yoyPct.toFixed(1) + '% - đà tăng trưởng tốt.' });

    if (!warnings.length) warnings.push({ level: 'success', text: 'Không phát hiện dấu hiệu bất thường - tình hình kinh doanh đang ổn định.' });

    return {
      thisMonth: thisMonth, lastMonth: lastMonth, momPct: momPct,
      thisQuarter: thisQuarter, lastQuarter: lastQuarter, qoqPct: qoqPct,
      ytdThis: ytdThis, ytdLast: ytdLast, yoyPct: yoyPct,
      monthlySeries: monthlySeries, seriesAvg: seriesAvg, cumThis: cumThis, cumLast: cumLast,
      empArr: empArr, priceTypeArr: priceTypeArr, productArr: productArr,
      daysSinceLastOrder: daysSinceLastOrder, warnings: warnings,
      generatedAt: now.toISOString()
    };
  } catch (e) {
    return { error: e.toString() };
  }
}
// [MỚI v6.2] Cho Admin bấm nút trên giao diện để dựng lại TongHopThang
// (Quý/YTD/12 tháng) mà không cần vào Apps Script Editor.
function rebuildTongHopThangFromClient() {
  rebuildTongHopThang();
  return 'Đã đồng bộ lại dữ liệu tổng hợp theo tháng thành công!';
}
// ════════════════════════════════════════════════════════════
//  [MỚI] DATA KHÁCH SỈ - XEM & SỬA TRỰC TIẾP TRÊN SHEET DataKhachSi
// ════════════════════════════════════════════════════════════
function getAllCustomersList() {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh || sh.getLastRow() < 2) return [];
    const lastRow = sh.getLastRow();
    const data = sh.getRange(2, 1, lastRow - 1, DKS_TOTAL_COLS).getValues();
    const out = [];
    data.forEach((r, i) => {
      const phone = (r[DKS_COL.PHONE - 1] || '').toString();
      const name = (r[DKS_COL.NAME - 1] || '').toString();
      if (!phone && !name) return;
      out.push({
        sheetRow: i + 2,
        name: name,
        phone: phone,
        address: (r[DKS_COL.ADDRESS - 1] || '').toString(),
        customerType: (r[DKS_COL.LOAI_KHACH_SI - 1] || '').toString(),
        taxCode: (r[DKS_COL.TAX - 1] || '').toString(),
        company: (r[DKS_COL.COMPANY - 1] || '').toString(),
        invoiceName: (r[DKS_COL.INVOICE_NAME - 1] || '').toString(),
        cccd: (r[DKS_COL.CCCD - 1] || '').toString(),
        email: (r[DKS_COL.EMAIL - 1] || '').toString(),
        description: (r[DKS_COL.DESCRIPTION - 1] || '').toString(),
        manualSeg: (r[DKS_COL_MANUAL_SEG - 1] || '').toString(),
        code: (r[DKS_COL.CODE - 1] || '').toString(),
        factory: (r[DKS_COL.FACTORY - 1] || '').toString(),
        prov: (r[DKS_COL.PROV - 1] || '').toString(),
        group: (r[DKS_COL.GROUP - 1] || '').toString(),
        oldCode: (r[DKS_COL.OLD_CODE - 1] || '').toString(),
        firstOrder: _clean(r[DKS_COL.FIRST_ORDER - 1]),
        lastOrder: _clean(r[DKS_COL.LAST_ORDER - 1])
      });
    });
    out.sort((a, b) => new Date(b.lastOrder || 0) - new Date(a.lastOrder || 0));
    return out;
  } catch (e) { return { error: e.toString() }; }
}
function updateCustomerRecord(sheetRow, data) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _dataKhachSiSheet();
    if (!sh) return { success: false, error: 'Không tìm thấy sheet DataKhachSi.' };
    const row = parseInt(sheetRow);
    if (!row || row < 2 || row > sh.getLastRow()) return { success: false, error: 'Dòng không hợp lệ.' };

    const newPhone = (data.phone || '').toString().replace(/[^0-9]/g, '');
    const curCode = (sh.getRange(row, DKS_COL.CODE).getValue() || '').toString().trim();
    if (!newPhone && !curCode) return { success: false, error: 'Số điện thoại không được để trống (khách chưa có mã KH).' };

    const lastRow = sh.getLastRow();
    const allPhones = sh.getRange(2, DKS_COL.PHONE, lastRow - 1, 1).getValues();
    for (let i = 0; i < allPhones.length; i++) {
      const rIdx = i + 2;
      if (rIdx === row) continue;
      const p = (allPhones[i][0] || '').toString().replace(/[^0-9]/g, '');
      if (newPhone && p && p === newPhone) return { success: false, error: 'Số điện thoại này đã thuộc về 1 khách sỉ khác (dòng ' + rIdx + ').' };
    }

    if (data.email && !_cleanEmail_(data.email)) return { success: false, error: 'Email không hợp lệ.' };
    // [FIX] Ép văn bản cho SĐT / MST / CCCD trước khi ghi
    sh.getRange(row, DKS_COL.PHONE).setNumberFormat('@');
    sh.getRange(row, DKS_COL.TAX).setNumberFormat('@');
    sh.getRange(row, DKS_COL.CCCD).setNumberFormat('@');

    sh.getRange(row, DKS_COL.NAME).setValue((data.name || '').toString());
    sh.getRange(row, DKS_COL.PHONE).setValue(newPhone);
    sh.getRange(row, DKS_COL.ADDRESS).setValue((data.address || '').toString());
    sh.getRange(row, DKS_COL.LOAI_KHACH_SI).setValue((data.customerType || '').toString());
    sh.getRange(row, DKS_COL.TAX).setValue((data.taxCode || '').toString());
    sh.getRange(row, DKS_COL.COMPANY).setValue((data.company || '').toString());
    sh.getRange(row, DKS_COL.INVOICE_NAME).setValue((data.invoiceName || '').toString());
    sh.getRange(row, DKS_COL.CCCD).setValue((data.cccd || '').toString());
    sh.getRange(row, DKS_COL.DESCRIPTION).setValue((data.description || '').toString());
    if (data.email !== undefined) sh.getRange(row, DKS_COL.EMAIL).setValue(_cleanEmail_(data.email));
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

// [MỚI] Xóa vĩnh viễn 1 khách sỉ khỏi DataKhachSi
function deleteCustomerRecord(sheetRow) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _dataKhachSiSheet();
    if (!sh) return { success: false, error: 'Không tìm thấy sheet DataKhachSi.' };
    const row = parseInt(sheetRow);
    if (!row || row < 2 || row > sh.getLastRow()) return { success: false, error: 'Dòng không hợp lệ.' };
    sh.deleteRow(row);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}
/** ============================================================
 *  9 SẠCH - XUẤT TEM DẠNG EXCEL THẬT (không qua PDF, không mất chữ)
 *  Tem Cuốn Chiếu: theo mẫu Tem_Dan_Thung_Lotte_Mart_Hang_Doc.xlsx
 *  Tem X2: theo mẫu Tem_niêm_phong_x2_CHUẨN.xlsx
 * ============================================================ */

function _exportSSAsBase64Xlsx(tempSS) {
  SpreadsheetApp.flush();
  const url = 'https://docs.google.com/spreadsheets/d/' + tempSS.getId() + '/export?format=xlsx';
  const resp = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
  if (resp.getResponseCode() !== 200) throw new Error('Google trả về HTTP ' + resp.getResponseCode() + ' khi xuất file.');
  const base64 = Utilities.base64Encode(resp.getBlob().getBytes());
  DriveApp.getFileById(tempSS.getId()).setTrashed(true);
  return base64;
}
// Logo LOTTE Mart (PNG nền trắng, nhúng base64 để không phụ thuộc link ngoài)
const MT_LOTTE_LOGO_BASE64 = 'iVBORw0KGgoAAAANSUhEUgAAAGMAAAAhCAIAAABCyYKlAAAQAElEQVR4AdRZC5hUxZU+p+693bcf0zAzPQPzAIK8NG7U8PmIUWNiskZNjHHdNRv1I5/xia8kut+KCRAVMaIoBrPGqKxiMDFustkkriIi4gNRUb+oSEBXZhhmcGZggJnp7tt9H1X71710zwzMiFGS7/N+59atOnXOqapTp06dqivUJ+oJurp2HnfSjkmH9kw4uPfs85SUle57617tmXqYhubJudk3VPAfLZO7ds6O5sk9EDVrTiRB0CfqUQVH7ugxPc9SMmhpVfl8pftBa1uqVKJisUoI2b29gv9oGZnPQQ5AFYuRhE+YpsjzoAuWipSSO3ep7TuiYSCV7R1xRSQlozBIgyh9FGA2iABoKGL/hGlKOY4JHZEKlDJdV3Z1R8NAKju2yXBYUKMsGwLwHxGEgNoBxBxJ+KRpqj9nKIUBSKIkc7Dt/WgYSIO2dh8VRDpxSwSFAXvg4MNpqlhyn1/jPvaEt+ZF5boHrvW/WpLK5aMeQx0msSxrSnme7Oz0Q3lQIjnFffupdu+W/f0hyf4TjsdhSwyLSiQiauE+82xpxdPe6ufIcSLUXmnQsS2/cFHxplvyN8wv3rTAuWNxxebV7t7ikyvdlc+4T6/eF4qPPxlsbsFUFx9fsW+txqx8prT8KbVD+xp3zVr3qac1siJq5TPFJ1bIzq4h/XEcQQw1ARmQkh0dyABUT0/Q04PVp/OkFDTlDcyo99b64r1LnFsXlRbeWfrt/xAcP+hgfZ7nv7LOgxE8+7zauQs47403vede8Na+jDnwiHxSyPhrX/ZffkXkf/hj57o5+bnz5CDvCJ4IZC5fWHSXde8DyY3vjO7ekdiwyfj5vYXFd6MrIAjeede7bm4e7MOBe+3s0pMrvdXPIjMSTWnWHH/9Bmxb3tx5+WvngCw3a04E+evmBtfORi/RUAVkviDKBegr2LpHU1CoyOWDsAo2pTesICz5gfvcGvemBcFNC6xlj1gPPlz84dzCskdIr2BSfX35G3/izL6+9KMfB21b/ZfXefMW5H50fX7ujf7rfy4qVVDKW/caivm58wS1d8S274DhKBdKpL0e94//Kx79Hdrsy2T6j5rel05JTOlDv3IfXw5K2ddXtWvXqO7tma7uRGc3v99J73danV0oVnV1Z3IFtX07NvVMrl8Xu7pjMJCQxg5pNOPuXiwob+Wq1Hubaft2EKS7u1MV6M8FO3rQUAVAXPawFGADRDQQSNQGXd1Jqd088ihrTYXDkdu352fNtta+UlKqX8k+GVjFYnD7T/231oOSXM//yyarpY3b2uXmzfkbb4698qpobeON71JfX6C0QO7ro43vBhs2CmVZmBy2TDL1nqj5K28+X7r/gRgxGUbi4u9mlv2n/d3vKGKb2fnFEnJdMaY+39TY39zUP2G8UzNaEUjJTSRQzI1rls2NoqFBNDV5zU0oAllKJjikcaD3CePB6ICmPhts3CSVQlXJtp1PHwwoHjLNOXhq//gm41PjafDjFEAWIbA0sOLU7t0oqm3vG0zogM7jLZbgqvBV/f1YobAO5MEIAkepdL5QfPhRYMiyRCoJhZeEKC77jf/mW9BmgI01MjlNQVrvEJypEsQMfqQhfkjiPvOc9X/vAeUddmjiovPJtqEvb9pkYIyNm7wXXzIP/XRi6X1Vv1wy6r8eti8832aREsI8cnrmkaWZXy6hB+6xzzojdspXjAd+gWLVbx6KnXhCWmga++x/yjy6DIzxh+43p39WahdDCSGsL38x86ulo5ben3nwvszS+1O/Xmod/3k0VwGVh0cPO0zapmjXbigLtUHLFqQRKIzH81RBB6Vcl+Xq6hizQYwxm6FBlpT0XlhDQcCWRazxJKX/2utMWrIgEsBGsoiYdFF5vqCRH2/lKpgPhMdO/xrUBEKuSsdOP00wp5jd5U+REGLSQeKgiTymXjQ1MkEoiVEZ0dgoJn5KTJ7ENTVi1ChkUDQaGlBEj9Ekjx0jAAdNBC+ZJgU6XGQi65ijuXo019eBAAA5XN560DpA5fT4kQFg8uO+r3p2Ii/b25FCAlJ4aowc0TzyoqrKqK8XhpDjm63PHR0kbIMIJqa2tsuWVo5ZoIFiYUMs9/RBChEIrTJUAVDrCya3JFAYFhDjea++Dg+VtyzzhIGJtb5wfE4w8O7al1WpNMCLKQoLSmLywtw+ifI9NKzRoRPRmfBV4RBhCzx6VIgYMVH9uUhCyEEIFBR8H+yrsxNuK2IDgQHrcMJTiGmKumzwtVMzS+9L3Xlb8t+vYdasmGl/yxY9SREP6VUGLp48KXbG6bEzz2BolhnGKMaPi33zG/FvfmNETWGDV+0daFWOHWNMGHAWsIKgLouwTrZtDba0lRtCU2UFYcQD2KG5ihIrmaH1JDEFe6GGFFXop7Sh2TZGDN+k9yLfl53dJaVg2hQqAnhQEmle+5ILYtdebUyeZDQ12ueczVMn2ywMKDfcNzFATUSUEoKmH15190+Ts65JzbrGOvxwmznBwjpyOjDJWf82sqZaWlNKGcQmFpFtR+KQinTaPGgiupKWUg7yDqg6ABCO84PkOA4UpFduc6PFLIiDzi65a5fYtduPx8yjpiulx45uU6EQybFOOM4Y1xzlKZHgcc0WRKDc06NJkSEymF0h4pddbBwyTTQ2aPnplEEkSGFWRMNYjQkph0nk1vaQlIzmpiHV6F9zkwENwoy2au8wpPZjFJiIDZM+4IEanCIzcbbWPHiaxYwVpwOR91ri8HSjMsYRRxghu8EURXy6BAYif9O7xfsfLMy7BRlsf4zOD3J5NrOcOiV+0pc0ffhK14UeNZSPkCLED5Oo97tAp1dUNrtXtairQxUg6Ozcq+rjFF1SODAh/kCsq+GOxfkFd8AJVGQqrLLQUjhuiwnjMVqfpOrZFWx8xyLmZBK2Y7B2xtCXDCkj3tKq1f78Bc7CReK+B0R7Bzy6xnvR4UdnLcJmchRZw81TqGgQCbzDgurtRVewv+zrZcWojMYTgWZY3o+AhN4xALV8Bc+/VSz6GcC88z9Sd98bvL1hQJrv6x0NpHaMGxqwzuDVZE9PsOkdk4kzGSNTFRELYkRSUR4HiWDeLfFnnzfyTkFJX0X7R1SpUyaCHHPaFF0Y+RUjVUm9r7FShNhsbxodrWmcQoCnvwfmRY9d5rzBeSZADqmSDEdbEQ8rcPThVKRSMB9JOJcRonAcOKA9hMGUTmPMkKM5+sN4Qsr8XfckW1p3SmwiKgEPHRqdJigbC/IYJiIYZD4ARtSUDjFgNWBFvIN0MJgmRBMMng7ko5fAccfaM86Nn/ftCOS3/llMmlRpQ0JNTrj3JxJGY0NJMDqpevtgU4izRXOTqKmWBrB6ASoQEwW4F12xsk9Kg3SEWWpu8NNpoyKxnIGi1SDFldFDviNrqkIWYJ4qhTADzJ6JC4sHIoG8OIv42WelbpiTnn89IDX/+qrbbjYOnloRz8U9dykcj3F9VmLM4fDAy8SicSxsiq0YVAXFqdBP4WKgCgc9pYRg88QTErOvMz93dJKHGbVePpWWhssMwxORoUm0h+qBTSSqgKE5ReDxJRN2UMYeiC9/oBCYifJ9AlEsJmpqGJtdmd5VCuESYm6OxVCvbSS0Pv/Pb2KRxpnlhPFVC38SP/VkbPnYNMt8H+LLkKfJwiHrzN4vZ9JA6fnZ9/arvz9ii2hAdqBA+cPcZ1SEq4JD0BQRh/GdyGYNrTb9IuwUTU0ERxGPo2/QDhW1Rws2tyKSiLOwTvsqjkfEPMTx0YjPIBPbn6aiUABdkT36pm2wSNnTI0j7Au1EB1f8jfOy4KA/BINJp9CUaGwwwlEIZt8yxdixhHDMMoGDG9W7Dc7Jvb0g95Qyy6tYWyWY9wuGAAl4o7lBXpfx2Re4SZ94cYsotw29dYSb3NaJKAEsBqYRn78bOAWLcUBTnArtvblRK45w+iPO1lKmik1DuzDSs4gzKfyGcl0MQQ+47ChUdzcw++0yh/RS6b01IhbRhwh2icmgymNMmJBTCs5cbm4hH989NbrtlpZAUUEIhH97sAfsM6QPe0vFjxlmXyFw0TZlNDVizGCwmPVpI5kgDALnFe1B0b8CAh3UQk0x+Klt2yAN14peeJmJ/H7AtMAL9+dv+EvQpo+3ZU3hp41hDGY2p072w5O939oa4KKyXIdTjr6TZfJra43JB5XRB+hrDhcll2XLfMEiXGMohlKI4JvhnpgI/Rb19STCsSRTQtsdqXxeMJP+ccAeov/Hlwfr3y4uWWr37MT4yyJH/MIFMzGODbxzV37OvMJti3AGxKIm2OogH6b5uXp07DOHGsQpp+S99rpGha+/7rW056PH1mH/wGm9CkL0x0sw70SCiYpFGlmS6tM7iU+0R1ONDUVmQfoRzY36Q8RpbW5EpJwSGYbABRmRI6X/+huF+bcWl/0aqyNsDSQfBCJbi+5IyCGyVz/nLL5bUBDAni3XdVc9K1u3yPc2A/xN76DT1ikng9rEOfsPf6pILf3xMYG5Ioqd/OUK8uNm9GRpT+2tfSVo7wg6OoL2doC/pU2FYVEkX+VyyKC3nEoiAztSySQ6g5FX/ACUiD4Do9ySEiymTIoxzJBgB9aal8zeXnh38O4XsJPCoDANEJVHeB+PCYWAmxSkO0seLCxclL/ldoB/y0J//dvWV07anUkrUvKFF92nVqm+vtLjTwQvrYOid9dU40pvSHuh+jSmktGFD/Vy3EIHikq5q1Y7d9yl4fbFzu2Lg4V3+m+8NSAiDJH01WQy1NSojFGXNUmf2nC4icigRIiCLeC/PAfSOuYoFAF6wAoOmpABaOKwn8yo1KW9XkS8/YaBpRPhEZcIY8rk0cKA8pKtbfE/PWGvWKlh9fP++g1Gw9jEjHNBmih5BZzFf36fc/PCVABvTonzZ2CTRtUAuC4CPAMND7KCgdoo53kwAdAoz4sQUSomTtR4okRvn/2739u//b39338AxB9bPviErHb0ELNFhDsjwmPb2PISwnClEvV1QAAQeZos0BOr4OBIaB57zM5kIsUC+rCZA9hgU0OVEAYLxLEkpcoXgAdQGKlBQgTGxAnWkdOrBEMz4CXXE/a3zgrG1Ll12Xy2Nle7B7yaaq7S53L7/BmF6Ud4MQtL0vnZPXJLmxeLFY85yp5xTiRxII3HSnW1HpZ3JjOAHJrj0dVBttYHTdmbRPWxk76YGzvGy2aLdbV9NTUVkDXVuLeIaJAqy5TZWtncBMNBEWAeMk1ma4Ipk7ASUQSIsQ2Q76CJ+jpcJeN4aJ/3r5ypwnHGSKXiZ54eO/Wr+A2BbohUmqHiMfXFumwJ9IkE2AcB2zPOLdXUkmUG4T4j4t8+O/jBlfZVlyV+cIVdhuDyS8zDPwM2TBqOYP6EcSoW0z8dYjF/0sTUzTfsexVjHnG4uvwSf+ZF8X85C4zDQuyUf/RmXujNvCj2+WMHE1jHHhOfNzd+5aX2969IXH1lBUqXX2xM/2yFEnG2e+kF9tVXierqe5tdRgAAAGNJREFUCBk/8wz34gsSV10m6rIRxvrSF/yZF8a/d7l55UzR3ARk8vtXeicez6mUd/SRiau/Fz/j68GlF7ozL7ROO5niMfAaV1yqrrhETNH/nEBfgfjXT5XfOYeyWa6tFeOa/h8AAP//giZ4hQAAAAZJREFUAwAiTLtJzej2OAAAAABJRU5ErkJggg==';

// ─── TEM CUỐN CHIẾU (1 cột dọc, cách nhau 10 dòng/tem - đúng mẫu) ──
// labelsArr: [{ channelLabel, storeName, vendorCode, ncc, nganhHang, nhietDo, boxCount }]
// ════════════════════════════════════════════════════════════
// BOOKING KONOIKE - XUẤT FILE EXCEL THẬT (không qua PDF), khớp đúng
// cấu trúc file mẫu BOOKING_KONOIKE (tiêu đề, bảng, ghi chú, chữ ký).
// rows: [{ deliveryDate, storeName, poNo, boxes, kg }]
// ════════════════════════════════════════════════════════════
function exportBookingKonoikeExcel(rows, meta) {
  let tempSS = null;
  try {
    tempSS = SpreadsheetApp.create('TEMP_BOOKING_' + new Date().getTime());
    const sh = tempSS.getSheets()[0];
    sh.setName('TBGH');
    sh.setHiddenGridlines(true);

    const COLW = [75, 190, 75, 65, 150, 85, 90, 75, 65, 55, 60, 110]; // A..L
    for (let i = 0; i < COLW.length; i++) sh.setColumnWidth(i + 1, COLW[i]);

    // Dòng 1: hướng dẫn (chữ đỏ)
    sh.getRange(1, 1, 1, 12).merge().setValue(
      'NCC điền thông tin đầy đủ theo form, gửi booking qua email nhận booking bên dưới và IN RA 2 BẢN ĐỂ TÀI XẾ MANG ĐI KHI GIAO HÀNG QUA KHO TRUNG TÂM.'
    ).setFontColor('#FF0000').setFontSize(11).setWrap(true).setVerticalAlignment('top');
    sh.setRowHeight(1, 40);

    // Dòng 2: liên hệ Kho Trung Tâm (trái) / thông tin NCC (phải)
    sh.getRange(2, 2, 1, 4).merge().setValue(
      'Contact Kho Trung tâm:\n- Kho HCM:\nEmail booking HCM: transport01@kvi.konoike.net; transport15@kvi.konoike.net\n- Kho HN: ……………………\nEmail booking HN: ……………………'
    ).setFontWeight('bold').setFontSize(9).setWrap(true).setVerticalAlignment('top');
    sh.getRange(2, 6, 1, 7).merge().setValue(
      'Tên NCC: CÔNG TY TNHH MTV 9 SẠCH\nTel: 0962221759\nFax: ………………………………………\nNgười liên hệ: TÔ THỊ MY'
    ).setFontWeight('bold').setFontSize(9).setWrap(true).setVerticalAlignment('top');
    sh.setRowHeight(2, 75);

    // Dòng 3-4: tiêu đề
    sh.getRange(3, 1, 1, 12).merge().setValue('THÔNG BÁO GIAO HÀNG').setFontWeight('bold').setFontSize(14).setHorizontalAlignment('center');
    sh.getRange(4, 1, 1, 12).merge().setValue('(BOOKING NOTICE)').setFontWeight('bold').setFontSize(10).setHorizontalAlignment('center');

    // Dòng 5: tiêu đề bảng
    const headers = [
      'Ngày giao\n(Date)', 'Giao đến\n(Destination)', 'Mã NCC\n(Vendor code)', 'Hóa đơn\n(Invoice)',
      'Đơn hàng số\n(PO No.)', 'Tên sản phẩm\n(Commodity)', 'Nhiệt độ\nbảo quản\n(temperature)', 'Ngành hàng\n(CAT)',
      'Số kiện/thùng\n(Qty.)', 'Khối lượng\n(KGS)', 'Số khối\n(M3)', 'Hàng kiểm dịch'
    ];
    sh.getRange(5, 1, 1, 12).setValues([headers]).setFontWeight('bold').setFontSize(8).setWrap(true)
      .setHorizontalAlignment('center').setVerticalAlignment('middle').setBackground('#f2f2f2');
    sh.setRowHeight(5, 46);

    // Các dòng dữ liệu - "Số khối (M3)" luôn là chữ "0.3m3" cố định, không
    // tính theo số thùng hay khối lượng, đúng như file mẫu thực tế.
    let r = 6;
    let totalBoxes = 0, totalKg = 0;
    (rows || []).forEach(function (o) {
      const dataRow = [
        o.deliveryDate || '', o.storeName || '', '010483', '',
        o.poNo || '', 'Bánh sầu riêng', '-18', '46',
        o.boxes || 0, Math.round((o.kg || 0) * 10) / 10, '0.3m3', 'No'
      ];
      sh.getRange(r, 3).setNumberFormat('@'); // giữ số 0 đầu của Mã NCC
      sh.getRange(r, 1, 1, 12).setValues([dataRow]);
      totalBoxes += (o.boxes || 0); totalKg += (o.kg || 0);
      r++;
    });
    const dataEndRow = r - 1;
    sh.getRange(6, 1, dataEndRow - 5, 12).setHorizontalAlignment('center').setVerticalAlignment('middle').setFontSize(9);

    // Dòng Tổng - chỉ cộng Số thùng + Khối lượng, KHÔNG cộng Số khối (đúng mẫu)
    sh.getRange(r, 1, 1, 6).merge().setValue('Tổng').setFontWeight('bold').setHorizontalAlignment('center');
    sh.getRange(r, 9).setValue(totalBoxes).setFontWeight('bold').setHorizontalAlignment('center');
    sh.getRange(r, 10).setValue(Math.round(totalKg * 10) / 10).setFontWeight('bold').setHorizontalAlignment('center');
    const totalRow = r;
    r++;

    sh.getRange(5, 1, totalRow - 5 + 1, 12).setBorder(true, true, true, true, true, true);

    // Ghi chú
    r = totalRow + 2;
    sh.getRange(r, 1).setValue('GHI CHÚ:').setFontWeight('bold').setFontLine('underline'); r++;
    const notes = [
      '* TBGH phải điền đầy đủ thông tin theo bảng trên.',
      '* Tất cả Thông báo giao hàng phải được gởi email đến Nhà vận chuyển (NVC) trước 15h30 từ Thứ Hai đến Thứ Sáu.',
      '* Trong vòng 60 phút sau khi nhận được thông báo này, NVC sẽ gởi lại xác nhận thông tin hàng hóa.',
      '* Nếu không nhận được phản hồi của NVC, Nhà cung cấp vui lòng liên hệ theo thông tin Kho trung tâm phía trên để yêu cầu xác nhận.',
      '* Hàng hóa phải được giao đến kho NVC trước 16h theo Lịch giao nhận hàng tại kho TT.',
      '* TBGH không nhận được xác nhận của NVC thì NVC sẽ không nhận hàng và trả hàng về.',
      '* Khối lượng thông báo = Khối lượng hàng hóa + Bao bì đóng gói.',
      '* Số khối = dài x rộng x cao.'
    ];
    notes.forEach(function (txt) {
      sh.getRange(r, 2, 1, 10).merge().setValue(txt).setFontSize(9).setWrap(true);
      r++;
    });

    // Chữ ký
    r += 1;
    sh.getRange(r, 2).setValue('Nhà Cung Cấp').setFontWeight('bold').setFontLine('underline').setHorizontalAlignment('center');
    sh.getRange(r, 4, 1, 2).merge().setValue('Tài xế giao hàng').setFontWeight('bold').setFontLine('underline').setHorizontalAlignment('center');
    sh.getRange(r, 7, 1, 2).merge().setValue('Xác nhận Kho Trung tâm').setFontWeight('bold').setFontLine('underline').setHorizontalAlignment('center');
    r++;
    sh.getRange(r, 2).setValue('(Ký tên & xác nhận)').setFontSize(9).setHorizontalAlignment('center');
    sh.getRange(r, 4, 1, 2).merge().setValue('(Ký tên & xác nhận)').setFontSize(9).setHorizontalAlignment('center');
    sh.getRange(r, 7, 1, 2).merge().setValue('(Ký tên & xác nhận)').setFontSize(9).setHorizontalAlignment('center');
    r += 4;
    sh.getRange(r, 2).setValue((meta && meta.signerName) || 'CAO THANH TÂN').setFontWeight('bold').setHorizontalAlignment('center');

    return _exportSSAsBase64Xlsx(tempSS);
  } catch (e) {
    if (tempSS) { try { DriveApp.getFileById(tempSS.getId()).setTrashed(true); } catch (ex) {} }
    throw new Error('Lỗi xuất Excel Booking: ' + e.toString());
  }
}
function exportTemCuonChieuExcel(labelsArr) {
  let tempSS = null;
  try {
    tempSS = SpreadsheetApp.create('TEMP_TEM_CUONCHIEU_' + new Date().getTime());
    const sh = tempSS.getSheets()[0];
    sh.setName('Tem Dán Thùng Dọc');
    sh.setHiddenGridlines(true); // ẩn lưới ô ly - nhìn như bản in thật, không cần chỉnh gì thêm
    sh.setColumnWidth(1, 175); // đủ rộng cho nhãn dài nhất "Nhiệt độ bảo quản"
    sh.setColumnWidth(2, 16);
    sh.setColumnWidth(3, 260); // thu hẹp lại - khung ôm sát chữ, không dư khoảng trắng
    sh.setColumnWidth(4, 30);
    const logoBlob = Utilities.newBlob(Utilities.base64Decode(MT_LOTTE_LOGO_BASE64), 'image/png', 'lotte_mart_logo.png');

    let row = 2;
    (labelsArr || []).forEach(function (item) {
      const n = Math.max(1, parseInt(item.boxCount) || 1);
      for (let i = 1; i <= n; i++) {
        _writeTemCuonChieuBlock(sh, row, item, i, n, logoBlob);
        row += 10; // đúng khoảng cách trong file mẫu (row 2,12,22,32...)
      }
    });
    return _exportSSAsBase64Xlsx(tempSS);
  } catch (e) {
    if (tempSS) { try { DriveApp.getFileById(tempSS.getId()).setTrashed(true); } catch (ex) {} }
    throw new Error('Lỗi xuất Excel tem cuốn chiếu: ' + e.toString());
  }
}
function _writeTemCuonChieuBlock(sh, startRow, item, boxIdx, boxTotal, logoBlob) {
  const rows = [
    ['Thùng số: ' + boxIdx + '/' + boxTotal, '', ''],
    ['Nơi Giao Hàng', ':', item.storeName || ''],
    ['Mã NCC', ':', item.vendorCode || '010483'],
    ['Tên NCC', ':', item.ncc || 'CÔNG TY TNHH MỘT THÀNH VIÊN 9 SẠCH'],
    ['Ngành hàng', ':', item.nganhHang || 'DELICA'],
    ['Nhiệt độ bảo quản', ':', item.nhietDo || '-18 độ C'],
    ['Tổng số thùng', ':', String(boxTotal)]
  ];
  const nRows = rows.length;
  const nccRow = startRow + 3; // dòng "Tên NCC" - dòng thứ 4 trong khối (0-based index 3)

  sh.getRange(startRow + 1, 3, nRows - 1, 1).setNumberFormat('@');
  sh.getRange(startRow, 1, nRows, 3).setValues(rows);
  sh.getRange(startRow + 1, 3, nRows - 1, 1).setHorizontalAlignment('left');

  // Khung ôm sát nội dung: viền ngoài toàn khối + kẻ ngang dưới "Thùng số"
  // + kẻ dọc giữa cột nhãn và cột giá trị
  sh.getRange(startRow, 1, nRows, 3).setBorder(true, true, true, true, false, false);
  sh.getRange(startRow, 1, 1, 3).setBorder(null, null, true, null, null, null);
  sh.getRange(startRow + 1, 1, nRows - 1, 1).setBorder(null, null, null, true, null, null);

  // [FIX] Canh giữa theo chiều dọc cho TOÀN BỘ khối - chữ không còn lệch
  // trên/dưới trong ô, và tắt wrap mặc định để khung ôm sát chữ hơn.
  sh.getRange(startRow, 1, nRows, 3).setVerticalAlignment('middle').setWrap(false);

  sh.setRowHeight(startRow, 36);
  sh.getRange(startRow, 1).setFontWeight('bold').setFontSize(13).setFontColor('#000000');

  if (logoBlob) {
    try {
      const img = sh.insertImage(logoBlob, 3, startRow, 30, 3);
      img.setWidth(96).setHeight(32);
    } catch (e) {}
  }

  sh.getRange(startRow + 1, 1, nRows - 1, 1).setFontColor('#000000').setFontWeight('bold').setFontSize(12);
  sh.getRange(startRow + 1, 3, nRows - 1, 1).setFontColor('#000000').setFontWeight('bold').setFontSize(12);

  // [MỚI] Riêng dòng "Tên NCC" (tên công ty dài) cho phép xuống dòng và
  // tăng chiều cao - nhờ đó cột C có thể thu hẹp lại (khung ôm sát chữ)
  // thay vì phải kéo giãn rất rộng chỉ để vừa 1 dòng tên công ty.
  sh.getRange(nccRow, 3).setWrap(true);
  sh.setRowHeight(nccRow, 34);
  for (let i = 1; i < nRows; i++) {
    if (startRow + i !== nccRow) sh.setRowHeight(startRow + i, 24);
  }
}

// ─── TEM X2 (2 cột giống hệt nhau, 3 dòng/tem, đúng mẫu) ──
function exportTemX2Excel(labelsArr) {
  let tempSS = null;
  try {
    tempSS = SpreadsheetApp.create('TEMP_TEM_X2_' + new Date().getTime());
    const sh = tempSS.getSheets()[0];
    sh.setName('Sheet1');
    sh.setColumnWidth(1, 72); sh.setColumnWidth(2, 290);
    sh.setColumnWidth(3, 65); sh.setColumnWidth(4, 290);

    let row = 1;
    (labelsArr || []).forEach(function (item) {
      const n = Math.max(1, parseInt(item.boxCount) || 1);
      for (let i = 1; i <= n; i++) {
        _writeTemX2Block(sh, row, item, i, n);
        row += 3; // đúng khoảng cách trong file mẫu (row 1,4,7,10...)
      }
    });
    return _exportSSAsBase64Xlsx(tempSS);
  } catch (e) {
    if (tempSS) { try { DriveApp.getFileById(tempSS.getId()).setTrashed(true); } catch (ex) {} }
    throw new Error('Lỗi xuất Excel tem x2: ' + e.toString());
  }
}
function _writeTemX2Block(sh, startRow, item, boxIdx, boxTotal) {
  sh.setColumnWidth(2, 300); sh.setColumnWidth(4, 300); // đúng ~41.18 đơn vị cột trong file mẫu
  const to = 'TO: ' + (item.storeName || '').toUpperCase();
  const ncc = item.ncc || 'CÔNG TY TNHH MỘT THÀNH VIÊN 9 SẠCH';
  const sk = boxIdx + '/' + boxTotal;
  const r1 = startRow, r2 = startRow + 1, r3 = startRow + 2;

  sh.getRange(r1, 1, 1, 2).merge().setValue(to);
  sh.getRange(r1, 3, 1, 2).merge().setValue(to);
  sh.getRange(r2, 1).setValue('TÊN NCC'); sh.getRange(r2, 2).setValue(ncc);
  sh.getRange(r2, 3).setValue('TÊN NCC'); sh.getRange(r2, 4).setValue(ncc);
  // [FIX] Ép định dạng văn bản TRƯỚC khi ghi "1/2" - nếu không Sheets tự
  // nhận diện chuỗi "số/số" là NGÀY THÁNG và hiển thị sai thành "1-2"
  sh.getRange(r3, 2).setNumberFormat('@');
  sh.getRange(r3, 4).setNumberFormat('@');
  sh.getRange(r3, 1).setValue('SỐ KIỆN'); sh.getRange(r3, 2).setValue(sk);
  sh.getRange(r3, 3).setValue('SỐ KIỆN'); sh.getRange(r3, 4).setValue(sk);

  const block = sh.getRange(r1, 1, 3, 4);
  block.setBorder(true, true, true, true, true, true);
  // [FIX] Tắt wrap - đây chính là nguyên nhân chữ "SẠCH" bị rớt xuống dòng
  // dưới. File mẫu KHÔNG bật wrap, cột đã đủ rộng để chứa trọn 1 dòng chữ.
  block.setFontFamily('Calibri').setHorizontalAlignment('center').setVerticalAlignment('middle').setWrap(false);
  sh.getRange(r1, 1, 1, 4).setFontWeight('bold').setFontSize(12);
  sh.getRange(r2, 1, 1, 4).setFontWeight('bold').setFontSize(12);
  sh.getRange(r3, 1).setFontWeight('bold').setFontSize(12);
  sh.getRange(r3, 3).setFontWeight('bold').setFontSize(12);
  sh.getRange(r3, 2).setFontWeight('bold').setFontSize(18);
  sh.getRange(r3, 4).setFontWeight('bold').setFontSize(18);
  sh.setRowHeight(r1, 44); sh.setRowHeight(r2, 46); sh.setRowHeight(r3, 43);
}
// [TIỆN ÍCH] Liệt kê các đơn hàng CHƯA HỦY nhưng đang thiếu tên nhân viên
function timDonThieuNhanVien() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!sh || sh.getLastRow() < 2) { Logger.log('DonHang trống.'); return; }
  const data = sh.getRange(2, 1, sh.getLastRow() - 1, 22).getValues();
  let count = 0;
  data.forEach((r, idx) => {
    const sheetRow = idx + 2;
    if (r[0] && r[0] !== '') {
      const emp = (r[18] || '').toString().trim();
      const status = (r[20] || '').toString();
      if (status !== 'Huy' && !emp) {
        count++;
        Logger.log('Dòng ' + sheetRow + ' | Ngày: ' + r[0] + ' | Khách: ' + r[1] + ' | Giá trị: ' + r[6]);
      }
    }
  });
  Logger.log('==> Tổng cộng ' + count + ' đơn đang THIẾU tên nhân viên.');
}

// [TIỆN ÍCH] Gán tên nhân viên cho TẤT CẢ đơn đang thiếu (chỉ đơn chưa hủy)
// ĐỔI "TEN_NHAN_VIEN" thành đúng Tên Hiển Thị của nhân viên bạn muốn gán
// trước khi chạy.
function ganNhanVienChoDonThieu() {
  const TEN_NHAN_VIEN = 'TEN_NHAN_VIEN'; // <-- ĐỔI TÊN NÀY TRƯỚC
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('DonHang');
  if (!sh || sh.getLastRow() < 2) { Logger.log('DonHang trống.'); return; }
  const data = sh.getRange(2, 1, sh.getLastRow() - 1, 22).getValues();
  let fixed = 0;
  data.forEach((r, idx) => {
    const sheetRow = idx + 2;
    if (r[0] && r[0] !== '') {
      const emp = (r[18] || '').toString().trim();
      const status = (r[20] || '').toString();
      if (status !== 'Huy' && !emp) {
        sh.getRange(sheetRow, 19).setValue(TEN_NHAN_VIEN);
        fixed++;
      }
    }
  });
  Logger.log('Đã gán "' + TEN_NHAN_VIEN + '" cho ' + fixed + ' đơn hàng.');
}
// ════════════════════════════════════════════════════════════
// TRA CỨU MÃ SỐ THUẾ (masothue.com) - dùng cho trang Data Khách Sỉ
// ════════════════════════════════════════════════════════════
function lookupTaxCode(taxCode) {
  try {
    var mst = (taxCode || '').toString().trim().replace(/[^0-9\-]/g, '');
    if (!mst) return { success: false, error: 'Vui lòng nhập mã số thuế.' };

    var searchUrl = 'https://masothue.com/Search/?q=' + encodeURIComponent(mst) + '&type=auto&force-search=1';
    var opts = {
      muteHttpExceptions: true,
      followRedirects: true,
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36' }
    };
    var resp = UrlFetchApp.fetch(searchUrl, opts);
    var html = resp.getContentText();

    // Nếu là trang danh sách kết quả (nhiều công ty trùng) -> lấy link đầu tiên rồi fetch trang chi tiết
    if (html.indexOf('itemprop="name"') === -1) {
      var linkMatch = html.match(/<h3[^>]*>\s*<a[^>]+href="(https:\/\/masothue\.com\/[^"]+)"/)
        || html.match(/<a[^>]+href="(https:\/\/masothue\.com\/[0-9][^"]*)"[^>]*>/);
      if (linkMatch) {
        var detailResp = UrlFetchApp.fetch(linkMatch[1], opts);
        html = detailResp.getContentText();
        searchUrl = linkMatch[1];
      }
    }

    function grab(re) {
      var m = html.match(re);
      return m ? m[1].replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim() : '';
    }

    var name = grab(/<h1[^>]*itemprop="name"[^>]*>([\s\S]*?)<\/h1>/i) || grab(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    var address = grab(/<[^>]+itemprop="address"[^>]*>([\s\S]*?)<\/(span|td|p)>/i)
      || grab(/Địa chỉ:?<\/(td|span|strong)>\s*<(td|span)[^>]*>([\s\S]*?)<\/\2>/i);
    var rep = grab(/Người đại diện:?<\/(td|span|strong)>\s*<(td|span)[^>]*>([\s\S]*?)<\/\2>/i);
    var status = grab(/Trạng thái:?<\/(td|span|strong)>\s*<(td|span)[^>]*>([\s\S]*?)<\/\2>/i);

    if (!name) {
      return { success: false, error: 'Không tìm thấy thông tin cho MST "' + mst + '" trên masothue.com. Vui lòng kiểm tra lại hoặc nhập tay.', link: searchUrl };
    }
    return { success: true, name: name, address: address, representative: rep, status: status, link: searchUrl };
  } catch (e) {
    return { success: false, error: 'Lỗi tra cứu: ' + e.toString(), link: 'https://masothue.com/' };
  }
}


/** ============================================================
 *  MÃ KHÁCH HÀNG - theo "Quy định mã khách hàng" 9 SẠCH (T10/2026)
 *  Cấu trúc: [Xưởng][Nhóm][Mã tỉnh]-[STT 4 số]   (MN, CH)
 *            [Xưởng][HCTM|HCGC]-[STT 4 số]        (Hội chợ)
 *  Xưởng: CT = Cần Thơ, ĐN = Đà Nẵng - suy ra từ TỈNH/THÀNH của khách.
 * ============================================================ */
const CUST_CODE_GROUPS = ['MN', 'CH', 'HCTM', 'HCGC'];   // nhóm tự sinh STT

// Mã tỉnh theo 34 tỉnh/thành sau sáp nhập (khóa: tên không dấu, chữ thường, bỏ "tỉnh/thành phố")
const PROV_CODE_BY_NAME = {
  'an giang':'AG','bac ninh':'BN','ca mau':'CM','cao bang':'CB','dak lak':'ĐL','dien bien':'ĐB',
  'dong nai':'ĐO','dong thap':'ĐT','gia lai':'GL','ha tinh':'HT','hung yen':'HY','khanh hoa':'KH',
  'lai chau':'LA','lang son':'LS','lao cai':'LC','lam dong':'LĐ','ninh binh':'NB','nghe an':'NA',
  'phu tho':'PT','quang ninh':'QI','quang ngai':'QN','quang tri':'QT','son la':'SL','tay ninh':'TN',
  'tuyen quang':'TQ','thai nguyen':'TA','thanh hoa':'TH','can tho':'CT','da nang':'ĐN','ha noi':'HN',
  'hai phong':'HP','ho chi minh':'SG','hue':'HU','vinh long':'VL'
};
// Tên tỉnh CŨ (trước sáp nhập) + cách viết tắt hay gặp -> mã tỉnh mới (theo bảng sáp nhập trong quy định)
const PROV_ALIASES = {
  'kien giang':'AG','bac lieu':'CM','soc trang':'CT','hau giang':'CT','ben tre':'VL','tra vinh':'VL',
  'tien giang':'ĐT','long an':'TN','binh duong':'SG','ba ria':'SG','vung tau':'SG','tphcm':'SG','tp hcm':'SG',
  'hcm':'SG','sai gon':'SG','binh phuoc':'ĐO','dak nong':'LĐ','binh thuan':'LĐ','phu yen':'ĐL',
  'ninh thuan':'KH','binh dinh':'GL','kon tum':'QN','quang binh':'QT','quang nam':'ĐN','thai binh':'HY',
  'hai duong':'HP','ha nam':'NB','nam dinh':'NB','yen bai':'LC','ha giang':'TQ','bac kan':'TA',
  'bac giang':'BN','hoa binh':'PT','vinh phuc':'PT','thua thien hue':'HU'
};
// Xưởng theo tỉnh. Nhóm CT = miền Nam; còn lại ĐN. (ĐB, LA, LS, NB chưa có trong data mẫu -> suy theo địa lý = ĐN)
const FACTORY_CT_PROVS = ['SG','AG','CT','ĐT','TN','CM','KH','LĐ','ĐO','VL','ĐL'];

function _nfc_(v) { return (v == null ? '' : v).toString().normalize('NFC'); }
function _normCode_(v) { return _nfc_(v).trim().toUpperCase(); }

function _provKeyList_() {
  const out = [];
  Object.keys(PROV_CODE_BY_NAME).forEach(k => out.push({ key: k, code: PROV_CODE_BY_NAME[k] }));
  Object.keys(PROV_ALIASES).forEach(k => out.push({ key: k, code: PROV_ALIASES[k] }));
  return out;
}
// Tìm mã tỉnh trong 1 đoạn text (tên tỉnh hoặc cả địa chỉ); lấy tên tỉnh xuất hiện CUỐI CÙNG (tỉnh nằm cuối địa chỉ)
function _resolveProvCode_(text) {
  const s = ' ' + _stripDiacriticsServer(text || '').replace(/[^a-z0-9]+/g, ' ') + ' ';
  let best = '', bestIdx = -1;
  _provKeyList_().forEach(function (it) {
    const idx = s.lastIndexOf(' ' + it.key + ' ');
    if (idx > bestIdx) { bestIdx = idx; best = it.code; }
  });
  return best;
}
function _provCodeFromInput_(cityName, address) {
  return _resolveProvCode_(cityName) || _resolveProvCode_(address);
}
function _factoryForProv_(prov) {
  return FACTORY_CT_PROVS.indexOf(prov) !== -1 ? 'CT' : 'ĐN';
}
function _codePrefix_(factory, group, prov) {
  return (group === 'HCTM' || group === 'HCGC') ? factory + group : factory + group + prov;
}
function _nextSeq_(codes, prefix) {
  const p = _normCode_(prefix) + '-';
  let max = 0;
  (codes || []).forEach(function (c) {
    const v = _normCode_(c);
    if (v.indexOf(p) === 0) {
      const n = parseInt(v.substring(p.length), 10);
      if (!isNaN(n) && n > max) max = n;
    }
  });
  return max + 1;
}
// Sinh mã mới. Trả {code, factory, group, prov, error}
function _validProvCodes_() {
  const set = {};
  Object.keys(PROV_CODE_BY_NAME).forEach(k => { set[PROV_CODE_BY_NAME[k]] = true; });
  return Object.keys(set);
}
function _generateCode_(codes, group, factoryOverride, cityName, address, provOverride) {
  group = (group || '').toString().toUpperCase();
  if (CUST_CODE_GROUPS.indexOf(group) === -1) return { code: '', error: 'Nhóm khách không hợp lệ.' };
  let prov = '';
  const po = _nfc_(provOverride).trim().toUpperCase();
  if (po) {
    if (_validProvCodes_().indexOf(po) === -1) return { code: '', error: 'Mã tỉnh "' + po + '" không có trong danh mục 34 tỉnh/thành.' };
    prov = po;
  } else prov = _provCodeFromInput_(cityName, address);
  const isHC = (group === 'HCTM' || group === 'HCGC');
  if (!prov && !isHC) return { code: '', error: 'Chưa xác định được Tỉnh/Thành.' };
  let factory = _nfc_(factoryOverride).toUpperCase();
  if (factory !== 'CT' && factory !== 'ĐN') {
    // Hội chợ: toàn bộ mã Hội chợ đang dùng đều là xưởng ĐN -> mặc định ĐN; còn lại theo tỉnh
    factory = isHC ? 'ĐN' : _factoryForProv_(prov);
  }
  const prefix = _codePrefix_(factory, group, prov);
  let seq = _nextSeq_(codes, prefix);
  const digits = (group === 'CH') ? 3 : 4;
  const pad = n => ('0000' + n).slice(-digits);
  // Chốt chặn cuối: không bao giờ trả về mã đã tồn tại
  const taken = {};
  (codes || []).forEach(c => { const v = _normCode_(c); if (v) taken[v] = true; });
  while (taken[prefix + '-' + pad(seq)]) seq++;
  if (seq > Math.pow(10, digits) - 1) return { code: '', error: 'Đã hết số thứ tự cho nhóm ' + prefix + '.' };
  return { code: prefix + '-' + pad(seq), factory: factory, group: group, prov: prov, seq: seq };
}
function _readAllCodes_(sh) {
  const lastRow = sh.getLastRow();
  const base = lastRow < 2 ? [] : sh.getRange(2, DKS_COL.CODE, lastRow - 1, 1).getValues().map(r => r[0]);
  // [MỚI] gộp cả mã của khách đang CHỜ DUYỆT để không cấp trùng
  let pend = [];
  try { pend = (typeof _pendCodes_ === 'function') ? _pendCodes_() : []; } catch (e) {}
  return base.concat(pend);
}

// [Client gọi] Xem trước mã sẽ cấp (chưa ghi sheet). p = {group, factory, city, address}
function previewCustomerCode(p) {
  try {
    p = p || {};
    const sh = _dataKhachSiSheet();
    const gen = _generateCode_(_readAllCodes_(sh), p.group, p.factory, p.city, p.address, p.prov);
    if (!gen.code) return { success: false, error: gen.error || 'Không tạo được mã.', detectedProv: _provCodeFromInput_(p.city, p.address) };
    return { success: true, code: gen.code, factory: gen.factory, group: gen.group, prov: gen.prov, provName: PROV_DISPLAY[gen.prov] || gen.prov, seq: gen.seq, autoProv: !p.prov };
  } catch (e) { return { success: false, error: e.toString() }; }
}

// [Client gọi] Cấp mã cho 1 khách CŨ chưa có mã (trang Data Khách Sỉ)
function assignCustomerCodeForRow(sheetRow, group, factory, manualCode, prov) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _dataKhachSiSheet();
    const row = parseInt(sheetRow);
    if (!row || row < 2 || row > sh.getLastRow()) return { success: false, error: 'Dòng không hợp lệ.' };
    const cur = (sh.getRange(row, DKS_COL.CODE).getValue() || '').toString().trim();
    if (cur) return { success: false, error: 'Khách này đã có mã ' + cur + ' (mã đã cấp không được đổi).' };
    const address = (sh.getRange(row, DKS_COL.ADDRESS).getValue() || '').toString();
    let gen;
    if (group === 'ST' || group === 'XK') {
      const mc = _normCode_(manualCode);
      const mm = mc.match(/^(CT|ĐN)(ST|XK)[A-Z0-9ĐÀ-Ỹ]*-/);
      if (!mc || !mm || mm[2] !== group) return { success: false, error: 'Nhóm ' + group + ': nhập mã tay dạng CT' + group + 'XX-TÊN.' };
      if (_readAllCodes_(sh).some(c => _normCode_(c) === mc)) return { success: false, error: 'Mã ' + mc + ' đã tồn tại.' };
      gen = { code: mc, factory: mm[1], group: group, prov: '' };
    } else {
      gen = _generateCode_(_readAllCodes_(sh), group, factory, '', address, prov);
    }
    if (!gen.code) return { success: false, error: gen.error || 'Không tạo được mã.' };
    sh.getRange(row, DKS_COL.CODE).setNumberFormat('@');
    sh.getRange(row, DKS_COL.CODE, 1, 4).setValues([[gen.code, gen.factory, gen.prov, gen.group]]);
    return { success: true, code: gen.code, factory: gen.factory, prov: gen.prov, group: gen.group };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

// [Client gọi] Tra mã + CCCD của khách theo SĐT (ưu tiên) hoặc tên - dùng khi copy lại đơn từ Lịch Sử
function getCustomerCodeFor(phone, name) {
  try {
    const sh = _dataKhachSiSheet();
    if (!sh || sh.getLastRow() < 2) return { code: '', cccd: '' };
    const data = sh.getRange(2, 1, sh.getLastRow() - 1, DKS_TOTAL_COLS).getValues();
    const pc = (phone || '').toString().replace(/[^0-9]/g, '');
    const nm = _stripDiacriticsServer(name || '').trim();
    let hit = null;
    if (pc) hit = data.filter(r => (r[DKS_COL.PHONE - 1] || '').toString().replace(/[^0-9]/g, '') === pc)[0] || null;
    if (!hit && nm) hit = data.filter(r => _stripDiacriticsServer(r[DKS_COL.NAME - 1] || '').trim() === nm)[0] || null;
    if (!hit) return { code: '', cccd: '' };
    return { code: (hit[DKS_COL.CODE - 1] || '').toString(), cccd: (hit[DKS_COL.CCCD - 1] || '').toString() };
  } catch (e) { return { code: '', cccd: '' }; }
}


/** ============================================================
 *  [MỚI v7.1] NHẬP KHÁCH HÀNG TỪ FILE "NEW CODE"
 *  Client (trang Data Khách Sỉ → "Nhập file New Code") đọc file Excel rồi gửi từng đợt về đây.
 *  Khớp khách theo: Mã KH → Mã cũ (KHSxxxx) → SĐT → (MST/CCCD + tên) → (tên + địa chỉ).
 *  Khớp được thì CẬP NHẬT (không xóa dữ liệu cũ bằng ô trống); không khớp thì THÊM MỚI.
 *  Dòng không có mã trong file → vào tab "Khách sỉ cũ chưa có mã".
 * ============================================================ */
const NC_CODE_RE = /^(CT|ĐN)(HCTM|HCGC|DL\d|MN|CH|ST|XK|HC)/;

function _ncNormName_(s) { return _stripDiacriticsServer(s || '').replace(/[^a-z0-9]+/g, ' ').trim(); }
function _ncCleanName_(s) {
  s = (s == null ? '' : s).toString().trim();
  s = s.replace(/^bán\s+(hàng\s+)?cho\s+người\s+tiêu\s+dùng\s*[-–:]?\s*/i, '');
  s = s.replace(/\s*\((?:CCCD|CCDC|CMND)[^)]*\)\s*/ig, ' ').replace(/\s*\((?:điện thoại|dien thoai)[^)]*\)\s*/ig, ' ');
  return s.replace(/\s+/g, ' ').trim();
}
function _ncPhoneFromText_(s) {
  const m = (s || '').toString().match(/(?:điện thoại|dien thoai|sđt|sdt)[^\d]*(0\d{8,10})/i);
  return m ? m[1] : '';
}
// Cột "Mã khách hàng / MST / CCCD" trong file lẫn 3 loại: mã cũ KHSxxxx, CCCD (12 số, có thể mất số 0 đầu), MST (10 số hoặc 10-3 số)
function _ncClassifyId_(v) {
  const out = { tax: '', cccd: '', oldCode: '' };
  if (v == null || v === '') return out;
  let s = (typeof v === 'number') ? String(Math.round(v)) : v.toString();
  s = s.replace(/\s+/g, '');
  if (!s) return out;
  if (/^KHS\d+$/i.test(s)) { out.oldCode = s.toUpperCase(); return out; }
  if (/^[A-Za-zĐđ]/.test(s)) return out;                 // dạng CTXK-xxx: là mã, không phải số giấy tờ
  if (s.indexOf('-') !== -1) { out.tax = s; return out; }   // 0304741634-015
  let d = s.replace(/\D/g, '');
  if (d.length === 11) d = '0' + d;
  if (d.length === 12 || d.length === 9) out.cccd = d; else if (d) out.tax = d;
  return out;
}

function importNewCodeBatch(rows, opts) {
  opts = opts || {};
  const snap = opts.snap || null; let nSame = 0; const orig = {};   // [v9] snap: bản chụp link lần đồng bộ trước
  const lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const sh = _dataKhachSiSheet();
    const W = DKS_TOTAL_COLS;
    const last = sh.getLastRow();
    const data = last > 1 ? sh.getRange(2, 1, last - 1, W).getValues() : [];
    const byCode = {}, byOld = {}, byPhone = {}, byIdName = {}, byNameAddr = {};
    const digits = v => (v == null ? '' : v).toString().replace(/[^0-9]/g, '');
    const index = function (r, i) {
      const c = _normCode_(r[DKS_COL.CODE - 1]); if (c) byCode[c] = i;
      const o = _normCode_(r[DKS_COL.OLD_CODE - 1]); if (o) byOld[o] = i;
      const p = digits(r[DKS_COL.PHONE - 1]); if (p) byPhone[p] = i;
      const nm = _ncNormName_(r[DKS_COL.NAME - 1]);
      const idn = digits(r[DKS_COL.TAX - 1]) || digits(r[DKS_COL.CCCD - 1]);
      if (idn && nm) byIdName[idn + '|' + nm] = i;
      if (nm) byNameAddr[nm + '|' + _ncNormName_(r[DKS_COL.ADDRESS - 1])] = i;
    };
    data.forEach(index);

    const changed = {};
    const added = [];
    const warnings = [];
    let nUpd = 0, nAdd = 0, nSkip = 0;

    (rows || []).forEach(function (x) {
      const rawName = (x.name || '').toString().trim();
      const alias = (x.alias || '').toString().trim();
      const newName = (x.newName || '').toString().trim();
      if (!rawName && !alias && !newName) { nSkip++; return; }

      let code = _normCode_(x.code);
      if (x.dupOf) { warnings.push('Mã ' + x.dupOf + ' bị trùng trong file: khách "' + (newName || alias || _ncCleanName_(rawName)) + '" được nhập KHÔNG mã (tab "chưa có mã") - hãy tự cấp mã.'); code = ''; }
      const id = _ncClassifyId_(x.idRaw);
      let phone = digits(x.phone) || digits(_ncPhoneFromText_(rawName));
      const m = code ? code.match(NC_CODE_RE) : null;
      let group = m ? m[2] : '';
      if (!group) { const g = (x.group || '').toString().trim().toUpperCase(); group = (g === 'HC') ? 'HC' : (/^DL\d?$/.test(g) ? (g === 'DL' ? 'DL1' : g) : (['MN', 'CH', 'ST', 'XK'].indexOf(g) !== -1 ? g : '')); }
      const factory = m ? m[1] : _nfc_(x.factory).trim().toUpperCase();
      let prov = _nfc_(x.prov).trim().toUpperCase();
      if (!prov && m && (group === 'MN' || group === 'CH' || /^DL\d$/.test(group))) prov = code.substr(m[0].length, 2);

      const cleanName = _ncCleanName_(rawName);
      const displayName = x.nameFromCol ? (cleanName || rawName) : (newName || alias || cleanName);   // nameFromCol (sheet DL): tên = đúng cột "Tên khách hàng"
      const nm = _ncNormName_(displayName), nmClean = _ncNormName_(cleanName);
      const addr = (x.address || '').toString().trim();
      const idn = id.tax.replace(/\D/g, '') || id.cccd;

      let idx = -1;
      if (code && byCode[code] != null) idx = byCode[code];
      if (idx < 0 && id.oldCode && byOld[id.oldCode] != null) idx = byOld[id.oldCode];
      if (idx < 0 && phone && byPhone[phone] != null) idx = byPhone[phone];
      if (idx < 0 && idn) idx = (byIdName[idn + '|' + nm] != null) ? byIdName[idn + '|' + nm] : (byIdName[idn + '|' + nmClean] != null ? byIdName[idn + '|' + nmClean] : -1);
      if (idx < 0) { const k = (byNameAddr[nm + '|' + _ncNormName_(addr)] != null) ? byNameAddr[nm + '|' + _ncNormName_(addr)] : byNameAddr[nmClean + '|' + _ncNormName_(addr)]; if (k != null) idx = k; }
      if (idx >= 0 && idx < data.length && code) {
        const cur = _normCode_(data[idx][DKS_COL.CODE - 1]);
        if (cur && cur !== code) idx = -1;   // khách đó đã mang mã khác → coi là người khác
      }

      const apply = function (arr) {
        const set = function (col, val) { if (val !== '' && val != null) arr[col - 1] = val; };
        set(DKS_COL.NAME, displayName);
        set(DKS_COL.ADDRESS, addr);
        set(DKS_COL.PHONE, phone);
        set(DKS_COL.INVOICE_NAME, rawName);
        set(DKS_COL.TAX, id.tax);
        set(DKS_COL.CCCD, id.cccd);
        set(DKS_COL.OLD_CODE, id.oldCode);
        if (alias && _ncNormName_(alias) !== _ncNormName_(displayName)) set(DKS_COL.DESCRIPTION, alias);
        if (code) { set(DKS_COL.CODE, code); set(DKS_COL.FACTORY, factory); set(DKS_COL.PROV, prov); set(DKS_COL.GROUP, group); }
        else if (group && !arr[DKS_COL.GROUP - 1]) set(DKS_COL.GROUP, group);
        return arr;
      };

      if (idx >= 0 && idx < data.length) {
        if (snap && x.snapKey && snap[x.snapKey] === x.snapHash) { nSame++; return; }   // dòng trên link không đổi từ lần trước -> giữ nguyên dữ liệu trong app
        if (orig[idx] === undefined) orig[idx] = JSON.stringify(data[idx]);
        apply(data[idx]); changed[idx] = true; index(data[idx], idx); nUpd++;
      } else {
        const arr = apply(new Array(W).fill(''));
        data.push(arr); added.push(arr); index(arr, data.length - 1); nAdd++;
      }
    });

    const fmtCols = [DKS_COL.PHONE, DKS_COL.TAX, DKS_COL.CCCD, DKS_COL.CODE, DKS_COL.OLD_CODE];
    // [v9] chỉ ghi các dòng THỰC SỰ đổi, gom dòng liền nhau thành 1 lần ghi (nhanh khi đồng bộ cả nghìn khách)
    const dirty = Object.keys(changed).map(function (k) { return parseInt(k, 10); })
      .filter(function (i) { return i < last - 1 && (orig[i] === undefined || JSON.stringify(data[i]) !== orig[i]); })
      .sort(function (a, b) { return a - b; });
    let pp = 0;
    while (pp < dirty.length) {
      let qq = pp; while (qq + 1 < dirty.length && dirty[qq + 1] === dirty[qq] + 1) qq++;
      const startRow = dirty[pp] + 2, len = qq - pp + 1;
      fmtCols.forEach(c => sh.getRange(startRow, c, len, 1).setNumberFormat('@'));
      sh.getRange(startRow, 1, len, W).setValues(dirty.slice(pp, qq + 1).map(function (i) { return data[i]; }));
      pp = qq + 1;
    }
    if (added.length) {
      const start = sh.getLastRow() + 1;
      fmtCols.forEach(c => sh.getRange(start, c, added.length, 1).setNumberFormat('@'));
      sh.getRange(start, 1, added.length, W).setValues(added);
    }
    // dòng mới thêm nhưng bị "update" lại trong cùng đợt (cùng khách xuất hiện 2 lần) đã nằm trong `added` (cùng tham chiếu mảng) nên không mất dữ liệu
    return { success: true, updated: dirty.length, added: nAdd, skipped: nSkip, unchanged: nSame, warnings: warnings };
  } catch (e) {
    return { success: false, error: e.toString() };
  } finally { lock.releaseLock(); }
}

// [Client gọi] Tạo khách hàng mới: nhập đủ thông tin, mã tự sinh theo quy tắc (MN/CH/HCTM/HCGC) hoặc nhập tay (ST/XK)
function createCustomerManual(p) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(8000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    p = p || {};
    const name = (p.name || '').toString().trim();
    const address = (p.address || '').toString().trim();
    const group = (p.group || '').toString().trim().toUpperCase();
    const phone = (p.phone || '').toString().replace(/[^0-9]/g, '');
    if (!name) return { success: false, error: 'Vui lòng nhập tên khách hàng.' };
    if (!address) return { success: false, error: 'Vui lòng nhập địa chỉ.' };
    if (CUST_CODE_GROUPS.concat(['ST', 'XK']).indexOf(group) === -1) return { success: false, error: 'Vui lòng chọn nhóm khách.' };
    const sh = _dataKhachSiSheet();
    const last = sh.getLastRow();
    if (last > 1) {
      const all = sh.getRange(2, 1, last - 1, DKS_TOTAL_COLS).getValues();
      const dg = v => (v == null ? '' : v).toString().replace(/[^0-9]/g, '');
      const tax = dg(p.taxCode), cc = dg(p.cccd);
      const nm = _ncNormName_(name), ad = _ncNormName_(address);
      for (let i = 0; i < all.length; i++) {
        const r = all[i], who = ' (dòng ' + (i + 2) + ': ' + (r[DKS_COL.NAME - 1] || '') + (r[DKS_COL.CODE - 1] ? ' - ' + r[DKS_COL.CODE - 1] : ' - chưa có mã') + ')';
        if (phone && dg(r[DKS_COL.PHONE - 1]) === phone) return { success: false, duplicate: true, error: 'TRÙNG SĐT với khách đã có' + who };
        if (tax && dg(r[DKS_COL.TAX - 1]) === tax && _ncNormName_(r[DKS_COL.NAME - 1]) === nm) return { success: false, duplicate: true, error: 'TRÙNG MST + tên với khách đã có' + who };
        if (cc && dg(r[DKS_COL.CCCD - 1]) === cc) return { success: false, duplicate: true, error: 'TRÙNG CCCD với khách đã có' + who };
        if (nm && _ncNormName_(r[DKS_COL.NAME - 1]) === nm && _ncNormName_(r[DKS_COL.ADDRESS - 1]) === ad) return { success: false, duplicate: true, error: 'TRÙNG tên + địa chỉ với khách đã có' + who };
      }
    }
    const codes = _readAllCodes_(sh);
    let code = '', factory = '', prov = '';
    if (group === 'ST' || group === 'XK') {
      code = _normCode_(p.manualCode);
      const m = code.match(/^(CT|ĐN)(ST|XK)[A-Z0-9ĐÀ-Ỹ]*-/);
      if (!code || !m || m[2] !== group) return { success: false, error: 'Nhóm ' + group + ' nhập mã tay theo dạng CT' + group + 'XX-TÊN hoặc ĐN' + group + 'XX-0001.' };
      if (codes.some(c => _normCode_(c) === code)) return { success: false, error: 'Mã ' + code + ' đã tồn tại.' };
      factory = m[1];
    } else {
      const gen = _generateCode_(codes, group, p.factory, p.city, address, p.prov);
      if (!gen.code) return { success: false, error: gen.error || 'Không tạo được mã.' };
      code = gen.code; factory = gen.factory; prov = gen.prov;
    }
    const arr = new Array(DKS_TOTAL_COLS).fill('');
    arr[DKS_COL.NAME - 1] = name; arr[DKS_COL.PHONE - 1] = phone; arr[DKS_COL.ADDRESS - 1] = address;
    arr[DKS_COL.LOAI_KHACH_SI - 1] = (p.customerType || '').toString();
    arr[DKS_COL.TAX - 1] = (p.taxCode || '').toString().trim();
    arr[DKS_COL.COMPANY - 1] = (p.company || '').toString().trim();
    arr[DKS_COL.INVOICE_NAME - 1] = (p.invoiceName || '').toString().trim();
    arr[DKS_COL.CCCD - 1] = (p.cccd || '').toString().trim();
    arr[DKS_COL.DESCRIPTION - 1] = (p.description || '').toString().trim();
    arr[DKS_COL.EMAIL - 1] = _cleanEmail_(p.email);
    arr[DKS_COL.CODE - 1] = code; arr[DKS_COL.FACTORY - 1] = factory; arr[DKS_COL.PROV - 1] = prov; arr[DKS_COL.GROUP - 1] = group;
    const row = last + 1;
    [DKS_COL.PHONE, DKS_COL.TAX, DKS_COL.CCCD, DKS_COL.CODE, DKS_COL.OLD_CODE].forEach(c => sh.getRange(row, c).setNumberFormat('@'));
    sh.getRange(row, 1, 1, DKS_TOTAL_COLS).setValues([arr]);
    return { success: true, code: code, factory: factory, prov: prov, group: group, sheetRow: row };
  } catch (e) { return { success: false, error: e.toString() }; } finally { lock.releaseLock(); }
}


/** ============================================================
 *  [MỚI v7.1] THEO DÕI XUẤT HÓA ĐƠN + ZALO BOT
 *  Sheet TheoDoiHoaDon: mỗi đơn xác nhận ở popup sao chép = 1 dòng.
 *  - Ngày xuất = hôm nay  → bot KHÔNG tự báo; người dùng vào bảng, chọn "Đã yêu cầu xuất" / "Đã yêu cầu xuất bỏ" thì bot mới gửi.
 *  - Ngày xuất = ngày khác → bot gửi lúc 8h sáng ngày đó.
 *  - Sửa ngày xuất sau khi bot đã gửi → bot báo "đã chỉnh sửa"; nếu sang ngày khác → 8h ngày đó nhắc lại.
 *  Trigger 5 phút/lần: chạy 1 lần hàm setupInvoiceTriggers() trong Apps Script Editor.
 *  Bot Zalo: chạy 1 lần setupZaloBot('TOKEN', 'CHAT_ID1,CHAT_ID2').
 * ============================================================ */
const INV_SHEET = 'TheoDoiHoaDon';
const INV_HEADERS = ['Mã Đơn', 'Ngày Tạo', 'NV Tạo', 'Khách Hàng', 'Mã KH', 'Địa Chỉ', 'Ngày Xuất Hàng', 'Trạng Thái', 'Hình Thức',
  'Tổng Tiền', 'Sản Phẩm (JSON)', 'Nội Dung Gửi Bot', 'Bot Gửi Lúc', 'Gửi Dự Kiến', 'Gửi Lại Lúc', 'Người Sửa Ngày', 'Lúc Sửa Ngày',
  'Ngày Cũ', 'Người Đổi Trạng Thái', 'Lúc Đổi Trạng Thái', 'SĐT'];
const IC = { ID: 1, CREATED: 2, EMP: 3, CUST: 4, CODE: 5, ADDR: 6, SHIP: 7, STATUS: 8, KIND: 9, TOTAL: 10, ITEMS: 11, TEXT: 12, SENT: 13,
  SENDAT: 14, RESEND: 15, EDITBY: 16, EDITAT: 17, OLDDATE: 18, STBY: 19, STAT: 20, PHONE: 21 };
const INV_ST = { NONE: 'Chưa yêu cầu xuất', REQ: 'Đã yêu cầu xuất', REQV: 'Đã yêu cầu xuất bỏ', DONE: 'Đã xuất hóa đơn', VOID: 'Đã xuất bỏ hóa đơn', NOINV: 'Không xuất hóa đơn' };

function _invSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(INV_SHEET);
  if (!sh) {
    sh = ss.insertSheet(INV_SHEET);
    sh.getRange(1, 1, 1, INV_HEADERS.length).setValues([INV_HEADERS]).setFontWeight('bold');
    sh.setFrozenRow(1);
  }
  return sh;
}
function _invTz_() { return Session.getScriptTimeZone(); }
function _invFmt_(d) { return Utilities.formatDate(d, _invTz_(), "yyyy-MM-dd'T'HH:mm:ss"); }
function _invParse_(s) { if (!s) return null; const d = new Date(s.toString()); return isNaN(d.getTime()) ? null : d; }
function _invToday_() { return Utilities.formatDate(new Date(), _invTz_(), 'yyyy-MM-dd'); }
function _invDM_(iso) { const p = (iso || '').toString().split('-'); return p.length === 3 ? (parseInt(p[2], 10) + '/' + parseInt(p[1], 10)) : (iso || ''); }
function _invNice_(d) { return Utilities.formatDate(d, _invTz_(), 'HH:mm dd/MM/yyyy'); }
// Xuất hàng TRONG NGÀY hoặc NGÀY ĐÃ QUA → KHÔNG tự báo (trả ''), người dùng phải vào Theo dõi xuất HĐ bấm "Đã yêu cầu xuất"/"Đã yêu cầu xuất bỏ" thì bot mới gửi.
// Ngày khác → tự báo 8h sáng ngày đó.
function _invCalcSendAt_(shipDate) {
  if (shipDate <= _invToday_()) return '';
  return _invFmt_(new Date(shipDate + 'T08:00:00'));
}
// Chuẩn hóa ô ngày giờ: nếu Google Sheets tự đổi chuỗi thành kiểu Date thì đưa về lại dạng chuỗi ISO (tránh lọc/hiển thị sai làm bảng trống)
function _invS_(v, dateOnly) {
  if (v instanceof Date) return dateOnly ? Utilities.formatDate(v, _invTz_(), 'yyyy-MM-dd') : _invFmt_(v);
  return (v == null ? '' : v).toString();
}
function _invRowObj_(r, rowNum) {
  let items = [];
  try { items = JSON.parse(r[IC.ITEMS - 1] || '[]'); } catch (e) {}
  return {
    sheetRow: rowNum, id: (r[IC.ID - 1] || '').toString(), created: _invS_(r[IC.CREATED - 1]), emp: (r[IC.EMP - 1] || '').toString(),
    customer: (r[IC.CUST - 1] || '').toString(), code: (r[IC.CODE - 1] || '').toString(), address: (r[IC.ADDR - 1] || '').toString(),
    shipDate: _invS_(r[IC.SHIP - 1], true), status: (r[IC.STATUS - 1] || INV_ST.NONE).toString(), kind: (r[IC.KIND - 1] || '').toString(),
    total: Number(r[IC.TOTAL - 1]) || 0, items: items, text: (r[IC.TEXT - 1] || '').toString(), sentAt: _invS_(r[IC.SENT - 1]),
    sendAt: _invS_(r[IC.SENDAT - 1]), resendAt: _invS_(r[IC.RESEND - 1]), editBy: (r[IC.EDITBY - 1] || '').toString(),
    editAt: _invS_(r[IC.EDITAT - 1]), oldDate: _invS_(r[IC.OLDDATE - 1], true), phone: (r[IC.PHONE - 1] || '').toString()
  };
}

// ---- Gửi Zalo Bot (Zalo Bot Platform). Nếu bạn đang dùng cách gửi khác, chỉ cần thay thân hàm này. ----
function setupZaloBot(token, chatIds) {
  const p = PropertiesService.getScriptProperties();
  // KHÔNG ghi đè token đang dùng bởi Notification.gs khi chạy không tham số
  if ((token || '').toString().trim()) p.setProperty('ZALO_BOT_TOKEN', token.toString().trim());
  if ((chatIds || '').toString().trim()) p.setProperty('ZALO_CHAT_IDS', chatIds.toString().trim());
  Logger.log('Đã lưu cấu hình bot Zalo.');
}
function invTestZalo() { Logger.log(JSON.stringify(_invSendZalo_('✅ Test bot 9 Sạch - ' + _invNice_(new Date())))); }
// Gửi qua ĐỘNG CƠ bot Zalo có sẵn (Notification.gs: guiZalo_, guiZaloTheoVaiTro_) - dùng chung token ZALO_BOT_TOKEN đã cài.
// Người nhận: (1) các vai trò trong Script Property INV_ZALO_ROLES (mặc định Admin,QLB2B) - lấy Chat ID từ bảng nhân viên;
//             (2) thêm Chat ID cố định trong ZALO_CHAT_IDS nếu có (setupZaloBot). Đổi vai trò nhận: chạy setInvoiceZaloRoles('Admin,QLB2B,CSKH').
function setInvoiceZaloRoles(roles) {
  PropertiesService.getScriptProperties().setProperty('INV_ZALO_ROLES', (roles || '').toString().trim());
  Logger.log('Vai trò nhận tin xuất hóa đơn: ' + roles);
}
function _invSendZalo_(text) {
  try {
    const props = PropertiesService.getScriptProperties();
    const msg = (text || '').toString().slice(0, 2000);
    const roles = (props.getProperty('INV_ZALO_ROLES') || 'Admin,QLB2B').split(',').map(x => x.trim()).filter(Boolean);
    const fixed = (props.getProperty('ZALO_CHAT_IDS') || '').split(',').map(x => x.trim()).filter(Boolean);
    let sent = 0;
    if (roles.length) sent += Number(guiZaloTheoVaiTro_(roles, msg)) || 0;
    fixed.forEach(function (cid) { if (guiZalo_(cid, msg)) sent++; });
    if (sent > 0) return { ok: true };
    const why = props.getProperty('last_zalo_error') || '';
    return { ok: false, error: why ? why.slice(0, 200) : ('Không có ai nhận: vai trò ' + roles.join('/') + ' chưa có Chat ID Zalo trong bảng nhân viên.') };
  } catch (e) { return { ok: false, error: e.toString() }; }
}
// Nội dung đơn + dòng người tạo đơn (không lặp nếu form sao chép đã có sẵn)
function _invTextEmp_(o) { return (o.text || '') + (/Người tạo đơn/.test(o.text || '') || !o.emp ? '' : '\nNgười tạo đơn: ' + o.emp); }
function _invMsgRequest_(o, isVoid) {
  return (isVoid ? '🔔 YÊU CẦU XUẤT BỎ HÓA ĐƠN\nMã đơn: ' : '🔔 YÊU CẦU XUẤT HÓA ĐƠN\nMã đơn: ') + o.id + '\n' + _invTextEmp_(o);
}
function _invMsgRemind_(o) {
  return '⏰ NHẮC XUẤT HÓA ĐƠN HÔM NAY (đơn đã chỉnh sửa ngày)\nMã đơn: ' + o.id + '\n' + _invTextEmp_(o);
}

// [MỚI] MỌI đơn tạo ra đều có 1 dòng ở Theo dõi xuất HĐ ngay lúc lưu đơn (trạng thái "Chưa yêu cầu xuất", KHÔNG gửi Zalo).
// Popup sau đó chỉ CẬP NHẬT dòng này (ngày xuất, loại xuất bỏ, "không xuất hóa đơn").
function _invCreateForOrder_(data, customerCode, total, opts) {
  const sh = _invSheet();
  const now = (opts && opts.created) || new Date();
  let ship = _invToday_();
  if (data.orderDate) { const d = new Date(data.orderDate); if (!isNaN(d.getTime())) ship = Utilities.formatDate(d, _invTz_(), 'yyyy-MM-dd'); }
  const prefix = 'HĐ' + Utilities.formatDate(now, _invTz_(), 'yyMMdd') + '-';
  const last = sh.getLastRow();
  let n = 0;
  if (last > 1) sh.getRange(2, 1, last - 1, 1).getValues().forEach(r => { if ((r[0] || '').toString().indexOf(prefix) === 0) n++; });
  const id = prefix + ('000' + (n + 1)).slice(-3);
  const items = (data.cartDetails || []).filter(it => Number(it.qty) > 0).map(it => ({ name: it.name, qty: it.qty, price: it.price || 0 }));
  const money = (Number(total) || 0).toLocaleString('vi-VN') + 'đ';
  const L = ['✳ ' + (data.name || '') + (customerCode ? ' (' + customerCode + ')' : '') + ', ngày đi đơn: ' + _invDM_(ship),
    ((data.invoiceName || data.company || data.name || '') + ' ' + (data.phone || '')).trim()];
  if (data.address) L.push(data.address);
  if (data.taxCode) L.push('MST ' + data.taxCode);
  if (data.cccd) L.push('CCCD ' + data.cccd);
  items.forEach(it => L.push(it.qty + ' ' + String(it.name || '').toLowerCase()));
  L.push('Tổng tiền: ' + money);
  if (data.employeeName) L.push('Người tạo đơn: ' + data.employeeName);
  const row = new Array(INV_HEADERS.length).fill('');
  row[IC.ID - 1] = id; row[IC.CREATED - 1] = _invFmt_(now); row[IC.EMP - 1] = data.employeeName || ''; row[IC.CUST - 1] = data.name || '';
  row[IC.CODE - 1] = customerCode || ''; row[IC.ADDR - 1] = data.address || ''; row[IC.SHIP - 1] = ship; row[IC.STATUS - 1] = INV_ST.NONE;
  row[IC.TOTAL - 1] = Number(total) || 0; row[IC.ITEMS - 1] = JSON.stringify(items); row[IC.TEXT - 1] = L.join('\n');
  row[IC.SENDAT - 1] = ''; row[IC.PHONE - 1] = (data.phone || '').toString();
  const r = last + 1;
  sh.getRangeList([IC.ID, IC.CREATED, IC.SHIP, IC.SENT, IC.SENDAT, IC.RESEND, IC.EDITAT, IC.OLDDATE, IC.STAT, IC.PHONE].map(c => _a1Col_(c) + r)).setNumberFormat('@');
  sh.getRange(r, 1, 1, INV_HEADERS.length).setValues([row]);
  try { _invEnsureTrigger_(); } catch (e2) {}
  return id;
}

function scheduleInvoiceReminder(p) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    p = p || {};
    const ship = (p.invoiceDate || '').toString();
    // [MỚI] Đơn đã có dòng theo dõi (tạo lúc lưu đơn) → chỉ cập nhật dòng đó
    if (p.id) {
      const shE = _invSheet();
      const rE = _invFindRow_(shE, p.id.toString());
      if (rE) {
        const oE = _invRowObj_(shE.getRange(rE, 1, 1, INV_HEADERS.length).getValues()[0], rE);
        if (p.none) {
          shE.getRange(rE, IC.STATUS).setValue(INV_ST.NOINV);
          shE.getRange(rE, IC.SENDAT).setValue('');
          shE.getRange(rE, IC.STBY).setValue(p.emp || '');
          shE.getRange(rE, IC.STAT).setNumberFormat('@').setValue(_invFmt_(new Date()));
          return { success: true, id: p.id, mode: 'none' };
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(ship)) return { success: false, error: 'Ngày xuất không hợp lệ.' };
        const sendAtE = (oE.status === INV_ST.NONE && !oE.sentAt) ? _invCalcSendAt_(ship) : '';
        shE.getRange(rE, IC.SHIP).setNumberFormat('@').setValue(ship);
        if (p.text) shE.getRange(rE, IC.TEXT).setValue(p.text);
        if (p.kind !== undefined) shE.getRange(rE, IC.KIND).setValue(p.kind || '');
        if (p.code) shE.getRange(rE, IC.CODE).setValue(p.code);
        if (p.address) shE.getRange(rE, IC.ADDR).setValue(p.address);
        if (p.phone) shE.getRange(rE, IC.PHONE).setNumberFormat('@').setValue(p.phone);
        if (p.items && p.items.length) shE.getRange(rE, IC.ITEMS).setValue(JSON.stringify(p.items.map(it => ({ name: it.name, qty: it.qty, price: it.price || 0 }))));
        if (oE.status === INV_ST.NONE && !oE.sentAt) shE.getRange(rE, IC.SENDAT).setNumberFormat('@').setValue(sendAtE);
        return { success: true, id: p.id, mode: ship < _invToday_() ? 'past' : (ship === _invToday_() ? 'manual' : '8h'), sendAt: sendAtE };
      }
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ship)) return { success: false, error: 'Ngày xuất không hợp lệ.' };
    const sh = _invSheet();
    const now = new Date();
    const prefix = 'HĐ' + Utilities.formatDate(now, _invTz_(), 'yyMMdd') + '-';
    const last = sh.getLastRow();
    let n = 0;
    if (last > 1) sh.getRange(2, 1, last - 1, 1).getValues().forEach(r => { if ((r[0] || '').toString().indexOf(prefix) === 0) n++; });
    const id = prefix + ('000' + (n + 1)).slice(-3);
    const sendAtStr = _invCalcSendAt_(ship);
    const row = new Array(INV_HEADERS.length).fill('');
    row[IC.ID - 1] = id; row[IC.CREATED - 1] = _invFmt_(now); row[IC.EMP - 1] = p.emp || ''; row[IC.CUST - 1] = p.customer || '';
    row[IC.CODE - 1] = p.code || ''; row[IC.ADDR - 1] = p.address || ''; row[IC.SHIP - 1] = ship; row[IC.STATUS - 1] = INV_ST.NONE;
    row[IC.KIND - 1] = p.kind || ''; row[IC.TOTAL - 1] = Number(p.total) || 0;
    row[IC.ITEMS - 1] = JSON.stringify((p.items || []).map(it => ({ name: it.name, qty: it.qty, price: it.price || 0 })));
    row[IC.TEXT - 1] = p.text || ''; row[IC.SENDAT - 1] = sendAtStr; row[IC.PHONE - 1] = p.phone || '';
    const r = last + 1;
    sh.getRangeList([IC.ID, IC.CREATED, IC.SHIP, IC.SENT, IC.SENDAT, IC.RESEND, IC.EDITAT, IC.OLDDATE, IC.STAT, IC.PHONE].map(c => _a1Col_(c) + r)).setNumberFormat('@');
    sh.getRange(r, 1, 1, INV_HEADERS.length).setValues([row]);
    try { _invEnsureTrigger_(); } catch (e2) {}
    return { success: true, id: id, sentNow: false, mode: ship < _invToday_() ? 'past' : (ship === _invToday_() ? 'manual' : '8h'), sendAt: sendAtStr };
  } catch (e) { return { success: false, error: e.toString() }; } finally { lock.releaseLock(); }
}

function getInvoiceTracking(opts) {
  try {
    opts = opts || {};
    const sh = _invSheet();
    const last = sh.getLastRow();
    if (last < 2) return [];
    const vals = sh.getRange(2, 1, last - 1, INV_HEADERS.length).getValues();
    const toks = _stripDiacriticsServer(opts.q || '').split(/\s+/).filter(Boolean);
    const out = [];
    for (let i = vals.length - 1; i >= 0; i--) {
      let o; try { o = _invRowObj_(vals[i], i + 2); } catch (eRow) { continue; }
      if (!o.id) continue;
      const cDay = o.created.slice(0, 10);
      if (opts.from && cDay < opts.from) continue;
      if (opts.to && cDay > opts.to) continue;
      if (opts.status && o.status !== opts.status) continue;
      if (opts.emp && o.emp !== opts.emp) continue;
      if (toks.length) {
        const hay = _stripDiacriticsServer([o.id, o.customer, o.code, o.address, o.emp, o.phone].join(' '));
        if (!toks.every(t => hay.indexOf(t) !== -1)) continue;
      }
      out.push(o);
      if (out.length >= (opts.limit || 600)) break;
    }
    return out;
  } catch (e) { return { error: e.toString() }; }
}

function _invFindRow_(sh, id) {
  const last = sh.getLastRow();
  if (last < 2) return 0;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) if ((ids[i][0] || '').toString() === id) return i + 2;
  return 0;
}

// Đổi trạng thái (tick) - chuyển sang "Đã yêu cầu xuất" thì bot gửi NGAY
function setInvoiceStatus(id, status, userName) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    if (Object.keys(INV_ST).map(k => INV_ST[k]).indexOf(status) === -1) return { success: false, error: 'Trạng thái không hợp lệ.' };
    const sh = _invSheet();
    const r = _invFindRow_(sh, id);
    if (!r) return { success: false, error: 'Không tìm thấy đơn ' + id };
    const row = sh.getRange(r, 1, 1, INV_HEADERS.length).getValues()[0];
    const o = _invRowObj_(row, r);
    const now = new Date();
    let warn = '';
    const isReq = (status === INV_ST.REQ || status === INV_ST.REQV);
    // Gửi khi: chưa từng gửi, hoặc chuyển sang "yêu cầu xuất bỏ" (đổi yêu cầu → báo lại)
    if (isReq && (!o.sentAt || (status === INV_ST.REQV && o.status !== INV_ST.REQV))) {
      const s = _invSendZalo_(status === INV_ST.REQV && o.sentAt
        ? '🔁 ĐỔI SANG XUẤT BỎ HÓA ĐƠN\nMã đơn: ' + o.id + ' - ' + o.customer + (o.code ? ' (' + o.code + ')' : '') + '\nNgười đổi: ' + (userName || '—')
        : _invMsgRequest_(o, status === INV_ST.REQV));
      if (!s.ok) return { success: false, error: 'Bot Zalo chưa gửi được: ' + s.error };
      if (!o.sentAt) sh.getRange(r, IC.SENT).setNumberFormat('@').setValue(_invFmt_(now));
      sh.getRange(r, IC.SENDAT).setValue('');
    }
    if ((status === INV_ST.DONE || status === INV_ST.VOID) && !o.sentAt) { sh.getRange(r, IC.SENDAT).setValue(''); }
    if (status === INV_ST.DONE || status === INV_ST.VOID) { sh.getRange(r, IC.RESEND).setValue(''); }
    if (status === INV_ST.NONE && !o.sentAt && !o.sendAt) { sh.getRange(r, IC.SENDAT).setNumberFormat('@').setValue(_invCalcSendAt_(o.shipDate)); }
    sh.getRange(r, IC.STATUS).setValue(status);
    sh.getRange(r, IC.STBY).setValue(userName || '');
    sh.getRange(r, IC.STAT).setNumberFormat('@').setValue(_invFmt_(now));
    return { success: true, order: _invRowObj_(sh.getRange(r, 1, 1, INV_HEADERS.length).getValues()[0], r), warn: warn };
  } catch (e) { return { success: false, error: e.toString() }; } finally { lock.releaseLock(); }
}

// Sửa ngày xuất hàng: ghi người sửa + thời gian; dời lịch nhắc; bot báo lại nếu tin trước đã gửi
function updateInvoiceShipDate(id, newDate, userName) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate || '')) return { success: false, error: 'Ngày không hợp lệ.' };
    const sh = _invSheet();
    const r = _invFindRow_(sh, id);
    if (!r) return { success: false, error: 'Không tìm thấy đơn ' + id };
    const o = _invRowObj_(sh.getRange(r, 1, 1, INV_HEADERS.length).getValues()[0], r);
    if (o.shipDate === newDate) return { success: true, order: o };
    const now = new Date();
    const finished = (o.status === INV_ST.DONE || o.status === INV_ST.VOID);
    // cập nhật nội dung "ngày đi đơn: d/m" trong tin sẽ gửi
    const newText = (o.text || '').replace(/ngày đi đơn:\s*[\d_]+\/[\d_]+/, 'ngày đi đơn: ' + _invDM_(newDate));
    sh.getRange(r, IC.OLDDATE).setNumberFormat('@').setValue(o.shipDate);
    sh.getRange(r, IC.SHIP).setValue(newDate);
    sh.getRange(r, IC.TEXT).setValue(newText);
    sh.getRange(r, IC.EDITBY).setValue(userName || '');
    sh.getRange(r, IC.EDITAT).setNumberFormat('@').setValue(_invFmt_(now));
    let botMsg = '';
    if (finished) {
      sh.getRange(r, IC.SENDAT).setValue(''); sh.getRange(r, IC.RESEND).setValue('');
    } else if (o.sentAt) {
      // tin đã gửi → báo chỉnh sửa ngay; sang ngày khác thì 8h ngày đó nhắc lại
      const future = newDate > _invToday_();
      const msg = '✏️ ĐƠN ĐÃ CHỈNH SỬA\nMã đơn: ' + o.id + ' - ' + o.customer + (o.code ? ' (' + o.code + ')' : '') +
        '\nNgày xuất hàng: ' + _invDM_(o.shipDate) + ' → ' + _invDM_(newDate) +
        '\nChỉnh sửa bởi: ' + (userName || '—') + ' lúc ' + _invNice_(now) +
        (future ? '\nBot sẽ nhắc lại lúc 8h sáng ngày ' + _invDM_(newDate) + '.' : '');
      const s = _invSendZalo_(msg);
      botMsg = s.ok ? 'Bot đã báo lại việc chỉnh sửa.' : ('Chưa gửi được tin báo chỉnh sửa: ' + s.error);
      sh.getRange(r, IC.RESEND).setNumberFormat('@').setValue(future ? _invFmt_(new Date(newDate + 'T08:00:00')) : '');
    } else {
      sh.getRange(r, IC.SENDAT).setNumberFormat('@').setValue(_invCalcSendAt_(newDate));   // hôm nay → '' (bấm tay); ngày khác → 8h
      sh.getRange(r, IC.RESEND).setValue('');
    }
    return { success: true, botMsg: botMsg, order: _invRowObj_(sh.getRange(r, 1, 1, INV_HEADERS.length).getValues()[0], r) };
  } catch (e) { return { success: false, error: e.toString() }; } finally { lock.releaseLock(); }
}

// Trigger 5 phút/lần: gửi tin đến hạn
function invTick_() {
  // B1: đọc KHÔNG khóa, chỉ lọc việc đến hạn
  const sh0 = _invSheet();
  const last0 = sh0.getLastRow();
  if (last0 < 2) return;
  const now = new Date();
  const due = [];
  sh0.getRange(2, 1, last0 - 1, INV_HEADERS.length).getValues().forEach(function (row, i) {
    const o = _invRowObj_(row, i + 2);
    if (!o.id) return;
    const open = (o.status === INV_ST.NONE || o.status === INV_ST.REQ || o.status === INV_ST.REQV);
    if (!open) return;
    const sendAt = _invParse_(o.sendAt), resendAt = _invParse_(o.resendAt);
    if (o.status === INV_ST.NONE && !o.sentAt && sendAt && now >= sendAt) due.push({ id: o.id, kind: 'send', o: o });
    else if (o.sentAt && resendAt && now >= resendAt) due.push({ id: o.id, kind: 'remind', o: o });
  });
  if (!due.length) return;   // không có gì đến hạn -> không đụng tới khóa

  // B2: gửi Zalo NGOÀI khóa
  due.forEach(function (d) {
    if (d.kind === 'send') {
      d.isVoid = (d.o.kind === 'Xuất bỏ');
      d.res = _invSendZalo_(_invMsgRequest_(d.o, d.isVoid));
    } else {
      d.res = _invSendZalo_(_invMsgRemind_(d.o));
    }
  });

  // B3: khóa NGẮN, chỉ ghi kết quả
  const lock = LockService.getScriptLock();
  try { lock.waitLock(10000); } catch (e) { return; }
  try {
    const sh = _invSheet();
    const t = new Date();
    due.forEach(function (d) {
      if (!d.res || !d.res.ok) return;
      const r = _invFindRow_(sh, d.id);
      if (!r) return;
      if (d.kind === 'send') {
        sh.getRange(r, IC.SENT).setNumberFormat('@').setValue(_invFmt_(t));
        sh.getRange(r, IC.SENDAT).setValue('');
        sh.getRange(r, IC.STATUS).setValue(d.isVoid ? INV_ST.REQV : INV_ST.REQ);
        sh.getRange(r, IC.STBY).setValue('Bot Zalo');
        sh.getRange(r, IC.STAT).setNumberFormat('@').setValue(_invFmt_(t));
      } else {
        sh.getRange(r, IC.RESEND).setValue('');
      }
    });
  } catch (e) { Logger.log('invTick_ lỗi: ' + e); } finally { lock.releaseLock(); }
}
function _invEnsureTrigger_() {
  const has = ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === 'invTick_');
  if (!has) ScriptApp.newTrigger('invTick_').timeBased().everyMinutes(5).create();
}
function setupInvoiceTriggers() {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'invTick_').forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('invTick_').timeBased().everyMinutes(5).create();
  Logger.log('Đã tạo trigger invTick_ (5 phút/lần).');
}



/** ============================================================
 *  [MỚI] BỔ SUNG ĐƠN CŨ VÀO "THEO DÕI XUẤT HĐ"
 *  Chạy tay trong Apps Script Editor: chọn hàm  backfillInvoiceTracking  rồi bấm Chạy.
 *   - Không tham số: bổ sung các đơn tạo HÔM NAY.
 *   - Muốn chọn khoảng ngày: sửa dòng gọi trong hàm  backfillInvoiceTrackingRun  (bên dưới) rồi chạy hàm đó.
 *  Đơn đã hủy bị bỏ qua. Đơn đã có dòng theo dõi (cùng khách + SĐT + tổng tiền, tạo cách nhau dưới 60 phút) bị bỏ qua
 *  => chạy lại nhiều lần không bị trùng. KHÔNG gửi Zalo. Trạng thái = "Chưa yêu cầu xuất", ngày xuất = ngày đặt đơn.
 * ============================================================ */
function backfillInvoiceTrackingRun() {
  // Ví dụ lấy từ 01/10/2026 đến hôm nay:  return backfillInvoiceTracking('2026-10-01', _invToday_());
  return backfillInvoiceTracking(_invToday_(), _invToday_());
}
function backfillInvoiceTracking(fromStr, toStr) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const from = fromStr || _invToday_(), to = toStr || from;
    const dh = _donHangSheet();
    const last = dh.getLastRow();
    if (last < 2) { Logger.log('Chưa có đơn.'); return { added: 0 }; }
    const vals = dh.getRange(2, 1, last - 1, 23).getValues();

    // mã khách theo SĐT
    const codeByPhone = {};
    try {
      const dks = _dataKhachSiSheet();
      if (dks.getLastRow() > 1) dks.getRange(2, 1, dks.getLastRow() - 1, DKS_TOTAL_COLS).getValues().forEach(function (r) {
        const ph = (r[DKS_COL.PHONE - 1] || '').toString().replace(/[^0-9]/g, ''), cd = _normCode_(r[DKS_COL.CODE - 1]);
        if (ph && cd) codeByPhone[ph] = cd;
      });
    } catch (e) {}

    // dòng theo dõi đã có (để chống trùng)
    const ish = _invSheet(), il = ish.getLastRow();
    const exist = [];
    if (il > 1) ish.getRange(2, 1, il - 1, INV_HEADERS.length).getValues().forEach(function (r) {
      const o = _invRowObj_(r, 0), t = _invParse_(o.created);
      exist.push({ cust: o.customer.trim(), phone: o.phone.replace(/[^0-9]/g, ''), total: o.total, t: t ? t.getTime() : 0 });
    });

    // gom đơn: dòng có cột A (ngày) là dòng đầu của đơn, các dòng A trống bên dưới thuộc cùng đơn
    const blocks = [];
    let cur = null;
    vals.forEach(function (r) {
      if (r[0] !== '' && r[0] != null) { cur = { first: r, rows: [r] }; blocks.push(cur); }
      else if (cur && (r[4] || '').toString().trim()) cur.rows.push(r);
    });

    let added = 0, skippedDup = 0, skippedCancel = 0;
    blocks.forEach(function (b) {
      const f = b.first;
      const d = f[0] instanceof Date ? f[0] : new Date(f[0]);
      if (isNaN(d.getTime())) return;
      const day = Utilities.formatDate(d, _invTz_(), 'yyyy-MM-dd');
      if (day < from || day > to) return;
      if ((f[20] || '').toString() === 'Huy') { skippedCancel++; return; }
      let total = 0;
      const cart = [];
      b.rows.forEach(function (r) {
        const qty = Number(r[5]) || 0, val = Number(r[6]) || 0;
        if (!qty) return;
        total += val;
        const nm = (r[4] || '').toString().replace(/\s*\([^()]*\)\s*$/, '');
        cart.push({ name: nm, qty: qty, price: qty ? Math.round(val / qty) : 0 });
      });
      if (!cart.length) return;
      const phone = (f[2] || '').toString().replace(/[^0-9]/g, '');
      const name = (f[1] || '').toString();
      const dup = exist.some(function (x) {
        return x.cust === name.trim() && x.phone === phone && Math.round(x.total) === Math.round(total) && Math.abs(x.t - d.getTime()) < 60 * 60 * 1000;
      });
      if (dup) { skippedDup++; return; }
      const data = { name: name, phone: phone, address: (f[3] || '').toString(), taxCode: (f[9] || '').toString(), company: (f[10] || '').toString(),
        invoiceName: (f[22] || '').toString(), employeeName: (f[18] || '').toString(), orderDate: d, cartDetails: cart };
      _invCreateForOrder_(data, codeByPhone[phone] || '', total, { created: d });
      exist.push({ cust: name.trim(), phone: phone, total: total, t: d.getTime() });
      added++;
    });
    const msg = 'Bổ sung Theo dõi xuất HĐ (' + from + ' → ' + to + '): thêm ' + added + ' đơn, bỏ qua ' + skippedDup + ' đơn đã có, ' + skippedCancel + ' đơn đã hủy.';
    Logger.log(msg);
    return { added: added, skippedDup: skippedDup, skippedCancel: skippedCancel, message: msg };
  } finally { lock.releaseLock(); }
}

/** ============================================================
 *  [MỚI v7.2] DANH MỤC TỈNH + KIỂM TRA TOÀN BỘ MÃ KHÁCH HÀNG
 * ============================================================ */
const PROV_DISPLAY = {
  AG:'An Giang', BN:'Bắc Ninh', CM:'Cà Mau', CB:'Cao Bằng', 'ĐL':'Đắk Lắk', 'ĐB':'Điện Biên', 'ĐO':'Đồng Nai', 'ĐT':'Đồng Tháp',
  GL:'Gia Lai', HT:'Hà Tĩnh', HY:'Hưng Yên', KH:'Khánh Hòa', LA:'Lai Châu', LS:'Lạng Sơn', LC:'Lào Cai', 'LĐ':'Lâm Đồng',
  NB:'Ninh Bình', NA:'Nghệ An', PT:'Phú Thọ', QI:'Quảng Ninh', QN:'Quảng Ngãi', QT:'Quảng Trị', SL:'Sơn La', TN:'Tây Ninh',
  TQ:'Tuyên Quang', TA:'Thái Nguyên', TH:'Thanh Hóa', CT:'Cần Thơ', 'ĐN':'Đà Nẵng', HN:'Hà Nội', HP:'Hải Phòng',
  SG:'TP. Hồ Chí Minh', HU:'Huế', VL:'Vĩnh Long'
};
function getProvinceList() {
  const keys = {};
  _provKeyList_().forEach(it => { (keys[it.code] = keys[it.code] || []).push(it.key); });
  return _validProvCodes_().map(c => ({ code: c, name: PROV_DISPLAY[c] || c, factory: _factoryForProv_(c), keys: keys[c] || [] }))
    .sort((a, b) => a.name.localeCompare(b.name, 'vi'));
}
function _validCodeFormat_(code, group) {
  const c = _normCode_(code);
  const provs = _validProvCodes_().join('|');
  if (group === 'MN') return new RegExp('^(CT|ĐN)MN(' + provs + ')-\\d{4}$').test(c);
  if (group === 'CH') return new RegExp('^(CT|ĐN)CH(' + provs + ')-\\d{3,4}$').test(c);
  if (group === 'HCTM' || group === 'HCGC') return new RegExp('^(CT|ĐN)' + group + '-\\d{4}$').test(c);
  if (/^DL\d$/.test(group)) return new RegExp('^(CT|ĐN)' + group + '(' + provs + ')-\\d{3,4}$').test(c);
  if (group === 'ST' || group === 'XK') return new RegExp('^(CT|ĐN)' + group + '[A-Z0-9ĐÀ-Ỹ]+-[A-Z0-9ĐÀ-Ỹ]+$').test(c);
  return new RegExp('^(CT|ĐN)(HC)').test(c);
}
// [Client gọi] Rà soát toàn bộ DataKhachSi: mã trùng, sai cấu trúc, lệch nhóm/xưởng/tỉnh, SĐT/MST trùng
function auditCustomerCodes() {
  try {
    const sh = _dataKhachSiSheet();
    const last = sh.getLastRow();
    const data = last > 1 ? sh.getRange(2, 1, last - 1, DKS_TOTAL_COLS).getValues() : [];
    const rep = { total: data.length, withCode: 0, noCode: 0, duplicates: [], badFormat: [], mismatch: [], dupPhone: [], dupTax: [] };
    const byCode = {}, byPhone = {}, byTax = {};
    const dg = v => (v == null ? '' : v).toString().replace(/[^0-9]/g, '');
    data.forEach(function (r, i) {
      const row = i + 2, code = _normCode_(r[DKS_COL.CODE - 1]), name = (r[DKS_COL.NAME - 1] || '').toString();
      const ph = dg(r[DKS_COL.PHONE - 1]), tx = dg(r[DKS_COL.TAX - 1]);
      if (ph) (byPhone[ph] = byPhone[ph] || []).push(row);
      if (tx) (byTax[tx + '|' + _ncNormName_(name)] = byTax[tx + '|' + _ncNormName_(name)] || []).push(row);
      if (!code) { if (name || ph) rep.noCode++; return; }
      rep.withCode++;
      (byCode[code] = byCode[code] || []).push(row);
      const m = code.match(/^(CT|ĐN)(HCTM|HCGC|DL\d|MN|CH|ST|XK|HC)/);
      if (!m) { rep.badFormat.push({ row: row, code: code, name: name, why: 'Không bắt đầu bằng CT/ĐN + nhóm' }); return; }
      const grp = m[2];
      if (!_validCodeFormat_(code, grp)) rep.badFormat.push({ row: row, code: code, name: name, why: 'Sai cấu trúc ' + grp });
      const why = [];
      const gCol = _nfc_(r[DKS_COL.GROUP - 1]).trim().toUpperCase(), fCol = _nfc_(r[DKS_COL.FACTORY - 1]).trim().toUpperCase(), pCol = _nfc_(r[DKS_COL.PROV - 1]).trim().toUpperCase();
      if (gCol && gCol !== grp) why.push('cột Nhóm=' + gCol);
      if (fCol && fCol !== m[1]) why.push('cột Xưởng=' + fCol);
      if ((grp === 'MN' || grp === 'CH' || /^DL\d$/.test(grp))) {
        const pc = code.substr(m[0].length, 2);
        if (pCol && pCol !== pc) why.push('cột Tỉnh=' + pCol);
        if (_validProvCodes_().indexOf(pc) !== -1 && _factoryForProv_(pc) !== m[1]) why.push('xưởng ' + m[1] + ' không khớp tỉnh ' + pc + ' (đúng: ' + _factoryForProv_(pc) + ')');
      }
      if (why.length) rep.mismatch.push({ row: row, code: code, name: name, why: why.join('; ') });
    });
    Object.keys(byCode).forEach(k => { if (byCode[k].length > 1) rep.duplicates.push({ code: k, rows: byCode[k] }); });
    Object.keys(byPhone).forEach(k => { if (byPhone[k].length > 1) rep.dupPhone.push({ phone: k, rows: byPhone[k] }); });
    Object.keys(byTax).forEach(k => { if (byTax[k].length > 1) rep.dupTax.push({ key: k.split('|')[0], rows: byTax[k] }); });
    ['duplicates', 'badFormat', 'mismatch', 'dupPhone', 'dupTax'].forEach(k => { rep[k + 'Count'] = rep[k].length; rep[k] = rep[k].slice(0, 80); });
    rep.ok = !rep.duplicatesCount && !rep.badFormatCount && !rep.mismatchCount;
    return rep;
  } catch (e) { return { error: e.toString() }; }
}
function chanDoanLichSuThang8() {
  const L = [];
  try {
    const f = new Date(2026, 7, 1, 0, 0, 0), t = new Date(2026, 7, 31, 23, 59, 59);
    L.push('Công tắc đọc lưu trữ: ' + (typeof _ldOn_ === 'function' ? (_ldOn_() ? 'BẬT' : 'TẮT') : 'không có _ldOn_'));
    L.push('Có _ldExtraRows_: ' + (typeof _ldExtraRows_ === 'function'));
    const ex = _ldExtraRows_(f, t);
    L.push('_ldExtraRows_ tháng 08: ' + ex.rows.length + ' dòng thô');
    if (ex.rows.length) {
      const r = ex.rows[0];
      L.push('Dòng đầu: ngày=' + r[0] + ' (kiểu ' + Object.prototype.toString.call(r[0]) + ') | khách=' + r[1] + ' | NV=' + r[18]);
    }
    const o = _readDonHangGrouped(f.toISOString(), t.toISOString(), null, false);
    L.push('_readDonHangGrouped tháng 08: ' + o.length + ' đơn');
    const h = getHistoryPage(f.toISOString(), t.toISOString(), null, '', false);
    L.push('getHistoryPage: ' + h.count + ' đơn' + (h.error ? ' | LỖI: ' + h.error : ''));
  } catch (e) { L.push('LỖI: ' + e + (e.stack ? '\n' + e.stack : '')); }
  Logger.log(L.join('\n'));
}
function testWebGoiLichSu() {
  const h = getHistoryPage('2026-08-01', '2026-08-31', [], '');
  Logger.log('count=' + h.count + ' | totalRev=' + h.totalRev + ' | error=' + (h.error || 'không'));
  if (h.orders && h.orders.length) Logger.log('đơn đầu: ' + h.orders[0].date + ' | ' + h.orders[0].name + ' | sheetStartRow=' + h.orders[0].sheetStartRow);
}
function testLichSuNhieuCach() {
  const iso1 = new Date(2026, 7, 1, 0, 0, 0).toISOString();
  const iso2 = new Date(2026, 7, 31, 23, 59, 59).toISOString();
  const cases = [
    ['A: ngày chuỗi "2026-08-01", NV = mảng rỗng (đúng như web)', '2026-08-01', '2026-08-31', []],
    ['B: ngày chuỗi, NV = null', '2026-08-01', '2026-08-31', null],
    ['C: ngày ISO đầy đủ, NV = mảng rỗng', iso1, iso2, []],
    ['D: ngày ISO đầy đủ, NV = null (như hàm chẩn đoán cũ)', iso1, iso2, null]
  ];
  cases.forEach(function (c) {
    try {
      const h = getHistoryPage(c[1], c[2], c[3], '');
      Logger.log(c[0] + ' => ' + h.count + ' đơn | ' + h.totalRev + 'đ | lỗi: ' + (h.error || 'không'));
    } catch (e) { Logger.log(c[0] + ' => LỖI ' + e); }
  });
  Logger.log('Múi giờ dự án: ' + Session.getScriptTimeZone());
}
function testLichSuKieuDuLieu() {
  const h = getHistoryPage('2026-08-01', '2026-08-31', [], '');
  const bad = {};
  const note = function (where, k, v, i) {
    if (v === null || v === undefined) return;
    const bi = (typeof v === 'object') || (typeof v === 'number' && !isFinite(v)) || (typeof v === 'function');
    if (!bi) return;
    const key = where + '.' + k + ' (' + Object.prototype.toString.call(v) + ')';
    bad[key] = (bad[key] || 0) + 1;
    if (bad[key] <= 2) Logger.log('đơn #' + i + ' | ' + key + ' = ' + String(v).slice(0, 60));
  };
  (h.orders || []).forEach(function (o, i) {
    Object.keys(o).forEach(function (k) { if (k !== 'items') note('đơn', k, o[k], i); });
    (o.items || []).forEach(function (it) { Object.keys(it).forEach(function (k) { note('sp', k, it[k], i); }); });
  });
  Logger.log('count=' + h.count + ' | trường lỗi: ' + (Object.keys(bad).length ? JSON.stringify(bad) : 'KHÔNG CÓ') + ' | JSON dài ' + JSON.stringify(h).length + ' ký tự');
}
function _hsv_(v) {
  if (v instanceof Date) return isNaN(v.getTime()) ? '' : Utilities.formatDate(v, 'Asia/Ho_Chi_Minh', 'dd/MM/yyyy HH:mm');
  if (v === null || v === undefined) return '';
  return (typeof v === 'number' || typeof v === 'boolean') ? v : v.toString();
}