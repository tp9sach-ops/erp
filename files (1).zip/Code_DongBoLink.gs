/** ============================================================
 *  9 SẠCH - ĐỒNG BỘ DATA KHÁCH SỈ VỚI GOOGLE SHEET (LINK)   — FILE MỚI (v9)
 *
 *  1) KÉO XUỐNG  : mở trang "Data Khách Sỉ" -> syncCustomersFromLink() đọc các sheet MN, CH-ST-HC-XK, DL*
 *                  trong link, khớp với DataKhachSi (theo Mã KH -> Mã cũ -> SĐT -> MST/CCCD+tên -> tên+địa chỉ),
 *                  CHỈ cập nhật / thêm mới, KHÔNG BAO GIỜ xóa khách trong app.
 *                  Dòng nào trên link không đổi từ lần đồng bộ trước thì app giữ nguyên dữ liệu đang có
 *                  (ví dụ SĐT, email, sửa tay trong app) - dùng "bản chụp" lưu ở sheet ẩn DongBoLink_Snap.
 *  2) ĐẨY LÊN    : khi Admin/QLB2B duyệt khách mới -> pushNewCustomerToLink_() ghi 1 dòng vào HÀNG TRỐNG KẾ TIẾP
 *                  của sheet tương ứng trên link. Không sửa / không đè bất kỳ ô cũ nào, không đụng cột A (Stt).
 *                  Chỉ ghi các cột có trong link (Mã mới, MST/CCCD, Tên, Địa chỉ, Phân loại, Ghi chú 1, Xưởng,
 *                  Mã tỉnh, Ngày, NV). SĐT, email... KHÔNG ghi lên link (chỉ hiển thị trong web).
 *  3) Link lưu trong Script Properties (chỉ Admin/QLB2B được đổi). Log đẩy link: sheet "NhatKyDongBoLink".
 *
 *  YÊU CẦU: - File link phải là GOOGLE TRANG TÍNH thật (nếu đang là .xlsx: mở file > "Lưu dưới dạng Google Trang tính").
 *           - Tài khoản chạy web app phải có quyền CHỈNH SỬA file link.
 *           - appsscript.json: nếu có "oauthScopes" thì phải có "https://www.googleapis.com/auth/spreadsheets"
 *             (KHÔNG dùng spreadsheets.currentonly). Sau khi dán code: chạy hàm slKiemTraLink() 1 lần để cấp quyền.
 *
 *  Dùng lại (Code.gs / Code_KhachMoi.gs): _dataKhachSiSheet, importNewCodeBatch, _normCode_, _ncNormName_,
 *            _pendRoleOf_, _pendRows_, _pendObj_, _pendSheet_, PC, PEND_APPROVER_ROLES.
 * ============================================================ */

const SL_PROP_URL = 'CUST_SYNC_LINK';
const SL_PROP_STATE = 'CUST_SYNC_STATE';
const SL_SNAP_SHEET = 'DongBoLink_Snap';
const SL_LOG_SHEET = 'NhatKyDongBoLink';
const SL_MIN_GAP_MS = 60 * 1000;          // mở trang liên tục: tối đa 1 lần kéo / phút (bấm "Đồng bộ ngay" thì bỏ qua)
const SL_READ_COLS = 12;                  // A..L

// ───────────────────────── tiện ích ─────────────────────────
function _slId_(url) {
  const s = String(url || '');
  const m = s.match(/\/d\/([a-zA-Z0-9_-]{20,})/) || s.match(/[?&]id=([a-zA-Z0-9_-]{20,})/);
  return m ? m[1] : '';
}
function _slOpen_(url) {
  const id = _slId_(url);
  if (!id) throw new Error('Link không đúng dạng Google Sheet (thiếu /d/<ID>/).');
  try { return SpreadsheetApp.openById(id); }
  catch (e) {
    throw new Error('Không mở được file link. Kiểm tra: (1) file phải là Google Trang tính thật - nếu đang là .xlsx thì mở file > "Lưu dưới dạng Google Trang tính" rồi dán link mới; ' +
      '(2) tài khoản chạy hệ thống cần quyền CHỈNH SỬA file; (3) appsscript.json phải có scope spreadsheets. Chi tiết: ' + e.message);
  }
}
function _slNow_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'HH:mm dd/MM/yyyy'); }
function _slCell_(v) { return v == null ? '' : (typeof v === 'string' ? v.trim() : v); }
function _slStr_(v) { const c = _slCell_(v); return c === '' ? '' : String(c); }

// Nhận diện sheet trong link: MN | CH-ST-HC-XK | DL1, DL2...
function _slKind_(name) {
  const n = String(name || '').trim();
  if (/^MN$/i.test(n)) return { mode: 'mn', dl: false, kind: 'MN' };
  if (/^CH.?ST/i.test(n)) return { mode: 'other', dl: false, kind: 'OTHER' };
  if (/^DL\d*$/i.test(n)) return { mode: 'mn', dl: true, kind: 'DL' };
  return null;
}

// 1 dòng của link (mảng A..L) -> object cùng định dạng với importNewCodeBatch (giống hệt cách trang "Nhập File" đọc)
function _slRowObj_(r, k) {
  let code = _slStr_(r[1]).trim();
  if (!code && /^(CT|ĐN)(XK|ST)[A-Z0-9ĐÀ-Ỹ]*-/i.test(_slStr_(r[2]))) code = _slStr_(r[2]).trim();
  const name = _slStr_(r[3]);
  if (!name && !code) return null;
  const o = {
    code: code, idRaw: _slCell_(r[2]), name: name, address: _slStr_(r[4]), group: _slStr_(r[5]),
    alias: k.dl ? '' : _slStr_(r[6]), newName: k.dl ? '' : _slStr_(r[7]), nameFromCol: !!k.dl,
    factory: _slStr_(r[8]), prov: k.mode === 'mn' ? _slStr_(r[9]) : ''
  };
  if (k.dl && !o.group) o.group = 'DL1';
  return o;
}
function _slKey_(o) {
  const c = _normCode_(o.code);
  return c ? c : 'N:' + _ncNormName_(o.name) + '|' + _ncNormName_(o.address);
}
function _slHash_(o) {
  const s = [String(o.idRaw == null ? '' : o.idRaw), o.name, o.alias, o.newName, o.address, o.group, o.factory, o.prov].join('\u0001');
  return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, s, Utilities.Charset.UTF_8)).substring(0, 12);
}

// ───────────────────────── bản chụp link (để biết dòng nào trên link đã đổi) ─────────────────────────
function _slSnapSheet_(create) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SL_SNAP_SHEET);
  if (!sh && create) {
    sh = ss.insertSheet(SL_SNAP_SHEET);
    sh.getRange(1, 1, 1, 2).setValues([['Khóa', 'Hash']]);
    try { sh.hideSheet(); } catch (e) {}
  }
  return sh;
}
function _slReadSnap_() {
  const sh = _slSnapSheet_(false);
  if (!sh) return null;
  const map = {};
  const n = sh.getLastRow() - 1;
  if (n > 0) sh.getRange(2, 1, n, 2).getValues().forEach(function (r) { if (r[0] !== '') map[String(r[0])] = String(r[1]); });
  return map;
}
function _slWriteSnap_(map) {
  const sh = _slSnapSheet_(true);
  const keys = Object.keys(map);
  sh.clear();
  sh.getRange(1, 1, 1, 2).setValues([['Khóa', 'Hash']]);
  if (keys.length) {
    const rng = sh.getRange(2, 1, keys.length, 2);
    rng.setNumberFormat('@');
    rng.setValues(keys.map(function (k) { return [k, map[k]]; }));
  }
}
function _slBackup_() {
  const sh = _dataKhachSiSheet();
  const name = 'DataKhachSi_BACKUP_' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyyMMdd_HHmm');
  sh.copyTo(sh.getParent()).setName(name);
  return name;
}
function _slLog_(code, sheetName, row, msg, by) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(SL_LOG_SHEET);
    if (!sh) { sh = ss.insertSheet(SL_LOG_SHEET); sh.appendRow(['Thời gian', 'Mã KH', 'Sheet link', 'Dòng', 'Kết quả', 'Người duyệt']); }
    sh.appendRow([new Date(), code, sheetName || '', row || '', msg, by || '']);
  } catch (e) {}
}

// ───────────────────────── CẤU HÌNH LINK (client gọi) ─────────────────────────
function getCustomerSyncConfig(username) {
  try {
    const me = _pendRoleOf_(username);
    if (!me) return { error: 'Không xác định được tài khoản.' };
    const p = PropertiesService.getScriptProperties();
    const url = p.getProperty(SL_PROP_URL) || '';
    let state = null;
    try { state = JSON.parse(p.getProperty(SL_PROP_STATE) || 'null'); } catch (e) {}
    const canEdit = PEND_APPROVER_ROLES.indexOf(me.role) !== -1;
    return { url: canEdit ? url : '', hasLink: !!url, canEdit: canEdit, state: state };
  } catch (e) { return { error: e.toString() }; }
}

function saveCustomerSyncLink(username, url) {
  try {
    const me = _pendRoleOf_(username);
    if (!me || PEND_APPROVER_ROLES.indexOf(me.role) === -1) return { success: false, error: 'Chỉ Admin / QLB2B được đổi link.' };
    const p = PropertiesService.getScriptProperties();
    url = String(url || '').trim();
    if (!url) { p.deleteProperty(SL_PROP_URL); p.deleteProperty(SL_PROP_STATE); return { success: true, sheets: [] }; }
    const ss = _slOpen_(url);
    const names = ss.getSheets().map(function (s) { return s.getName(); });
    const usable = names.filter(function (n) { return !!_slKind_(n); });
    if (!usable.length) return { success: false, error: 'File không có sheet nào tên MN, CH-ST-HC-XK hoặc DL1. Các sheet hiện có: ' + names.join(', ') };
    p.setProperty(SL_PROP_URL, url);
    p.deleteProperty(SL_PROP_STATE);
    return { success: true, sheets: usable };
  } catch (e) { return { success: false, error: e.message || e.toString() }; }
}

// ───────────────────────── KÉO DỮ LIỆU TỪ LINK XUỐNG ─────────────────────────
function syncCustomersFromLink(username, force) {
  const props = PropertiesService.getScriptProperties();
  try {
    const me = _pendRoleOf_(username);
    if (!me) return { success: false, error: 'Không xác định được tài khoản.' };
    const url = props.getProperty(SL_PROP_URL) || '';
    if (!url) return { success: false, noLink: true, error: 'Chưa cài link đồng bộ.' };

    let st = null;
    try { st = JSON.parse(props.getProperty(SL_PROP_STATE) || 'null'); } catch (e) {}
    if (!force && st && st.ok && st.atMs && (Date.now() - st.atMs) < SL_MIN_GAP_MS) return { success: true, skipped: true, state: st };

    const ss = _slOpen_(url);
    const order = { MN: 0, OTHER: 1, DL: 2 };
    const sheets = ss.getSheets().map(function (s) { return { s: s, k: _slKind_(s.getName()) }; })
      .filter(function (x) { return !!x.k; })
      .sort(function (a, b) { return order[a.k.kind] - order[b.k.kind]; });
    if (!sheets.length) return { success: false, error: 'Link không có sheet MN / CH-ST-HC-XK / DL1.' };

    const rows = [], seen = {}, snapNew = {};
    sheets.forEach(function (x) {
      const lr = x.s.getLastRow();
      if (lr < 2) return;
      const w = Math.min(SL_READ_COLS, x.s.getMaxColumns());
      x.s.getRange(2, 1, lr - 1, w).getValues().forEach(function (r) {
        const o = _slRowObj_(r, x.k);
        if (!o) return;
        if (o.code) {   // cùng mã + cùng khách = gộp; cùng mã nhưng khác khách = báo trùng, nhập không mã
          const k = o.code.toUpperCase(), sig = (o.name + '|' + o.address).toLowerCase();
          if (seen[k] && seen[k] !== sig) { o.dupOf = o.code; o.code = ''; } else seen[k] = sig;
        }
        o.snapKey = _slKey_(o); o.snapHash = _slHash_(o);
        snapNew[o.snapKey] = o.snapHash;
        rows.push(o);
      });
    });

    const snap = _slReadSnap_();
    let backup = '';
    if (!snap) backup = _slBackup_();           // lần đồng bộ đầu tiên: tự sao lưu DataKhachSi trước khi áp dụng

    const res = importNewCodeBatch(rows, { snap: snap });
    if (!res || !res.success) {
      const err = (res && res.error) || 'Lỗi nhập dữ liệu';
      props.setProperty(SL_PROP_STATE, JSON.stringify({ ok: false, at: _slNow_(), atMs: Date.now(), err: err }));
      return { success: false, error: err };
    }
    _slWriteSnap_(snapNew);

    const warns = res.warnings || [];
    const state = { ok: true, at: _slNow_(), atMs: Date.now(), by: me.name, added: res.added, updated: res.updated,
      unchanged: res.unchanged || 0, rows: rows.length, warnCount: warns.length, backup: backup };
    props.setProperty(SL_PROP_STATE, JSON.stringify(state));
    return { success: true, added: res.added, updated: res.updated, unchanged: res.unchanged || 0, warnings: warns.slice(0, 5), state: state };
  } catch (e) {
    const msg = e.message || e.toString();
    try { props.setProperty(SL_PROP_STATE, JSON.stringify({ ok: false, at: _slNow_(), atMs: Date.now(), err: msg })); } catch (e2) {}
    return { success: false, error: msg };
  }
}

// ───────────────────────── ĐẨY KHÁCH MỚI ĐÃ DUYỆT LÊN LINK ─────────────────────────
// Nhóm khách -> sheet trên link
function _slPickSheet_(ss, group) {
  const g = String(group || '').toUpperCase();
  const all = ss.getSheets();
  const by = function (re) { return all.filter(function (s) { return re.test(String(s.getName()).trim()); })[0] || null; };
  if (g === 'MN') return { sh: by(/^MN$/i), k: _slKind_('MN') };
  if (/^DL\d*$/.test(g)) return { sh: by(new RegExp('^' + g + '$', 'i')) || by(/^DL\d*$/i), k: _slKind_('DL1') };
  if (g === 'KL') return { sh: by(/^KL$/i), k: { mode: 'mn', dl: true, kind: 'KL' } };
  return { sh: by(/^CH.?ST/i), k: _slKind_('CH-ST') };       // CH, ST, XK, HCTM, HCGC
}

// Dựng 1 dòng A..L đúng "cú pháp" của link. Cột A (Stt) để trống - link tự đánh / công thức sẵn có.
function _slBuildRow_(c, k) {
  const grp = String(c.group || '').toUpperCase();
  const tax = String(c.taxCode || '').trim(), cccd = String(c.cccd || '').trim();
  const name = String(c.name || '').trim();
  const inv = String(c.invoiceName || '').trim(), comp = String(c.company || '').trim();
  let D;
  if (k.dl) D = name;
  else D = inv || comp || ((tax || cccd) ? name : 'Bán cho người tiêu dùng - ' + name);   // đúng kiểu các dòng đang có trên link
  const arr = new Array(SL_READ_COLS).fill('');
  arr[1] = _normCode_(c.code);                                   // B  New-code
  arr[2] = tax || cccd;                                          // C  Mã số thuế / CCCD
  arr[3] = D;                                                    // D  Tên khách hàng
  arr[4] = String(c.address || '').trim();                       // E  Địa chỉ
  arr[5] = (grp === 'HCTM' || grp === 'HCGC') ? 'HC' : grp;      // F  Phân loại
  arr[6] = name;                                                 // G  Tên ghi chú 1 (tên khách trong app)
  arr[8] = String(c.factory || '');                              // I  XƯỞNG
  arr[9] = k.mode === 'mn' ? String(c.prov || '') : '';          // J  MÃ TỈNH
  arr[10] = new Date();                                          // K  NGÀY
  arr[11] = String(c.emp || '');                                 // L  NV
  return arr;
}

// Tìm hàng trống kế tiếp: sau dòng cuối có dữ liệu ở cột B..L; bỏ qua dòng có công thức sẵn.
function _slNextRow_(sh, maxC) {
  const total = sh.getMaxRows();
  const width = Math.max(1, maxC - 1);
  const body = sh.getRange(1, 2, total, width).getValues();
  let last = 1;
  for (let i = body.length - 1; i >= 1; i--) {
    if (body[i].some(function (v) { return v !== '' && v !== null; })) { last = i + 1; break; }
  }
  let next = last + 1;
  for (let guard = 0; guard < 300; guard++) {
    if (next > sh.getMaxRows()) break;
    const rng = sh.getRange(next, 2, 1, width);
    const vals = rng.getValues()[0], f = rng.getFormulas()[0];
    if (vals.every(function (v) { return v === '' || v === null; }) && f.every(function (x) { return !x; })) break;
    next++;
  }
  return { last: last, next: next };
}

// Trả {ok, skipped, msg}. Không bao giờ ghi đè ô có dữ liệu.
function pushNewCustomerToLink_(c, byName) {
  const url = PropertiesService.getScriptProperties().getProperty(SL_PROP_URL) || '';
  if (!url) return { ok: false, skipped: true, msg: 'CHƯA ĐẨY: chưa cài link Google Sheet' };
  const code = _normCode_(c.code);
  try {
    if (!code) return { ok: false, msg: 'LỖI: khách chưa có mã' };
    const ss = _slOpen_(url);

    // chống trùng: mã đã có ở bất kỳ sheet nào của link -> không ghi thêm
    const dup = ss.getSheets().some(function (s) {
      if (!_slKind_(s.getName()) && !/^KL$/i.test(String(s.getName()).trim())) return false;
      const lr = s.getLastRow();
      if (lr < 2) return false;
      return s.getRange(2, 2, lr - 1, 1).getValues().some(function (r) { return _normCode_(r[0]) === code; });
    });
    if (dup) { _slLog_(code, '', '', 'Đã có sẵn trên link - không ghi lại', byName); return { ok: true, msg: 'OK: mã đã có sẵn trên link (không ghi lại)' }; }

    const pick = _slPickSheet_(ss, c.group);
    if (!pick.sh || !pick.k) { const m = 'LỖI: link không có sheet cho nhóm ' + (c.group || '?'); _slLog_(code, '', '', m, byName); return { ok: false, msg: m }; }
    const sh = pick.sh;
    const maxC = Math.min(SL_READ_COLS, sh.getMaxColumns());

    // chỉ ghi các cột có tiêu đề trong link (vd sheet CH-ST-HC-XK không có Mã tỉnh / Ngày / NV)
    const head = sh.getRange(1, 1, 1, maxC).getValues()[0];
    let lastHdr = 3;
    for (let i = 1; i < maxC; i++) if (String(head[i] == null ? '' : head[i]).trim() !== '') lastHdr = i;   // chỉ số 0-based của cột cuối có tiêu đề

    const pos = _slNextRow_(sh, maxC);
    if (pos.next > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), pos.next - sh.getMaxRows() + 5);
    if (pos.last > 1) sh.getRange(pos.last, 1, 1, maxC).copyTo(sh.getRange(pos.next, 1, 1, maxC), SpreadsheetApp.CopyPasteType.PASTE_FORMAT, false);

    const arr = _slBuildRow_(c, pick.k);
    sh.getRange(pos.next, 3).setNumberFormat('@');                                   // MST/CCCD luôn là văn bản (giữ số 0 đầu)
    if (lastHdr >= 10) {                                                             // cột K = Ngày
      const kc = sh.getRange(pos.next, 11);
      const nf = kc.getNumberFormat();
      if (!nf || nf === 'General' || nf === '0') kc.setNumberFormat('d/m/yyyy');
    }
    sh.getRange(pos.next, 2, 1, lastHdr).setValues([arr.slice(1, lastHdr + 1)]);      // chỉ cột B.. (không đụng cột A)
    SpreadsheetApp.flush();

    // ghi "bản chụp" để lần kéo xuống sau không coi dòng này là dòng link vừa sửa
    try {
      const o = _slRowObj_(arr.map(function (v) { return v instanceof Date ? '' : v; }), pick.k);
      const snapSh = _slSnapSheet_(false);
      if (o && snapSh) {
        const r = snapSh.getLastRow() + 1;
        snapSh.getRange(r, 1, 1, 2).setNumberFormat('@').setValues([[_slKey_(o), _slHash_(o)]]);
      }
    } catch (e0) {}

    const msg = 'OK: sheet ' + sh.getName() + ', dòng ' + pos.next;
    _slLog_(code, sh.getName(), pos.next, msg, byName);
    return { ok: true, msg: msg };
  } catch (e) {
    const m = 'LỖI: ' + (e.message || e);
    _slLog_(code, '', '', m, byName);
    return { ok: false, msg: m };
  }
}

// [Client gọi] Đẩy lại các khách ĐÃ DUYỆT nhưng lần đẩy trước lỗi / chưa cài link (chỉ ghi hàng trống kế tiếp)
function retryPushPendingToLink(username) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(15000); } catch (e) { return { success: false, error: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    const me = _pendRoleOf_(username);
    if (!me || PEND_APPROVER_ROLES.indexOf(me.role) === -1) return { success: false, error: 'Chỉ Admin / QLB2B được đẩy lại.' };
    if (!(PropertiesService.getScriptProperties().getProperty(SL_PROP_URL) || '')) return { success: false, error: 'Chưa cài link Google Sheet.' };
    const sh = _pendSheet_();
    const todo = _pendRows_().filter(function (x) {
      return x.v[PC.STATUS - 1] === 'Đã duyệt' && /^(LỖI|CHƯA)/.test(String(x.v[PC.LINK - 1] || ''));
    });
    let ok = 0, fail = 0, firstErr = '';
    todo.forEach(function (x) {
      const r = pushNewCustomerToLink_(_pendObj_(x), me.name);
      sh.getRange(x.row, PC.LINK).setValue(r.msg);
      if (r.ok) ok++; else { fail++; if (!firstErr) firstErr = r.msg; }
    });
    const message = todo.length ? ('Đã ghi lên link ' + ok + ' khách' + (fail ? (', lỗi ' + fail + ': ' + firstErr) : '') + '.') : 'Không có khách nào cần đẩy lại.';
    return { success: true, message: message, ok: ok, fail: fail };
  } catch (e) { return { success: false, error: e.message || e.toString() }; }
  finally { lock.releaseLock(); }
}

// Chạy tay 1 lần trong Apps Script Editor: cấp quyền + kiểm tra link đã lưu mở được chưa
function slKiemTraLink() {
  const url = PropertiesService.getScriptProperties().getProperty(SL_PROP_URL) || '';
  if (!url) { Logger.log('Chưa lưu link. Vào trang Data Khách Sỉ > dán link > Lưu link.'); return; }
  const ss = _slOpen_(url);
  Logger.log('Mở được file: ' + ss.getName());
  ss.getSheets().forEach(function (s) {
    Logger.log('- ' + s.getName() + ' | ' + (_slKind_(s.getName()) ? 'SẼ ĐỒNG BỘ' : 'bỏ qua') + ' | ' + s.getLastRow() + ' dòng');
  });
}
